﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace DXNotepad.Clases
{
	public static class Util
	{
		#region Formato

		/// <summary>Convierte una cadena de texto a tipo Titulo (Mayúscula Inicial)</summary>
		public static string ProperCase(String strText)
		{
			string rText = "";
			try
			{
				System.Globalization.CultureInfo cultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture;
				System.Globalization.TextInfo TextInfo = cultureInfo.TextInfo;
				strText = strText.ToLower();
				rText = TextInfo.ToTitleCase(strText);
			}
			catch
			{
				rText = strText;
			}
			return rText;
		}

		/// <summary>Formatea Numeros de Cedula, Internos y Coches.</summary>
		/// <param name="pCedula">Numero de Documento a formatear.</param>
		public static string FormatearCI(string pDocumento)
		{
			string v_formateado = string.Empty;
			int posicion = 0;
			int largo = 0;
			int largo2 = 0;

			largo = pDocumento.Length - 1;
			largo2 = pDocumento.Length;

			for (posicion = 0; posicion <= largo; posicion++)
			{
				if (posicion == 1)
				{
					v_formateado = "-" + v_formateado;
				}
				if (posicion == 4)
				{
					v_formateado = "." + v_formateado;
				}
				if (posicion == 7)
				{
					v_formateado = "." + v_formateado;
				}

				v_formateado = pDocumento.Substring(largo - posicion, 1) + v_formateado;
			}
			return v_formateado;
		}

		/// <summary>Elimina todos los caracteres de formato de una cadena, tales como: ().,-$</summary>
		/// <param name="pCadenaFormateada">Cadena con Formato.</param>
		/// <returns>Devuelve la cadena sin formato.</returns>
		public static string LimpiarFormato(string pCadenaFormateada)
		{
			string retorno = "";
			try
			{
				retorno = pCadenaFormateada.Replace(".", null);
				retorno = retorno.Replace(",", null);
				retorno = retorno.Replace("-", null);
				retorno = retorno.Replace("_", null);
				retorno = retorno.Replace("$", null);
				retorno = retorno.Replace("(", null);
				retorno = retorno.Replace(")", null);
				retorno = retorno.Replace("/", null);
				retorno = retorno.Replace(":", null);
				retorno = retorno.Replace(";", null);
				retorno = retorno.Trim();
			}
			catch { }
			return retorno;
		}

		/// <summary>Limpia todos los caracteres extraños de un texto.
		/// Extraños: Aquellos no campatibles con UTF8.</summary>
		/// <param name="Texto">Cadena de texto a limpiar.</param>
		public static string LimpiarSpecialCharacters(this string Texto)
		{
			string _ret = string.Empty;
			try
			{
				_ret = Regex.Replace(Texto, @"<[^>]+>|&nbsp;", "", RegexOptions.Multiline).Trim();
				byte[] bytes = Encoding.Default.GetBytes(_ret); //<- Los caracteres extraños se convertiran en �
				_ret = Encoding.UTF8.GetString(bytes).Replace("�", ""); //<- El texto se devuelve en formato UTF8
			}
			catch { }
			return _ret;
		}


		/// <summary>Convierte una Fecha en su representación de Cadena con la funcion MDY de Informix.
		/// Ejem: devuelve 'MDY(12,30,2012)'.</summary>
		/// <param name="pFecha">Fecha que se quiere convertir.</param>
		public static string FormatearFecha_MDY(DateTime pFecha)
		{
			string retorno = null;
			try
			{
				if (pFecha != null && pFecha != DateTime.MinValue)
				{ retorno = string.Format("MDY({0},{1},{2})", pFecha.Month, pFecha.Day, pFecha.Year); }
				else { retorno = "null"; }
			}
			catch { }
			return retorno;
		}

		/// <summary>Convierte el tamaño de un archivo a la unidad más adecuada:
		/// Returns the human-readable file size for an arbitrary, 64-bit file size.
		/// The default format is "0.### XB", e.g. "4.2 KB" or "1.434 GB"</summary>
		/// <param name="pFileLenght">Tamaño del archivo en Bytes</param>
		public static string FileSize(long pFileLenght)
		{
			// Get absolute value
			long absolute_i = (pFileLenght < 0 ? -pFileLenght : pFileLenght);
			// Determine the suffix and readable value
			string suffix;
			double readable;
			if (absolute_i >= 0x1000000000000000) // Exabyte
			{
				suffix = "EB";
				readable = (pFileLenght >> 50);
			}
			else if (absolute_i >= 0x4000000000000) // Petabyte
			{
				suffix = "PB";
				readable = (pFileLenght >> 40);
			}
			else if (absolute_i >= 0x10000000000) // Terabyte
			{
				suffix = "TB";
				readable = (pFileLenght >> 30);
			}
			else if (absolute_i >= 0x40000000) // Gigabyte
			{
				suffix = "GB";
				readable = (pFileLenght >> 20);
			}
			else if (absolute_i >= 0x100000) // Megabyte
			{
				suffix = "MB";
				readable = (pFileLenght >> 10);
			}
			else if (absolute_i >= 0x400) // Kilobyte
			{
				suffix = "KB";
				readable = pFileLenght;
			}
			else
			{
				return pFileLenght.ToString("0 B"); // Byte
			}
			// Divide by 1024 to get fractional value
			readable = Math.Round((readable / 1024), 2);
			// Return formatted number with suffix
			return readable.ToString("0.## ") + suffix;
		}

		/// <summary>Formatea el Codigo de una Ficha de Material.</summary>
		/// <param name="pCodFicha"></param>
		public static string FormatearFicha(string pCodFicha)
		{
			string _ret = string.Empty;
			try
			{
				if (!string.IsNullOrEmpty(pCodFicha) && pCodFicha.Length > 11)
				{
					_ret = String.Format("{0}.{1}.{2}.{3}.{4}.{5}", pCodFicha.Substring(0, 1),
																pCodFicha.Substring(1, 4),
																pCodFicha.Substring(5, 2),
																pCodFicha.Substring(7, 4),
																pCodFicha.Substring(11, 1),
																pCodFicha.Substring(12, 1));
				}
			}
			catch { }
			return _ret;
		}

		#endregion

		#region Extension del Lenguaje C#

		/* Estos metodos se pueden llamar directamente desde el tipo base:
			 * Ejem:  string X = "Hola Mundo ";
			 *  X = X.RemoveLastCharacter(); --> "Hola Mundo"
				var L = X.Left(2); --> "Ho"
				var R = X.Right(3); --> "ndo"
				var M = X.Mid(1, 4); --> "ola M"
				bool I = X.In("a", "b"); --> falso
			 * 
			 *  List<string> Cosas = null;
				if (Cosas.IsEmpty())
				{
					//reeplaza a ->  if (Cosas != null && Cosas.Count > 0) 
				}
			 * */

		#region Generales

		/// <summary>Verifica que la lista de objetos NO sea nula y tenga al menos 1 elemento.
		/// <para>Devuelve 'True' si la Lista contiene Elementos.</para>
		/// <para>Devuelve 'False' si la Lista es Nula o Vacia.</para></summary>
		public static bool IsNotEmpty(this ICollection elements)
		{
			return elements != null && elements.Count > 0;
		}

		/// <summary>Devuelve uno de dos objetos, dependiendo de la evaluación de una expresión.</summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="expression">Expresión que se desea evaluar.</param>
		/// <param name="truePart">Se devuelve si Expression se evalúa como True.</param>
		/// <param name="falsePart">Se devuelve si Expression se evalúa como False.</param>
		public static object IIf(bool expression, object truePart, object falsePart)
		{ return expression ? truePart : falsePart; }
		public static T IIf<T>(bool expression, T truePart, T falsePart)
		{ return expression ? truePart : falsePart; }

		/// <summary>Muestra un mensaje en un cuadro de diálogo, espera a que el usuario escriba un texto 
		/// o haga clic en un botón y devuelve una cadena con el contenido del cuadro de texto.</summary>
		/// <param name="title">Expresión de tipo String que se muestra en la barra de título del cuadro de diálogo.</param>
		/// <param name="promptText">Expresión de tipo String que se muestra como mensaje en el cuadro de diálogo.</param>
		/// <param name="value">Valor Suministrado por el usuario.</param>
		public static DialogResult InputBox(string title, string promptText, ref string value)
		{
			Form form = new Form();
			Label label = new Label();
			TextBox textBox = new TextBox();
			Button buttonOk = new Button();
			Button buttonCancel = new Button();

			form.Text = title;
			label.Text = promptText;
			textBox.Text = value;

			buttonOk.Text = "Aceptar";
			buttonCancel.Text = "Cancelar";
			buttonOk.DialogResult = DialogResult.OK;
			buttonCancel.DialogResult = DialogResult.Cancel;

			label.SetBounds(9, 20, 372, 13);
			textBox.SetBounds(12, 36, 372, 20);
			buttonOk.SetBounds(228, 72, 75, 23);
			buttonCancel.SetBounds(309, 72, 75, 23);

			label.AutoSize = true;
			textBox.Anchor = textBox.Anchor | AnchorStyles.Right;
			buttonOk.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
			buttonCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;

			form.ClientSize = new Size(396, 107);
			form.Controls.AddRange(new Control[] { label, textBox, buttonOk, buttonCancel });
			form.ClientSize = new Size(Math.Max(300, label.Right + 10), form.ClientSize.Height);
			form.FormBorderStyle = FormBorderStyle.FixedDialog;
			form.StartPosition = FormStartPosition.CenterScreen;
			form.MinimizeBox = false;
			form.MaximizeBox = false;
			form.AcceptButton = buttonOk;
			form.CancelButton = buttonCancel;

			DialogResult dialogResult = form.ShowDialog();
			value = textBox.Text;
			return dialogResult;
		}


		/// <summary>Evalua si un determinado valor se encuentra entre una lista de valores.</summary>
		/// <param name="pVariable">Valor a Buscar.</param>
		/// <param name="pValores">Lista de Valores de Referencia. Ignora Mayusculas.</param>
		/// <returns>Devuelve 'True' si el valor existe en la lista al menos una vez.</returns>
		public static bool In(this String text, params string[] pValores)
		{
			bool retorno = false;
			try
			{
				foreach (string val in pValores)
				{
					if (text.Equals(val, StringComparison.InvariantCultureIgnoreCase))
					{ retorno = true; break; }
				}
			}
			catch { }
			return retorno;
		}
		/// <summary>Evalua si un determinado valor se encuentra entre una lista de valores.</summary>
		/// <param name="pVariable">Valor a Buscar.</param>
		/// <param name="pValores">Lista de Valores de Referencia.</param>
		/// <returns>Devuelve 'True' si el valor existe en la lista al menos una vez.</returns>
		public static bool In(this Int32 valor, params int[] pValores)
		{
			bool retorno = false;
			try
			{
				foreach (int val in pValores)
				{
					if (val == valor) { retorno = true; break; }
				}
			}
			catch { }
			return retorno;
		}
		public static bool In<T>(this T source, params T[] list)
		{
			if (null == source) throw new ArgumentNullException("source");
			return list.Contains(source);
		}

		/// <summary>Determina si el valor de la Variable se encuentra dentro del Rango especificado.</summary>
		/// <typeparam name="T">Tipo de Datos del  Objeto</typeparam>
		/// <param name="Valor">Valor (numerico) a comparar.</param>
		/// <param name="Desde">Rango Inicial</param>
		/// <param name="Hasta">Rango final</param>
		public static bool Between<T>(this T Valor, T Desde, T Hasta) where T : IComparable<T>
		{
			return Valor.CompareTo(Desde) >= 0 && Valor.CompareTo(Hasta) < 0;
		}

		#endregion

		#region Texto

		/// <summary>Devuelve la Cantidad de Palabras en una Cadena de Texto.</summary>
		/// <param name="str">Texto</param>
		public static int ContarPalabras(this String text)
		{
			return text.Split(new char[] { ' ', '.', '?', ',', '!', '-', '(', ')', '"', '\'' }, StringSplitOptions.RemoveEmptyEntries).Length;
		}

		public static int ContarLetras(this String text, bool ContarEspacios = true)
		{
			if (ContarEspacios)
			{
				return text.Length;
			}
			else
			{
				return text.Replace(" ", string.Empty).Length;
			}
		}

		/// <summary>Busca palabras en una cadena de Texto. Ignora Mayusculas.</summary>
		/// <param name="text">Cadena de Texto donde se Busca</param>
		/// <param name="pValores">Lista de Palabras a Buscar</param>
		/// <returns>Devuelve la cantidad de palabras encontradas.</returns>
		public static int Search(this String text, params string[] pValores)
		{
			int _ret = 0;
			try
			{
				var Palabras = text.Split(new char[] { ' ', '.', '?', ',', '!', '-', '(', ')', '"', '\'' },
					StringSplitOptions.RemoveEmptyEntries);

				foreach (string word in Palabras)
				{
					foreach (string palabra in pValores)
					{
						if (Regex.IsMatch(word, string.Format(@"\b{0}\b", palabra), RegexOptions.IgnoreCase))
						{
							_ret++;
						}
					}
				}
			}
			catch { }
			return _ret;
		}

		/// <summary>Devuelve una cadena que contiene un número especificado de caracteres desde el lado izquierdo de una cadena.</summary>
		/// <param name="str">Cadena de texto Original.</param>
		/// <param name="length">Indica cuántos caracteres se van a devolver. Si es 0, se devuelve una cadena de longitud cero (""). 
		/// Si es mayor o igual que el número de caracteres en 'text', se devuelve toda la cadena.</param>
		public static string Left(this String text, int length)
		{
			if (length < 0) return "";
			else if (length == 0 || text.Length == 0) return "";
			else if (text.Length <= length) return text;
			else return text.Substring(0, length);
		}

		/// <summary>Devuelve una cadena que contiene un número especificado de caracteres desde el lado derecho de una cadena.</summary>
		/// <param name="text">Cadena de texto Original.</param>
		/// <param name="length">Indica cuántos caracteres se van a devolver. Si es 0, se devuelve una cadena de longitud cero (""). 
		/// Si es mayor o igual que el número de caracteres en 'text', se devuelve toda la cadena.</param>
		public static string Right(this String text, int length)
		{
			if (length < 0) { return ""; }
			else if (length == 0 || text.Length == 0) { return ""; }
			else if (text.Length <= length) { return text; }
			else { return text.Substring(text.Length - length, length); }
		}

		/// <summary>Devuelve una porcion de texto dentro de una cadena.</summary>
		/// <param name="text">Cadena de texto Original.</param>
		/// <param name="startIndex">Posicion de inicio.</param>
		/// <param name="length">Cantidad de carácteres que se quieren extraer.</param>
		public static string Mid(this String text, int startIndex, int length)
		{
			string result = text.Substring(startIndex, length);
			return result;
		}
		public static string Mid(this String text, int startIndex)
		{
			string result = text.Substring(startIndex);
			return result;
		}

		/// <summary>Convierte la cadena especificada en Mayuscula Inicial.</summary>
		/// <param name="text">Texto a Cambiar</param>
		public static string ToTitleCase(this string text)
		{
			if (text == null) return text;

			System.Globalization.CultureInfo cultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture;
			System.Globalization.TextInfo textInfo = cultureInfo.TextInfo;

			return textInfo.ToTitleCase(text.ToLower());
		}

		/// <summary>Elimina el Ultimo Caracter de la cadena."</summary>
		public static string RemoveLastCharacter(this String pTexto)
		{
			return pTexto.Substring(0, pTexto.Length - 1);
		}
		/// <summary>Elimina los Ultimos X Caracteres de la cadena."</summary>
		public static string RemoveLast(this String pTexto, int pLength = 1)
		{
			return pTexto.Substring(0, pTexto.Length - pLength);
		}
		/// <summary>Elimina el Primer Caracter de la cadena."</summary>
		public static string RemoveFirstCharacter(this String pTexto)
		{
			return pTexto.Substring(1);
		}
		/// <summary>Elimina los Primeros X Caracteres de la cadena."</summary>
		public static string RemoveFirst(this String pTexto, int pLength = 1)
		{
			return pTexto.Substring(pLength);
		}


		/// <summary>Obtiene el valor de una cadena validando NULL, Elimina espacios sobrantes y la convierte a mayusculas.</summary>
		/// <param name="pString">Cadena de Texto a Obtener</param>
		/// <param name="ToUpper">Convierte la cadena a Mayusculas</param>
		/// <param name="LeadingSpace">Agrega un espacio al principio</param>		
		public static string GetString(this String pString, bool ToUpper = true, bool LeadingSpace = false)
		{
			string _ret = string.Empty;
			if (pString != null)
			{
				_ret = pString.Trim();

				if (ToUpper) _ret = _ret.ToUpper();

				if (LeadingSpace && _ret != string.Empty)
				{
					_ret = string.Format(" {0}", _ret);
				}
			}
			return _ret;
		}


		/// <summary>Reemplaza uno o varios elementos de la cadena especificada con los valores indicados.
		/// <para>Ejem: string X = "{0}{1}".Format(1, 2);</para> </summary>
		/// <param name="texto">Cadena de texto con Formato Compuesto.</param>
		/// <param name="args">Valores a insertar en la Cadena.</param>
		public static string Format(this String texto, params object[] args)
		{
			return string.Format(texto, args);
		}

		/// <summary>Formatea la Cadena a tipo Numerico entero con separadores de miles. ej: '0.000.000'</summary>
		/// <param name="texto">Cadena de texto a Formatear</param>
		public static string FormatNumber(this String texto, string Mask = "n0")
		{
			return string.Format("{0:" + Mask + "}", texto.ToInteger());
		}

		/// <summary>Formatea la Cadena a tipo Numerico entero con separadores de miles y 2 decimales. ej: '0.000.000,00'</summary>
		/// <param name="texto">Cadena de texto a Formatear</param>
		public static string FormatDecimal(this string texto, string Mask = "n2")
		{
			return string.Format("{0:" + Mask + "}", texto.ToDecimal());
		}

		/// <summary>Formatea la Cadena a tipo Numerico entero con separadores de miles y 2 decimales. ej: '0.000.000,00'</summary>
		/// <param name="texto">Cadena de texto a Formatear</param>
		public static string FormatCurrency(this string texto)
		{
			return string.Format("$ {0:n2}", texto.ToDecimal());
		}

		/// <summary>Formats the string according to the specified mask</summary>
		/// <param name="input">The input string.</param>
		/// <param name="mask">The mask for formatting. Like "A##-##-T-###Z"</param>
		/// <returns>The formatted string</returns>
		public static string FormatWithMask(this string input, string mask)
		{
			if (input.IsNullOrEmpty()) return input;
			var output = string.Empty;
			var index = 0;
			foreach (var m in mask)
			{
				if (m == '#')
				{
					if (index < input.Length)
					{
						output += input[index];
						index++;
					}
				}
				else
					output += m;
			}
			return output;
		}


		/// <summary>Devuelve la Cadena de texto con sus caracteres invertidos.</summary>
		/// <param name="input">Texto</param>
		public static string Reverse(this string input)
		{
			if (string.IsNullOrWhiteSpace(input)) return string.Empty;
			char[] chars = input.ToCharArray();
			Array.Reverse(chars);
			return new String(chars);
		}


		/// <summary>Valida que la cadena tenga el formato de una direccion de Correo Electronico.
		/// No intenta enviar ningun mensaje para verificar su existencia.</summary>
		/// <param name="input"></param>
		public static bool isEmail(this string input)
		{
			var match = Regex.Match(input,
			  @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", RegexOptions.IgnoreCase);
			return match.Success;
		}

		public static bool isNumber(this string input)
		{
			var match = Regex.Match(input, @"^[0-9]+$", RegexOptions.IgnoreCase);
			return match.Success;
		}

		/// <summary>Determina si un dato se puede Convertir a Numero.</summary>
		/// <param name="pValor">Valor a comprobar.</param>
		public static bool IsNumeric(Object pValor)
		{
			if (pValor == null || pValor is DateTime)
				return false;

			if (pValor is Int16 || pValor is Int32 || pValor is Int64 || pValor is Decimal || pValor is Single || pValor is Double || pValor is Boolean)
				return true;

			try
			{
				if (pValor is string)
					Double.Parse(pValor as string);
				else
					Double.Parse(pValor.ToString());
				return true;
			}
			catch { }
			return false;
		}

		public static bool IsDate(this string input)
		{
			if (!string.IsNullOrEmpty(input))
			{
				DateTime dt;
				return (DateTime.TryParse(input, out dt));
			}
			else
			{
				return false;
			}
		}

		public static bool IsUnicode(this string value)
		{
			int asciiBytesCount = System.Text.Encoding.ASCII.GetByteCount(value);
			int unicodBytesCount = System.Text.Encoding.UTF8.GetByteCount(value);

			if (asciiBytesCount != unicodBytesCount)
			{
				return true;
			}
			return false;
		}

		public static string ToUTF8(this string text)
		{
			return Encoding.UTF8.GetString(Encoding.Default.GetBytes(text));
		}

		/// <summary>Determina si la Cadena contiene un valor que se pueda convertir en Boolean.</summary>
		public static bool IsBoolean(this string pTexto)
		{
			var val = pTexto.ToLower().Trim();
			if (val == "false")
				return true;
			if (val == "f")
				return true;
			if (val == "true")
				return true;
			if (val == "t")
				return true;
			if (val == "yes")
				return true;
			if (val == "no")
				return true;
			if (val == "y")
				return true;
			if (val == "n")
				return true;
			if (val == "s")
				return true;
			if (val == "si")
				return true;

			return false;
		}
		/// <summary>Convierte la cadena a Boleano, se pueden convertir los siguientes valores:
		/// 'true/false', 't/f', 'si/no', 'yes/no', 'y/n'  [NO IMPORTAN LAS MAYUSCULAS].</summary>
		public static bool ToBoolean(this string pTexto)
		{
			var val = pTexto.ToLower().Trim();
			if (val == "false")
				return false;
			if (val == "f")
				return false;

			if (val == "true")
				return true;
			if (val == "t")
				return true;

			if (val == "yes")
				return true;
			if (val == "y")
				return true;

			if (val == "no")
				return false;
			if (val == "n")
				return false;

			if (val == "s")
				return true;
			if (val == "si")
				return true;

			return false;
		}


		/// <summary>Devuelve 'true' si la cadena es Nula o Vacia.</summary>
		/// <param name="input">Cadena de Texto a Validar</param>
		public static bool IsNullOrEmpty(this String input)
		{
			bool _ret = true;
			if (input != null && input != string.Empty) _ret = false;
			return _ret;
		}

		/// <summary>Devuelve 'true' si la Cadena es Nula o Vacia.</summary>
		/// <param name="pValor">Cadena de Texto</param>
		public static bool EmptyOrNull(this string pValor)
		{
			bool _ret = true;
			if (pValor != null && pValor != string.Empty) _ret = false;
			return _ret;
		}

		/// <summary>Devuelve un Valor por Defecto si la cadena es Nula o Vacia.</summary>
		/// <param name="str">Cadena de Texto</param>
		/// <param name="defaultValue">Valor x Defecto</param>
		/// <param name="considerWhiteSpaceIsEmpty">Los Espacios se consideran como Vacio?</param>
		public static string DefaultIfEmpty(this string str, string defaultValue, bool considerWhiteSpaceIsEmpty = false)
		{
			return (considerWhiteSpaceIsEmpty ? string.IsNullOrWhiteSpace(str) : string.IsNullOrEmpty(str)) ? defaultValue : str;
		}

		/// <summary>Devuelve un Valor por Defecto si la cadena es Null o Vacia.</summary>
		/// <param name="pTexto">Cadena de Texto</param>
		/// <param name="defaultValue">Valor x Defecto</param>
		/// <param name="considerWhiteSpaceIsEmpty">Los Espacios se consideran como Vacio?</param>
		public static string NVL(this string pTexto, string defaultValue, bool considerWhiteSpaceIsEmpty = false)
		{
			return (considerWhiteSpaceIsEmpty ? string.IsNullOrWhiteSpace(pTexto) : string.IsNullOrEmpty(pTexto)) ? defaultValue : pTexto.Trim();
		}
		public static string NVL(this object pTexto, string defaultValue, bool considerWhiteSpaceIsEmpty = true)
		{
			string _ret = defaultValue;
			if (pTexto != null)
			{
				if (considerWhiteSpaceIsEmpty)
				{
					if (pTexto.ToString().Trim() != string.Empty)
					{
						_ret = pTexto.ToString().Trim();
					}
				}
				else
				{
					_ret = pTexto.ToString();
				}
			}
			return _ret;
		}

		/// <summary>Devuelve un Valor x Defecto si el Valor Indicado es nulo (int.MinValue).</summary>
		/// <param name="defaultValue">[Opcional] Valor x Defecto</param>
		public static int NVL(this int pValor, int defaultValue = 0)
		{
			int _ret = defaultValue;
			if (pValor != int.MinValue) _ret = pValor;
			return _ret;
		}
		/// <summary>Devuelve un Valor x Defecto si el Valor Indicado es nulo (long.MinValue).</summary>
		/// <param name="defaultValue">[Opcional] Valor x Defecto</param>
		public static long NVL(this long pValor, long defaultValue = 0)
		{
			long _ret = defaultValue;
			if (pValor != long.MinValue) _ret = pValor;
			return _ret;
		}
		/// <summary>Devuelve un Valor x Defecto si el Valor Indicado es nulo (decimal.MinValue).</summary>
		/// <param name="defaultValue">[Opcional] Valor x Defecto</param>
		public static decimal NVL(this decimal pValor, decimal defaultValue = 0)
		{
			decimal _ret = defaultValue;
			if (pValor != decimal.MinValue) _ret = pValor;
			return _ret;
		}
		/// <summary>Devuelve un Valor x Defecto si el Valor Indicado es nulo (DateTime.MinValue).</summary>
		/// <param name="defaultValue">[Opcional] Valor x Defecto</param>
		public static DateTime NVL(this DateTime pValor, DateTime defaultValue)
		{
			DateTime _ret = defaultValue;
			if (pValor != DateTime.MinValue) _ret = pValor;
			return _ret;
		}

		/// <summary>Convierte un Valor desde una Escala (Rango) hacia otra escala diferente.</summary>
		/// <param name="_Value">Valor que se quiere convertir</param>
		/// <param name="A_MinValue">Minimo valor posible para el Rango original</param>
		/// <param name="A_MaxValue">Maximo valor posible para el Rango original</param>
		/// <param name="B_MinValue">Minimo valor posible para el Rango Destino</param>
		/// <param name="B_MaxValue">Maximo valor posible para el Rango Destino</param>
		public static decimal NormalizeValue(decimal _Value,
			decimal A_MinValue = 0, decimal A_MaxValue = 1,
			decimal B_MinValue = 0, decimal B_MaxValue = 10)
		{
			decimal _ret = 0;
			if (B_MaxValue > B_MinValue && A_MaxValue > A_MinValue)
			{
				_ret = (B_MaxValue - B_MinValue) / (A_MaxValue - A_MinValue) * (_Value - A_MaxValue) + B_MaxValue;
			}
			if (_ret < B_MinValue) _ret = B_MinValue;
			if (_ret > B_MaxValue) _ret = B_MaxValue;
			return _ret;
		}


		#endregion

		#region Numericos

		/// <summary>Trata de convertir una cadena de texto a un valor numerico entero.</summary>
		/// <param name="input">Texto a convertir</param>
		/// <param name="throwExceptionIfFailed"></param>
		public static int ToInteger(this string input, bool throwExceptionIfFailed = false)
		{
			int result;
			var valid = int.TryParse(LimpiarFormato(input), out result);
			if (!valid)
				if (throwExceptionIfFailed)
					throw new FormatException(string.Format("'{0}' cannot be converted as int", input));
			return result;
		}

		/// <summary>Trata de convertir una cadena de texto a un valor numerico entero.</summary>
		/// <param name="input">Texto a convertir</param>
		/// <param name="throwExceptionIfFailed"></param>
		public static long ToLong(this string input, bool throwExceptionIfFailed = false)
		{
			long result;
			var valid = long.TryParse(LimpiarFormato(input), out result);
			if (!valid)
				if (throwExceptionIfFailed)
					throw new FormatException(string.Format("'{0}' cannot be converted as int", input));
			return result;
		}

		/// <summary>Convierte una Cadena de Texto a su representacion Numerica Decimal.</summary>
		/// <param name="input">Texto a convertir</param>
		/// <param name="throwExceptionIfFailed"></param>
		public static decimal ToDecimal(this string input, bool throwExceptionIfFailed = false)
		{
			decimal result;
			var valid = decimal.TryParse(input, System.Globalization.NumberStyles.AllowDecimalPoint,
			  new System.Globalization.NumberFormatInfo { NumberDecimalSeparator = "." }, out result);
			if (!valid)
				if (throwExceptionIfFailed)
					throw new FormatException(string.Format("'{0}' cannot be converted as decimal", input));
			return result;
		}


		/// <summary>Genera Numeros Enteros Consecutivos en el Rango especificado.</summary>
		/// <param name="MinValue">Valor menor del Rango.</param>
		/// <param name="MaxValue">Valor Mayor del Rango.</param>
		public static List<int> NumerosEnRango(this Int32 MinValue, Int32 MaxValue)
		{
			List<int> _ret = new List<int>();
			try
			{
				int inicio = IIf(MaxValue > MinValue, MinValue, MaxValue);
				int final = IIf(MaxValue > MinValue, MaxValue, MinValue);

				for (int i = inicio; i <= final; i++)
				{
					_ret.Add(i);
				}
			}
			catch { }
			return _ret;
		}

		/// <summary>Generador de numeros aleatorios.
		/// Al ser declarado a nivel de clase, mejora la calidad de los numeros aleatorios generados.</summary>
		private static Random RND = new Random();

		/// <summary>Obtiene un Número aleatorio.
		/// Si el Numero Base es Diferente a Cero se usará como Semilla.</summary>
		/// <param name="Numero">(Seed) Un número usado para calcular un valor inicial para la secuencia numérica pseudoaleatoria. Si se especifica un número negativo, se usa el valor absoluto del número.</param>
		public static int RandomNumber(this Int32 Numero)
		{
			int _ret = 0;
			try
			{
				if (Numero != 0)
				{
					_ret = new Random(Numero).Next();
				}
				else
				{
					_ret = RND.Next();
				}
			}
			catch { }
			return _ret;
		}

		/// <summary>Obtiene un Número aleatorio entre 0.0 y 1.0
		/// Si el Numero Base es Diferente a Cero se usará como Semilla.
		/// Ejem: double DD = new double().RandomNumber();</summary>
		/// <param name="Numero">(Seed) Un número usado para calcular un valor inicial para la secuencia numérica pseudoaleatoria. Si se especifica un número negativo, se usa el valor absoluto del número.</param>
		public static double RandomNumber(this Double Numero)
		{
			double _ret = 0;
			try
			{
				if (Numero > 0)
				{
					_ret = new Random(Convert.ToInt32(Numero)).NextDouble();
				}
				else
				{
					_ret = RND.NextDouble();
				}
			}
			catch { }
			return _ret;
		}

		/// <summary>Obtiene un Número aleatorio entre el Rango especificado.
		/// Si el Numero Base es Diferente a Cero se usará como Semilla.
		/// Ejem: int G = new Int32().RandomBetween(0, 10);</summary>
		/// <param name="Numero">(Seed) Un número usado para calcular un valor inicial para la secuencia numérica pseudoaleatoria. Si se especifica un número negativo, se usa el valor absoluto del número.</param>
		/// <param name="MinValue">Valor Minimo del Rango</param>
		/// <param name="MaxValue">Valor Maximo del Rango</param>
		public static int RandomBetween(this Int32 Numero, int MinValue, int MaxValue)
		{
			int _ret = 0;
			try
			{
				if (Numero != 0)
				{
					_ret = new Random(Numero).Next(MinValue, MaxValue + 1);
				}
				else
				{
					_ret = RND.Next(MinValue, MaxValue + 1); //<- MaxValue No es Inclusivo
				}
			}
			catch { }
			return _ret;
		}

		/// <summary>Obtiene un Número aleatorio entre el Rango especificado.
		/// Si el Numero Base es Diferente a Cero se usará como Semilla.
		/// Ejem: double D = new double().RandomBetween(1, 10);</summary>
		/// <param name="Numero">(Seed) Un número usado para calcular un valor inicial para la secuencia numérica pseudoaleatoria. Si se especifica un número negativo, se usa el valor absoluto del número.</param>
		/// <param name="MinValue">Valor Minimo del Rango</param>
		/// <param name="MaxValue">Valor Maximo del Rango</param>
		public static double RandomBetween(this Double Numero, int MinValue, int MaxValue)
		{
			double _ret = 0;
			try
			{
				if (Numero != 0)
				{
					_ret = new Random(Convert.ToInt32(Numero)).NextDouble() * MaxValue;
				}
				else
				{
					_ret = RND.NextDouble() * MaxValue; //<- MaxValue No es Inclusivo
				}
			}
			catch { }
			return _ret;
		}

		/// <summary>Reordena al Azar la lista de elementos.</summary>
		/// <typeparam name="T">Cualquier tipo de Objeto.</typeparam>
		/// <param name="list">Lista de elementos a reordenar.</param>
		public static void RandomizeOrder<T>(this IList<T> list)
		{
			int n = list.Count;
			while (n > 1)
			{
				n--;
				int k = RND.Next(n + 1);
				T value = list[k];
				list[k] = list[n];
				list[n] = value;
			}
		}

		#endregion

		#region Fechas

		/// <summary>Convierte una cadena de texto a Fecha.</summary>
		/// <param name="input">Texto a Convertir</param>
		/// <param name="throwExceptionIfFailed"></param>
		public static DateTime ToDate(this string input, bool throwExceptionIfFailed = false)
		{
			DateTime result;
			var valid = DateTime.TryParse(input, out result);
			if (!valid)
				if (throwExceptionIfFailed)
					throw new FormatException(string.Format("'{0}' cannot be converted as DateTime", input));
			return result;
		}

		/// <summary>Determina si el valor de la Variable se encuentra dentro del Rango especificado.</summary>
		/// <typeparam name="T">Tipo de Datos del  Objeto</typeparam>
		/// <param name="Valor">Valor (Fecha) a comparar.</param>
		/// <param name="Desde">Rango Inicial</param>
		/// <param name="Hasta">Rango final</param>
		public static bool Between(this DateTime Fecha, DateTime Inicio, DateTime Final)
		{
			return Fecha.Ticks >= Inicio.Ticks && Fecha.Ticks <= Final.Ticks;
		}

		/// <summary>Compara la Fecha con el dia actual y Convierte la diferencia en un texto humanamente leible.</summary>
		/// <param name="value">Fecha a Convertir</param>
		public static string ToReadableTime(this DateTime value)
		{
			string _ret = string.Empty;
			string _prefix = string.Empty;
			var ts = new TimeSpan(DateTime.Now.Ticks - value.Ticks);

			if (value < DateTime.Now) //<- Fecha Anterior a Hoy
			{
				_prefix = "hace";
				ts = DateTime.Now.Subtract(value); //<- Tiempo Transcurrido    
			}
			else
			{
				_prefix = "dentro de";
				ts = value.Subtract(DateTime.Now); //<- Tiempo Transcurrido      
			}

			double delta = Math.Abs(ts.TotalSeconds);
			if (delta > 31104000) // 12 * 30 * 24 * 60 * 60
			{
				var years = Convert.ToInt32(Math.Floor((double)ts.Days / 365));
				_ret = years <= 1 ? string.Format("{0} un año", _prefix) : string.Format("{0} {1} años", _prefix, years);
			}
			if (delta <= 31104000) // 12 * 30 * 24 * 60 * 60
			{
				int months = Convert.ToInt32(Math.Floor((double)ts.Days / 30));
				_ret = months <= 1 ? string.Format("{0} un mes", _prefix) : string.Format("{0} {1} meses", _prefix, months);
			}
			if (delta < 2592000) // 30 * 24 * 60 * 60
			{
				_ret = string.Format("{0} {1} días", _prefix, ts.Days);
			}
			if (delta < 172800) // 48 * 60 * 60
			{
				_ret = "Ayer";
			}
			if (delta < 86400) // 24 * 60 * 60
			{
				_ret = "Hoy";
			}
			if (delta < 43200) // 12 * 60 * 60
			{
				_ret = string.Format("{0} {1} horas", _prefix, ts.Hours);
			}
			if (delta < 5400) // 90 * 60
			{
				_ret = string.Format("{0} una hora", _prefix);
			}
			if (delta < 2700) // 45 * 60
			{
				_ret = string.Format("{0} {1} minutos", _prefix, ts.Minutes);
			}
			if (delta < 2100) // 30 * 60
			{
				_ret = string.Format("{0} media hora", _prefix);
			}
			if (delta < 1300) // 15 * 60
			{
				_ret = string.Format("{0} {1} minutos", _prefix, ts.Minutes);
			}
			if (delta < 420) //7 * 60  
			{
				_ret = string.Format("{0} 5 minutos", _prefix);
			}
			if (delta < 180) //3 * 60  <- 3 minutos
			{
				_ret = string.Format("{0} {1} minutos", _prefix, ts.Minutes);
			}
			if (delta < 90) //1 minuto 
			{
				_ret = string.Format("{0} un minuto", _prefix);
			}
			if (delta < 40) //30 segundos
			{
				_ret = string.Format("{0} {1} segundos", _prefix, ts.Seconds);
			}
			if (delta < 20) //20 segundos
			{
				_ret = string.Format("{0} un momento", _prefix);
			}
			return _ret;
		}

		public static bool IsNull(this DateTime date)
		{
			//Determina si la fecha indicada es Nula (Usamos MinValue para las Fechas Nulas)
			if (date != DateTime.MinValue)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		public static bool IsWorkingDay(this DateTime date)
		{
			//Determina si la fecha indicada es un dia laborable
			return date.DayOfWeek != DayOfWeek.Saturday && date.DayOfWeek != DayOfWeek.Sunday;
		}
		public static bool IsWeekend(this DateTime date)
		{
			//Determina si la Fecha indicada es en un fin de semana
			return date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday;
		}
		public static DateTime NextWorkday(this DateTime date)
		{
			//Devuelve la Fecha del siguiente dia laborable
			var nextDay = date;
			while (!nextDay.IsWorkingDay())
			{
				nextDay = nextDay.AddDays(1);
			}
			return nextDay;
		}

		/// <summary>Obtiene el nombre del Dia de la Semana para la Fecha Indicada.</summary>
		public static string GetDayName(this DateTime date)
		{
			string _ret = string.Empty; //para .NET Framework 4++
			var culture = new System.Globalization.CultureInfo("es-419"); //<- 'es-419' = Spanish (Latin America), 'es-UY' = Spanish (Uruguay)
			_ret = culture.DateTimeFormat.GetDayName(date.DayOfWeek);
			//Convierte el texto a Mayuscula Inicial
			System.Globalization.TextInfo textInfo = culture.TextInfo;
			_ret = textInfo.ToTitleCase(_ret.ToLower());
			return _ret;
		}

		/// <summary>Obtiene el nombre del Mes para la Fecha Indicada.</summary>
		public static string GetMonthName(this DateTime date)
		{
			string _ret = string.Empty; //para .NET Framework 4++
			var culture = new System.Globalization.CultureInfo("es-419"); //<- 'es-419' = Spanish (Latin America), 'es-UY' = Spanish (Uruguay)
			_ret = culture.DateTimeFormat.GetMonthName(date.Month);
			//Convierte el texto a Mayuscula Inicial
			System.Globalization.TextInfo textInfo = culture.TextInfo;
			_ret = textInfo.ToTitleCase(_ret.ToLower());
			return _ret;
		}

		/// <summary>Carga los Feriados (Estaticos) Uruguayos para el Año de la Fecha indicada.</summary>
		/// <param name="date">Fecha Indicada</param>
		public static List<DateTime> CargarFeriados(this DateTime date)
		{
			List<DateTime> _ret = new List<DateTime>();

			_ret.Add(new DateTime(date.Year, 1, 1)); //<- Año Nuevo
			_ret.Add(new DateTime(date.Year, 1, 6)); //<- Dia de Reyes

			//Agregar la Semana Santa:
			DateTime Pascua = DomingoPascua(date.Year);
			_ret.Add(Pascua.AddDays(-3));   //<- Jueves Santo
			_ret.Add(Pascua.AddDays(-2));   //<- Viernes Santo
			_ret.Add(Pascua);               //<- Domingo de Pascua

			_ret.Add(new DateTime(date.Year, 4, 22)); //<- Desembarco de los 33 orientales
			_ret.Add(new DateTime(date.Year, 5, 1)); //<- Día de los Trabajadores
			_ret.Add(new DateTime(date.Year, 5, 18)); //<- Batalla de las Piedras
			_ret.Add(new DateTime(date.Year, 6, 19)); //<- Natalicio de Artigas
			_ret.Add(new DateTime(date.Year, 7, 18)); //<- Día de la Constitución
			_ret.Add(new DateTime(date.Year, 8, 25)); //<- Día de la Independencia
			_ret.Add(new DateTime(date.Year, 10, 12)); //<- Día de la Raza
			_ret.Add(new DateTime(date.Year, 11, 2)); //<-Día de los Difuntos
			_ret.Add(new DateTime(date.Year, 12, 25)); //<- Navidad

			return _ret;
		}

		#region Calcula la Semana Santa

		private struct ParConstantes
		{
			public int M { get; set; }
			public int N { get; set; }
		}
		private static DateTime DomingoPascua(int anio)
		{
			DateTime pascuaResurreccion;
			int a, b, c, d, e;

			ParConstantes p = new ParConstantes();
			if (anio < 1583)
			{
				throw new ArgumentOutOfRangeException("El año deberá ser superior a 1583");
			}
			else if (anio < 1700) { p.M = 22; p.N = 2; }
			else if (anio < 1800) { p.M = 23; p.N = 3; }
			else if (anio < 1900) { p.M = 23; p.N = 4; }
			else if (anio < 2100) { p.M = 24; p.N = 5; }
			else if (anio < 2200) { p.M = 24; p.N = 6; }
			else if (anio < 2299) { p.M = 25; p.N = 0; }
			else
			{
				throw new ArgumentOutOfRangeException("El año deberá ser inferior a 2299");
			}

			a = anio % 19;
			b = anio % 4;
			c = anio % 7;
			d = (19 * a + p.M) % 30;
			e = (2 * b + 4 * c + 6 * d + p.N) % 7;

			if (d + e < 10)
				pascuaResurreccion = new DateTime(anio, 3, d + e + 22);
			else
				pascuaResurreccion = new DateTime(anio, 4, d + e - 9);

			// Excepciones
			if (pascuaResurreccion == new DateTime(anio, 4, 26))
				pascuaResurreccion = new DateTime(anio, 4, 19);

			if (pascuaResurreccion == new DateTime(anio, 4, 25)
					&& d == 28 && e == 6 && a > 10)
				pascuaResurreccion = new DateTime(anio, 4, 18);

			return pascuaResurreccion;
		}
		#endregion

		#endregion

		#endregion

		#region Manejo de Archivos

		/// <summary>Constantes para los Codigos de Pagina al leer o guardar archivos de texto.</summary>
		public enum TextEncoding
		{
			/// <summary>CodePage:1252; windows-1252 ANSI Latin 1; Western European (Windows)</summary>
			ANSI = 1252,
			/// <summary>CodePage:850; ibm850; ASCII Multilingual Latin 1; Western European (DOS)</summary>
			DOS_850 = 850,
			/// <summary>CodePage:1200; utf-16; Unicode UTF-16, little endian byte order (BMP of ISO 10646);</summary>
			Unicode = 1200,
			/// <summary>CodePage:65001; utf-8; Unicode (UTF-8)</summary>
			UTF8 = 65001
		}

		/// <summary>Guarda Datos en un Archivo de Texto usando la Codificacion especificada.</summary>
		/// <param name="FilePath">Ruta de acceso al Archivo. Si no existe, se Crea. Si existe, se Sobreescribe.</param>
		/// <param name="Data">Datos a Grabar en el Archivo.</param>
		/// <param name="CodePage">[Opcional] Pagina de Codigos con la que se guarda el archivo. Por defecto se usa Unicode(UTF-16).</param>
		public static bool SaveTextFile(string FilePath, string Data, TextEncoding CodePage = TextEncoding.UTF8)
		{
			bool _ret = false;
			try
			{
				if (FilePath != null && FilePath != string.Empty)
				{
					/* ANSI code pages, like windows-1252, can be different on different computers, 
					 * or can be changed for a single computer, leading to data corruption. 
					 * For the most consistent results, applications should use UNICODE, 
					 * such as UTF-8 or UTF-16, instead of a specific code page. 
					 https://docs.microsoft.com/es-es/windows/desktop/Intl/code-page-identifiers  */

					System.Text.Encoding ENCODING = System.Text.Encoding.GetEncoding((int)CodePage); //<- Unicode Garantiza Maxima compatibilidad
					using (System.IO.FileStream FILE = new System.IO.FileStream(FilePath, System.IO.FileMode.Create))
					{
						if (CodePage == TextEncoding.UTF8) ENCODING = new UTF8Encoding(false); //<- UTF8 sin BOM

						using (System.IO.StreamWriter WRITER = new System.IO.StreamWriter(FILE, ENCODING))
						{
							WRITER.Write(Data);
							WRITER.Close();
						}
					}
					if (System.IO.File.Exists(FilePath)) _ret = true;
				}
			}
			catch (Exception ex) { throw ex; }
			return _ret;
		}

		/// <summary>Lee un Archivo de Texto usando la Codificacion especificada.</summary>
		/// <param name="FilePath">Ruta de acceso al Archivo. Si no existe se produce un Error.</param>
		/// <param name="CodePage">[Opcional] Pagina de Codigos con la que se Leerá el archivo. Por defecto se usa UTF-8.</param>
		public static string ReadTextFile(string FilePath, TextEncoding CodePage = TextEncoding.UTF8)
		{
			string _ret = string.Empty;
			try
			{
				if (FilePath != null && FilePath != string.Empty)
				{
					if (System.IO.File.Exists(FilePath))
					{
						System.Text.Encoding ENCODING = System.Text.Encoding.GetEncoding((int)CodePage);
						//_ret = System.IO.File.ReadAllText(FilePath, ENCODING);

						//Abre el archivo sin Bloquearlo:
						using (FileStream fs = new FileStream(FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
						{
							using (StreamReader sr = new StreamReader(fs, ENCODING))
							{
								_ret = sr.ReadToEnd();

								//while (!sr.EndOfStream)
								//{
								//	string line = sr.ReadLine();									
								//}
							}
						}

					}
					else { throw new Exception(string.Format("ERROR 404: Archivo '{0}' NO Encontrado!", FilePath)); }
				}
				else { throw new Exception("No se ha Especificado la Ruta de acceso al Archivo!"); }
			}
			catch (Exception ex) { throw ex; }
			return _ret;
		}

		/// <summary>Guarda un array de bytes en un archivo.</summary>
		/// <param name="fileBytes">Datos a Guradar.</param>
		/// <param name="fileName">Ruta completa del Archivo.</param>
		public static void SaveFile(byte[] fileBytes, string fileName)
		{
			File.WriteAllBytes(fileName, fileBytes);
		}

		/// <summary>Convierte el tamaño de un archivo a la unidad más adecuada.</summary>
		/// <param name="pFileBytes">Tamaño del Archivo en Bytes</param>
		/// <returns>"0.### XB", ejem. "4.2 KB" or "1.434 GB"</returns>
		public static string GetFileSize(long pFileBytes)
		{
			// Get absolute value
			long absolute_i = (pFileBytes < 0 ? -pFileBytes : pFileBytes);
			// Determine the suffix and readable value
			string suffix;
			double readable;
			if (absolute_i >= 0x1000000000000000) // Exabyte
			{
				suffix = "EB";
				readable = (pFileBytes >> 50);
			}
			else if (absolute_i >= 0x4000000000000) // Petabyte
			{
				suffix = "PB";
				readable = (pFileBytes >> 40);
			}
			else if (absolute_i >= 0x10000000000) // Terabyte
			{
				suffix = "TB";
				readable = (pFileBytes >> 30);
			}
			else if (absolute_i >= 0x40000000) // Gigabyte
			{
				suffix = "GB";
				readable = (pFileBytes >> 20);
			}
			else if (absolute_i >= 0x100000) // Megabyte
			{
				suffix = "MB";
				readable = (pFileBytes >> 10);
			}
			else if (absolute_i >= 0x400) // Kilobyte
			{
				suffix = "KB";
				readable = pFileBytes;
			}
			else
			{
				return pFileBytes.ToString("0 B"); // Byte
			}

			readable = System.Math.Round((readable / 1024), 2);
			return string.Format("{0:n1} {1}", readable, suffix);
		}

		/// <summary>Verifica la conexión a un servidor pingeandolo.</summary>
		/// <param name="pServerAddress">Dirección del Servidor.</param>
		public static bool PingServer(string pServerAddress)
		{
			bool _ret = false;
			try
			{
				System.Net.NetworkInformation.PingReply pingReply;
				using (var ping = new System.Net.NetworkInformation.Ping())
					pingReply = ping.Send(pServerAddress);

				var available = pingReply.Status == System.Net.NetworkInformation.IPStatus.Success;
				_ret = Convert.ToBoolean(available);
			}
			catch { }
			return _ret;
		}


		/// <summary>OBTIENE LA LISTA DE TODOS LOS ARCHIVOS Y SUB-DIRECTORIOS DENTRO DE LA RUTA ESPECIFICADA.
		/// Cada resultado incluye la ruta completa de cada archivo. </summary>
		/// <param name="path">Carpeta donde Buscar</param>
		/// <param name="searchPattern">puede ser '*.*' o '*.jpg'</param>
		/// <param name="searchOption"></param>
		public static IEnumerable<string> GetXFiles(string path, string searchPattern, SearchOption searchOption)
		{
			/* Sólo para .NET 4.5+  
			 * OBTIENE LA LISTA DE TODOS LOS ARCHIVOS Y SUB-DIRECTORIOS DENTRO DE LA RUTA ESPECIFICADA
			 */
			var foldersToProcess = new List<string>()
			{
				path
			};

			while (foldersToProcess.Count > 0)
			{
				string folder = foldersToProcess[0];
				foldersToProcess.RemoveAt(0);

				if (searchOption.HasFlag(SearchOption.AllDirectories))
				{
					//get subfolders
					try
					{
						var subfolders = Directory.GetDirectories(folder);
						foldersToProcess.AddRange(subfolders);
					}
					catch 
					{
						//log if you're interested
					}
				}

				//get files
				var files = new List<string>();
				try
				{
					files = Directory.GetFiles(folder, searchPattern, SearchOption.TopDirectoryOnly).ToList();
				}
				catch (Exception ex)
				{
					//log if you're interested
				}

				foreach (var file in files)
				{
					yield return file;
				}
			}
		}

		/// <summary>Obtiene la Ruta Relativa del Archivo. (Solo el nombre de las Carpetas)</summary>
		/// <param name="FilePath">Ruta Completa del Archivo</param>
		/// <param name="RootPath">Ruta del Directorio Padre</param>
		public static String GetRelativeFolder(string FilePath, string RootPath)
		{
			/* Si el archivo está en la Raiz, devuelve 'string.Empty', si hay varios niveles, devuelve 'Carpeta_1\Carpeta_2' */
			string _ret = string.Empty;
			try
			{
				string _PathOnly = System.IO.Path.GetDirectoryName(FilePath);
				_ret = _PathOnly.Replace(RootPath, string.Empty);
				if (_ret != string.Empty)
				{
					_ret = _ret.Remove(0, 1);
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return _ret;
		}


		#endregion

		#region AppConfig

		/// <summary>Obtiene el Valor de una Clave guardada en el archivo 'App.config', en la Seccion 'appSettings'.</summary>
		/// <param name="Key">Nombre de la Clave que tiene el Valor</param>
		public static string AppConfig_GetValue(string Key)
		{
			string _ret = string.Empty;
			try
			{
				_ret = System.Configuration.ConfigurationManager.AppSettings[Key];
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return _ret;
		}

		/// <summary>Guarda un Valor en una Clave de el archivo 'App.config', en la Seccion 'appSettings'.</summary>
		/// <param name="Key">Nombre de la Clave que tiene el Valor</param>
		/// <param name="Value">Valor a Guardar</param>
		public static bool AppConfig_SetValue(string Key, string Value)
		{
			bool _ret = false;
			try
			{
				System.Configuration.Configuration config =
					System.Configuration.ConfigurationManager.OpenExeConfiguration(
						System.Configuration.ConfigurationUserLevel.None);

				config.AppSettings.Settings[Key].Value = Value;
				config.Save(System.Configuration.ConfigurationSaveMode.Modified);

				System.Configuration.ConfigurationManager.RefreshSection("appSettings");
				_ret = true;
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return _ret;
		}

		#endregion

		public static String HexConverter(System.Drawing.Color c)
		{
			return "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
		}

		public static String RGBConverter(System.Drawing.Color c)
		{
			return c.R.ToString() + "," + c.G.ToString() + "," + c.B.ToString();
		}

		public static T DeSerialize_FromJSON<T>(string filePath) where T : new()
		{
			/* EJEMPLO:  inventario _JSON = Util.DeSerialize_FromJSON_String<inventario>(Inventario_JSON);  */
			/* List<string> videogames = JsonConvert.DeserializeObject<List<string>>(json); */

			try
			{
				if (!filePath.EmptyOrNull())
				{
					if (System.IO.File.Exists(filePath))
					{
						using (TextReader reader = new StreamReader(filePath))
						{
							var fileContents = reader.ReadToEnd(); reader.Close();
							return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(fileContents);
						}
					}
					else
					{
						return default(T); //<- Si el Archivo NO Existe, les devuelvo un Objeto Vacio.
					}
				}
				else
				{
					return default(T); //<- Si me pasan un JSON vacio, les devuelvo un Objeto Vacio.
				}
			}
			finally { }
		}

		/// <summary>Serializa y escribe el objeto indicado en un archivo JSON.
		/// <para>La Clase a Serializar DEBE tener un Constructor sin parametros.</para>
		/// <para>Only Public properties and variables will be written to the file. These can be any type, even other classes.</para>
		/// <para>If there are public properties/variables that you do not want written to the file, decorate them with the [JsonIgnore] attribute.</para>
		/// </summary>
		/// <typeparam name="T">El tipo de Objeto a guardar en el Archivo.</typeparam>
		/// <param name="filePath">Ruta completa al archivo donde se guardará el JSON.</param>
		/// <param name="objectToWrite">Instancia del Objeto a Serializar</param>
		/// <param name="append">'false'=Sobre-Escribe el Archivo, 'true'=Añade datos al final del archivo.</param>
		public static string Serialize_ToJSON<T>(string filePath, T objectToWrite, bool append = false) where T : new()
		{
			/* EJEMPLO:  string _JsonString = Util.Serialize_ToJSON(System.IO.Path.Combine(file_path,_file_name), _Inventario);  */

			string _ret = string.Empty;
			try
			{
				if (!filePath.EmptyOrNull())
				{
					_ret = Newtonsoft.Json.JsonConvert.SerializeObject(objectToWrite);
					using (System.IO.TextWriter writer = new System.IO.StreamWriter(filePath, append))
					{
						writer.Write(_ret);
						writer.Close();
					};
				}
			}
			catch { }
			return _ret;
		}
	}

	static class GraphicsExtension
	{
		private static GraphicsPath GenerateRoundedRectangle(
			this Graphics graphics,
			RectangleF rectangle,
			float radius)
		{
			float diameter;
			GraphicsPath path = new GraphicsPath();
			if (radius <= 0.0F)
			{
				path.AddRectangle(rectangle);
				path.CloseFigure();
				return path;
			}
			else
			{
				if (radius >= (Math.Min(rectangle.Width, rectangle.Height)) / 2.0)
					return graphics.GenerateCapsule(rectangle);
				diameter = radius * 2.0F;
				SizeF sizeF = new SizeF(diameter, diameter);
				RectangleF arc = new RectangleF(rectangle.Location, sizeF);
				path.AddArc(arc, 180, 90);
				arc.X = rectangle.Right - diameter;
				path.AddArc(arc, 270, 90);
				arc.Y = rectangle.Bottom - diameter;
				path.AddArc(arc, 0, 90);
				arc.X = rectangle.Left;
				path.AddArc(arc, 90, 90);
				path.CloseFigure();
			}
			return path;
		}
		private static GraphicsPath GenerateCapsule(
			this Graphics graphics,
			RectangleF baseRect)
		{
			float diameter;
			RectangleF arc;
			GraphicsPath path = new GraphicsPath();
			try
			{
				if (baseRect.Width > baseRect.Height)
				{
					diameter = baseRect.Height;
					SizeF sizeF = new SizeF(diameter, diameter);
					arc = new RectangleF(baseRect.Location, sizeF);
					path.AddArc(arc, 90, 180);
					arc.X = baseRect.Right - diameter;
					path.AddArc(arc, 270, 180);
				}
				else if (baseRect.Width < baseRect.Height)
				{
					diameter = baseRect.Width;
					SizeF sizeF = new SizeF(diameter, diameter);
					arc = new RectangleF(baseRect.Location, sizeF);
					path.AddArc(arc, 180, 180);
					arc.Y = baseRect.Bottom - diameter;
					path.AddArc(arc, 0, 180);
				}
				else path.AddEllipse(baseRect);
			}
			catch { path.AddEllipse(baseRect); }
			finally { path.CloseFigure(); }
			return path;
		}

		/// <summary>
		/// Draws a rounded rectangle specified by a pair of coordinates, a width, a height and the radius 
		/// for the arcs that make the rounded edges.
		/// </summary>
		/// <param name="brush">System.Drawing.Pen that determines the color, width and style of the rectangle.</param>
		/// <param name="x">The x-coordinate of the upper-left corner of the rectangle to draw.</param>
		/// <param name="y">The y-coordinate of the upper-left corner of the rectangle to draw.</param>
		/// <param name="width">Width of the rectangle to draw.</param>
		/// <param name="height">Height of the rectangle to draw.</param>
		/// <param name="radius">The radius of the arc used for the rounded edges.</param>

		public static void DrawRoundedRectangle(
			this Graphics graphics,
			Pen pen,
			float x,
			float y,
			float width,
			float height,
			float radius)
		{
			RectangleF rectangle = new RectangleF(x, y, width, height);
			GraphicsPath path = graphics.GenerateRoundedRectangle(rectangle, radius);
			SmoothingMode old = graphics.SmoothingMode;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.DrawPath(pen, path);
			graphics.SmoothingMode = old;
		}

		/// <summary>
		/// Draws a rounded rectangle specified by a pair of coordinates, a width, a height and the radius 
		/// for the arcs that make the rounded edges.
		/// </summary>
		/// <param name="brush">System.Drawing.Pen that determines the color, width and style of the rectangle.</param>
		/// <param name="x">The x-coordinate of the upper-left corner of the rectangle to draw.</param>
		/// <param name="y">The y-coordinate of the upper-left corner of the rectangle to draw.</param>
		/// <param name="width">Width of the rectangle to draw.</param>
		/// <param name="height">Height of the rectangle to draw.</param>
		/// <param name="radius">The radius of the arc used for the rounded edges.</param>

		public static void DrawRoundedRectangle(
			this Graphics graphics,
			Pen pen,
			int x,
			int y,
			int width,
			int height,
			int radius)
		{
			graphics.DrawRoundedRectangle(
				pen,
				Convert.ToSingle(x),
				Convert.ToSingle(y),
				Convert.ToSingle(width),
				Convert.ToSingle(height),
				Convert.ToSingle(radius));
		}

		/// <summary>
		/// Fills the interior of a rounded rectangle specified by a pair of coordinates, a width, a height
		/// and the radius for the arcs that make the rounded edges.
		/// </summary>
		/// <param name="brush">System.Drawing.Brush that determines the characteristics of the fill.</param>
		/// <param name="x">The x-coordinate of the upper-left corner of the rectangle to fill.</param>
		/// <param name="y">The y-coordinate of the upper-left corner of the rectangle to fill.</param>
		/// <param name="width">Width of the rectangle to fill.</param>
		/// <param name="height">Height of the rectangle to fill.</param>
		/// <param name="radius">The radius of the arc used for the rounded edges.</param>

		public static void FillRoundedRectangle(
			this Graphics graphics,
			Brush brush,
			float x,
			float y,
			float width,
			float height,
			float radius)
		{
			RectangleF rectangle = new RectangleF(x, y, width, height);
			GraphicsPath path = graphics.GenerateRoundedRectangle(rectangle, radius);
			SmoothingMode old = graphics.SmoothingMode;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.FillPath(brush, path);
			graphics.SmoothingMode = old;
		}

		/// <summary>
		/// Fills the interior of a rounded rectangle specified by a pair of coordinates, a width, a height
		/// and the radius for the arcs that make the rounded edges.
		/// </summary>
		/// <param name="brush">System.Drawing.Brush that determines the characteristics of the fill.</param>
		/// <param name="x">The x-coordinate of the upper-left corner of the rectangle to fill.</param>
		/// <param name="y">The y-coordinate of the upper-left corner of the rectangle to fill.</param>
		/// <param name="width">Width of the rectangle to fill.</param>
		/// <param name="height">Height of the rectangle to fill.</param>
		/// <param name="radius">The radius of the arc used for the rounded edges.</param>

		public static void FillRoundedRectangle(
			this Graphics graphics,
			Brush brush,
			int x,
			int y,
			int width,
			int height,
			int radius)
		{
			graphics.FillRoundedRectangle(
				brush,
				Convert.ToSingle(x),
				Convert.ToSingle(y),
				Convert.ToSingle(width),
				Convert.ToSingle(height),
				Convert.ToSingle(radius));
		}
	}

	public class FileAssociation
	{
		public string Extension { get; set; }
		public string ProgId { get; set; }
		public string FileTypeDescription { get; set; }
		public string ExecutableFilePath { get; set; }
	}

	public static class FileAssociations
	{
		[DllImport("shell32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

		private const int SHCNE_ASSOCCHANGED = 0x8000000;
		private const int SHCNF_FLUSH = 0x1000;


		public static void SetAssociation_User(string Extension, string OpenWith, string ExecutableName)
		{
			try
			{
				using (RegistryKey User_Classes = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Classes\\", true))
				using (RegistryKey User_Ext = User_Classes.CreateSubKey("." + Extension))
				using (RegistryKey User_AutoFile = User_Classes.CreateSubKey(Extension + "_auto_file"))
				using (RegistryKey User_AutoFile_Command = User_AutoFile.CreateSubKey("shell").CreateSubKey("open").CreateSubKey("command"))
				using (RegistryKey ApplicationAssociationToasts = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\ApplicationAssociationToasts\\", true))
				using (RegistryKey User_Classes_Applications = User_Classes.CreateSubKey("Applications"))
				using (RegistryKey User_Classes_Applications_Exe = User_Classes_Applications.CreateSubKey(ExecutableName))
				using (RegistryKey User_Application_Command = User_Classes_Applications_Exe.CreateSubKey("shell").CreateSubKey("open").CreateSubKey("command"))
				using (RegistryKey User_Explorer = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\." + Extension))
				using (RegistryKey User_Choice = User_Explorer.OpenSubKey("UserChoice"))
				{
					User_Ext.SetValue("", Extension + "_auto_file", RegistryValueKind.String);
					User_Classes.SetValue("", Extension + "_auto_file", RegistryValueKind.String);
					User_Classes.CreateSubKey(Extension + "_auto_file");
					User_AutoFile_Command.SetValue("", "\"" + OpenWith + "\"" + " \"%1\"");
					ApplicationAssociationToasts.SetValue(Extension + "_auto_file_." + Extension, 0);
					ApplicationAssociationToasts.SetValue(@"Applications\" + ExecutableName + "_." + Extension, 0);
					User_Application_Command.SetValue("", "\"" + OpenWith + "\"" + " \"%1\"");
					User_Explorer.CreateSubKey("OpenWithList").SetValue("a", ExecutableName);
					User_Explorer.CreateSubKey("OpenWithProgids").SetValue(Extension + "_auto_file", "0");
					if (User_Choice != null) User_Explorer.DeleteSubKey("UserChoice");
					User_Explorer.CreateSubKey("UserChoice").SetValue("ProgId", @"Applications\" + ExecutableName);
				}
				SHChangeNotify(0x08000000, 0x0000, IntPtr.Zero, IntPtr.Zero);
			}
			catch (Exception excpt)
			{
				throw excpt;
			}
		}

		static string SeekExtensionBehaviour(string path, string shellComand)
		{
			//Menu -> Nuevo Archivo
			/*  [HKEY_CLASSES_ROOT\.png\ShellNew] "NullFile"=""  */


			string extension = System.IO.Path.GetExtension(path);
			string command = "not found";

			if (string.IsNullOrWhiteSpace(extension)) return command;

			using (RegistryKey keyExt = Registry.ClassesRoot.OpenSubKey(extension))
			{
				if (keyExt == null) return command;

				var keyRealExt = keyExt.GetValue("");

				if (string.IsNullOrEmpty(keyRealExt.ToString())) return command;

				using (RegistryKey keyReal = Registry.ClassesRoot.OpenSubKey(keyRealExt.ToString()))
				{
					if (keyReal == null) return command;

					string keycommandPath = string.Format(@"shell\{0}\command", shellComand); // New, Open or Edit

					using (RegistryKey keyCommand = keyReal.OpenSubKey(keycommandPath))
					{
						command = keyCommand.GetValue("").ToString();
					}
				}
			}

			return command; // "C:\Program Files (x86)\Microsoft Office\Root\Office16\WINWORD.EXE" /n "%1" /o "%u"
		}

		public static void EnsureAssociationsSet()
		{
			var filePath = Process.GetCurrentProcess().MainModule.FileName;
			EnsureAssociationsSet(
				new FileAssociation
				{
					Extension = ".ucs",
					ProgId = "UCS_Editor_File",
					FileTypeDescription = "UCS File",
					ExecutableFilePath = filePath
				});
		}

		public static void ContextMenu_NewTextFile()
		{
			try
			{
				/*[HKEY_CLASSES_ROOT\.txt]
				@="textfile"

				[HKEY_CLASSES_ROOT\.txt\ShellNew]
				"NullFile"=""

				[HKEY_CLASSES_ROOT\textfile]
				@="Text Document"*/

				Registry.ClassesRoot.SetValue(@".txt\@", "textfile");
				Registry.ClassesRoot.SetValue(@".txt\ShellNew\NullFile", "");
				Registry.ClassesRoot.SetValue(@".txt\ShellNew\FileName", "");
				Registry.ClassesRoot.SetValue(@"textfile\@", "Text File");
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public static void EnsureAssociationsSet(params FileAssociation[] associations)
		{
			bool madeChanges = false;
			foreach (var association in associations)
			{
				madeChanges |= SetAssociation(
					association.Extension,
					association.ProgId,
					association.FileTypeDescription,
					association.ExecutableFilePath);
			}

			if (madeChanges)
			{
				SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_FLUSH, IntPtr.Zero, IntPtr.Zero);
			}
		}

		public static bool SetAssociation(string extension, string progId, string fileTypeDescription, string applicationFilePath)
		{
			bool madeChanges = false;
			madeChanges |= SetKeyDefaultValue(@"Software\Classes\" + extension, progId);
			madeChanges |= SetKeyDefaultValue(@"Software\Classes\" + progId, fileTypeDescription);
			madeChanges |= SetKeyDefaultValue($@"Software\Classes\{progId}\shell\open\command", "\"" + applicationFilePath + "\" \"%1\"");
			return madeChanges;
		}

		private static bool SetKeyDefaultValue(string keyPath, string value)
		{
			using (var key = Registry.CurrentUser.CreateSubKey(keyPath))
			{
				if (key.GetValue(null) as string != value)
				{
					key.SetValue(null, value);
					return true;
				}
			}

			return false;
		}
	}

	/// <summary>
	/// Managed equivalent of the Win32 <code>RECT</code> structure.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct LtrbRectangle
	{
		public int Left;
		public int Top;
		public int Right;
		public int Bottom;

		public LtrbRectangle(int left, int top, int right, int bottom)
		{
			this.Left = left;
			this.Top = top;
			this.Right = right;
			this.Bottom = bottom;
		}

		public Rectangle ToRectangle()
		{
			return Rectangle.FromLTRB(Left, Top, Right, Bottom);
		}

		public static LtrbRectangle FromRectangle(Rectangle rect)
		{
			return new LtrbRectangle(rect.X, rect.Y, rect.X + rect.Width, rect.Y + rect.Height);
		}

		public override string ToString()
		{
			return "{Left=" + this.Left + ",Top=" + this.Top + ",Right=" + this.Right + ",Bottom=" + this.Bottom + "}";
		}
	}

	/// <summary>
	/// Flags specifying which edges to anchor the form at.
	/// </summary>
	[Flags]
	public enum SnapLocation
	{
		None = 0,
		Left = 1 << 0,
		Top = 1 << 1,
		Right = 1 << 2,
		Bottom = 1 << 3,
		All = Left | Top | Right | Bottom
	}
}
 
 