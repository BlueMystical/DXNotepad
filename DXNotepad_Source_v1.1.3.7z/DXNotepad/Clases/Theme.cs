﻿using System;

namespace DXNotepad.Clases
{
	[Serializable]
	public class Theme
	{
		public Theme()
		{
			//Default Values for Dark Theme:
			Name = "Dark";
			Description = "Default Dark Theme";
			Author = "Blue Mystic";
			Colors = new ThemeColors();
		}

		public string Name { get; set; }
		public string Description { get; set; }
		public string Author { get; set; }

		public ThemeColors Colors { get; set; }
	}

	[Serializable]
	public class ThemeColors
	{
		public ThemeColors()
		{
			//Default Values for Dark Theme:
			Window_BackColor = "#000000";
			Window_BorderColor = "#0055FF";
			Window_ForeColor = "#FFFFFF";
			Window_FontName = "Segoe UI";
			Window_Fontsize = "8,25";

			Menus_BackColor = "#000000";
			Menus_ForeColor = "#FFFFFF";
			Menus_BorderColor = "#2A00FF";
			Menus_SeparatorColor = "#2E3349";
			Menus_HightLight_BackColor = "#2A00FF";
			Menus_HightLight_ForeColor = "#FFFFFF";
			Menus_HightLight_BorderColor = "#6A93CC";

			TextEditor_BackColor = "#1E1E1E";
			TextEditor_ForeColor = "#E0E0E0";
			TextEditor_FontName = "Courier New";
			TextEditor_Fontsize = "9,75";
			LineCounter_BackColor = "#000000";
			LineCounter_ForeColor = "#004040";

			Button_BackColor = "#FF8000";
			Button_ForeColor = "#000000";
			Button_HoverColor = "#2A00FF";
			Button_PressColor = "#0055FF";

			Icon_Color = "#FF8000";

			Slider_BackColor = "#000000";
			Slider_ForeColor = "#1E1E1E";
			Slider_HoverColor = "#FF8000";
			Slider_PressColor = "#2A00FF";
		}

		public string Window_BackColor { get; set; }
		public string Window_BorderColor { get; set; }
		public string Window_ForeColor { get; set; }
		public string Window_FontName { get; set; }
		public string Window_Fontsize { get; set; }

		public string Menus_BackColor { get; set; }
		public string Menus_ForeColor { get; set; }
		public string Menus_BorderColor { get; set; }

		public string Menus_SeparatorColor { get; set; }

		public string Menus_HightLight_BackColor { get; set; }
		public string Menus_HightLight_ForeColor { get; set; }
		public string Menus_HightLight_BorderColor { get; set; }

		public string TextEditor_BackColor { get; set; }
		public string TextEditor_ForeColor { get; set; }
		public string TextEditor_FontName { get; set; }
		public string TextEditor_Fontsize { get; set; }

		public string LineCounter_BackColor { get; set; }
		public string LineCounter_ForeColor { get; set; }

		public string Button_BackColor { get; set; }
		public string Button_ForeColor { get; set; } 
		public string Button_HoverColor { get; set; }
		public string Button_PressColor { get; set; }

		public string Slider_BackColor { get; set; }
		public string Slider_ForeColor { get; set; }
		public string Slider_HoverColor { get; set; }
		public string Slider_PressColor { get; set; }

		public string Icon_Color { get; set; }
	}
}
