﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

using AutoUpdaterDotNET;
using DXNotepad.Clases;
using DXNotepad.Controls;
using FontAwesome.Sharp;
using MenuControls;

namespace DXNotepad
{
    public partial class MainForm : Form
	{
		#region Win32 API stuff

		[DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int msg, int wParam, ref Point lParam);

		[DllImport("user32.dll", EntryPoint = "FindWindowEx")]
		public static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);

		[DllImport("User32.dll")]
		public static extern long GetScrollPos(IntPtr hWnd, int nBar);

		[DllImport("user32.dll")]
		public static extern bool GetScrollRange(IntPtr hWnd, int nBar, out int lpMinPos, out int lpMaxPos);

		[DllImportAttribute("user32.dll")]
		public static extern bool ReleaseCapture();

		[System.Runtime.InteropServices.DllImport("user32.dll")]
		private extern static int GetWindowLong(IntPtr hWnd, int index);

		public static bool VerticalScrollBarVisible(Control ctl)
		{
			int style = GetWindowLong(ctl.Handle, -16);
			return (style & WS_VSCROLL) != 0;
		}
		public static bool HorizontalScrollBarVisible(Control ctl)
		{
			int style = GetWindowLong(ctl.Handle, -16);
			return (style & WS_HSCROLL) != 0;
		}

		public enum ScrollBarType : uint
		{
			SbHorz = 0,
			SbVert = 1,
			SbCtl = 2,
			SbBoth = 3
		}
		public enum ScrollBarCommands : uint
		{
			SB_THUMBPOSITION = 4
		}


		private const int SB_LINEUP = 0;
		private const int SB_LINEDOWN = 1;
		private const int SB_PAGEUP = 2;
		private const int SB_PAGEDOWN = 3;
		private const int SB_TOP = 6;
		private const int SB_BOTTOM = 7;
		private const int SB_ENDSCROLL = 8;

		private const int SC_MAXIMIZE = 0xF030;

		private const int WM_ENTERSIZEMOVE = 0x0231;
		private const int WM_GETMINMAXINFO = 0x0024;
		private const int WM_NCLBUTTONDOWN = 0xA1;
		private const int WM_SYSCOMMAND = 0x0112;
		private const int WM_NCHITTEST = 0x0084;
		private const int WM_NCCALCSIZE = 0x83;
		private const int WM_VSCROLL = 0x115;
		private const int WM_MOVING = 0x0216;
		private const int WM_SIZE = 0x0005;
		private const int WM_USER = 0x400;

		private const int WS_VSCROLL = 0x00200000;
		private const int WS_HSCROLL = 0x00100000;

		private const int EM_GETSCROLLPOS = WM_USER + 221;
		private const int EM_SETSCROLLPOS = WM_USER + 222;

		private const int HT_CAPTION = 0x2;
		private const int HTCLIENT = 0x01;
		private const int HTRIGHT = 11;
		private const int HTLEFT = 10;
		private const int HTTOP = 12;
		private const int HTBOTTOM = 15;
		private const int HTTOPLEFT = 13;
		private const int HTTOPRIGHT = 14;
		private const int HTBOTTOMLEFT = 16;
		private const int HTBOTTOMRIGHT = 17;

		private const int CS_DROPSHADOW = 0x20000;
		private const int WS_SIZEBOX = 0x40000;

		[StructLayout(LayoutKind.Sequential)]
		private class POINT
		{
			public int x;
			public int y;
			public POINT()
			{
			}
			public POINT(int x, int y)
			{
				this.x = x;
				this.y = y;
			}
		}
		[StructLayout(LayoutKind.Sequential)]
		private class MINMAXINFO
		{
			public POINT ptReserved;
			public POINT ptMaxSize;
			public POINT ptMaxPosition;
			public POINT ptMinTrackSize;
			public POINT ptMaxTrackSize;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct RECT
		{
			public int Left, Top, Right, Bottom;

			public RECT(int left, int top, int right, int bottom)
			{
				this.Left = left;
				this.Top = top;
				this.Right = right;
				this.Bottom = bottom;
			}

			public RECT(System.Drawing.Rectangle r) : this(r.Left, r.Top, r.Right, r.Bottom) { }

			public int X
			{
				get { return this.Left; }
				set { this.Right -= (this.Left - value); this.Left = value; }
			}

			public int Y
			{
				get { return this.Top; }
				set { this.Bottom -= (this.Top - value); this.Top = value; }
			}

			public int Height
			{
				get { return this.Bottom - this.Top; }
				set { this.Bottom = value + this.Top; }
			}

			public int Width
			{
				get { return this.Right - this.Left; }
				set { this.Right = value + this.Left; }
			}

			public System.Drawing.Point Location
			{
				get { return new System.Drawing.Point(this.Left, this.Top); }
				set { this.X = value.X; this.Y = value.Y; }
			}

			public System.Drawing.Size Size
			{
				get { return new System.Drawing.Size(this.Width, this.Height); }
				set { this.Width = value.Width; this.Height = value.Height; }
			}

			public static implicit operator System.Drawing.Rectangle(RECT r)
			{
				return new System.Drawing.Rectangle(r.Left, r.Top, r.Width, r.Height);
			}

			public static implicit operator RECT(System.Drawing.Rectangle r)
			{
				return new RECT(r);
			}

			public static bool operator ==(RECT r1, RECT r2)
			{
				return r1.Equals(r2);
			}

			public static bool operator !=(RECT r1, RECT r2)
			{
				return !r1.Equals(r2);
			}

			public bool Equals(RECT r)
			{
				return r.Left == this.Left && r.Top == this.Top && r.Right == this.Right && r.Bottom == this.Bottom;
			}

			public override bool Equals(object obj)
			{
				if (obj is RECT)
					return Equals((RECT)obj);
				else if (obj is System.Drawing.Rectangle)
					return Equals(new RECT((System.Drawing.Rectangle)obj));
				return false;
			}

			public override int GetHashCode()
			{
				return ((System.Drawing.Rectangle)this).GetHashCode();
			}

			public override string ToString()
			{
				return string.Format(System.Globalization.CultureInfo.CurrentCulture, "{{Left={0},Top={1},Right={2},Bottom={3}}}", this.Left, this.Top, this.Right, this.Bottom);
			}

			public Rectangle ToRectangle()
			{
				return Rectangle.FromLTRB(this.Left, this.Top, this.Right, this.Bottom);
			}
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct WINDOWPOS
		{
			public IntPtr hwnd;
			public IntPtr hwndInsertAfter;
			public int x;
			public int y;
			public int cx;
			public int cy;
			public uint flags;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct NCCALCSIZE_PARAMS
		{
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
			public RECT[] rgrc;
			WINDOWPOS lppos;
		}

		//Estos son los Bordes de la Ventana:
		private const int _W = 2; //<- Ancho de los Bordes
		Rectangle BorderTop { get { return new Rectangle(0, 0, this.ClientSize.Width, _W); } }
		Rectangle BorderLeft { get { return new Rectangle(0, 0, _W, this.ClientSize.Height); } }
		Rectangle BorderBottom { get { return new Rectangle(0, this.ClientSize.Height - _W, this.ClientSize.Width, _W); } }
		Rectangle BorderRight { get { return new Rectangle(this.ClientSize.Width - _W, 0, _W, this.ClientSize.Height); } }

		Rectangle TopLeft { get { return new Rectangle(0, 0, _W, _W); } }
		Rectangle TopRight { get { return new Rectangle(this.ClientSize.Width - _W, 0, _W, _W); } }
		Rectangle BottomLeft { get { return new Rectangle(0, this.ClientSize.Height - _W, _W, _W); } }
		Rectangle BottomRight { get { return new Rectangle(this.ClientSize.Width - _W, this.ClientSize.Height - _W, _W, _W); } }

		#endregion

		#region Private Declarations

		private ResourceManager res_man;    // declare Resource manager to access to specific cultureinfo
		private bool SilentUpdate = true;
		private bool ShowLines = true;

		private PrintPreviewDialog printPreviewDialog1 = new PrintPreviewDialog();
		private PrintDocument printDocument1 = new PrintDocument();

		private string stringToPrint; //<-  to hold the portion of the document that is not printed.		
		private string documentContents; //<- Declare a string to hold the entire document contents.

		private FlatPopupMenu FPM = null; //<- Custom Popup Menu para el RichTextBox

		private Rectangle WindowSize;
		private bool IsMaximized = false;
		private bool CustomizingTheme = false;

		#endregion

		#region Public Properties

		public string FilePath { get; set; }
		public int LinesCount { get; set; }
		public Theme MyTheme { get; set; }
		public bool IsDirty { get; set; }
		public Font Fuente { get; set; }

		#endregion

		#region Constructores

		public MainForm()
		{
			InitializeComponent();

			Size designSize = this.ClientSize;
			this.FormBorderStyle = FormBorderStyle.Sizable;
			this.Size = designSize;
			this.DoubleBuffered = true;
			//this.SetStyle(ControlStyles.ResizeRedraw, true); // this is to avoid visual artifacts

			LoadTheme(Util.AppConfig_GetValue("Theme").NVL("theme_dark"));
		}
		public MainForm(string[] args)
		{
			InitializeComponent();

			Size designSize = this.ClientSize;
			this.FormBorderStyle = FormBorderStyle.Sizable;
			this.Size = designSize;
			this.DoubleBuffered = true;
			this.SetStyle(ControlStyles.ResizeRedraw, true); // this is to avoid visual artifacts

			LoadTheme(Util.AppConfig_GetValue("Theme").NVL("theme_dark"));

			//Leer los argumentos pasados por linea de comandos:
			if (args != null && args.Length > 0)
			{
				this.FilePath = args[0];
			}
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			#region Carga el Idioma

			//Carga el Idioma del Usuario, si no lo encuentra Detecta el idioma Local, de lo contrario usa Ingles:
			string LangShort = ConfigurationManager.AppSettings["Language"].NVL(string.Empty);
			if (LangShort.EmptyOrNull())
			{
				LangShort = System.Globalization.CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
			}
			SetLanguage(LangShort);

			#endregion

			this.printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);

			this.WindowSize = new Rectangle(this.Location.X, this.Location.Y, this.Size.Width, this.Size.Height);

			CheckForUpdates();
		}
		private void Form1_Shown(object sender, EventArgs e)
		{
			if (!this.FilePath.EmptyOrNull())
			{
				Loadfile(this.FilePath);
			}
			else
			{
				NewFile();
			}
		}
		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (this.IsDirty)
			{
				if (!this.FilePath.EmptyOrNull() && File.Exists(this.FilePath))
				{
					if (MessageBox.Show(this.res_man.GetString("save_closing_msg"), this.res_man.GetString("save_title"),
						MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
					{
						SaveFile();
					}
				}
			}
			var bmp = this.VScrollBar_Box.Image as IDisposable;
			if (bmp != null)
			{
				bmp.Dispose();
			}
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			//Color para la Barra de Titulo y los Bordes de la Ventana:
			if (this.MyTheme != null)
			{
				Color BorderColor = System.Drawing.ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BorderColor);
				SolidBrush _Brush = new SolidBrush(BorderColor);

				e.Graphics.FillRectangle(_Brush, this.BorderTop);
				e.Graphics.FillRectangle(_Brush, this.BorderLeft);
				e.Graphics.FillRectangle(_Brush, this.BorderRight);
				e.Graphics.FillRectangle(_Brush, this.BorderBottom);

				DrawGripper(e);
			}
		}
		protected override void WndProc(ref Message m)
		{
			//This gives us the ability to resize the borderless from any borders instead of just the lower right corner
			if (m.Msg == WM_NCHITTEST)
			{
				int x = (int)(m.LParam.ToInt64() & 0xFFFF);
				int y = (int)((m.LParam.ToInt64() & 0xFFFF0000) >> 16);
				Point pt = PointToClient(new Point(x, y));
				Size clientSize = this.ClientSize;

				///allow resize on the lower right corner
				if (pt.X >= clientSize.Width - 16 && pt.Y >= clientSize.Height - 16 && clientSize.Height >= 16)
				{
					m.Result = (IntPtr)(this.IsMirrored ? HTBOTTOMLEFT : HTBOTTOMRIGHT);
					return;
				}
				///allow resize on the lower left corner
				if (pt.X <= 16 && pt.Y >= clientSize.Height - 16 && clientSize.Height >= 16)
				{
					m.Result = (IntPtr)(this.IsMirrored ? HTBOTTOMRIGHT : HTBOTTOMLEFT);
					return;
				}
				///allow resize on the upper right corner
				if (pt.X <= 16 && pt.Y <= 16 && clientSize.Height >= 16)
				{
					m.Result = (IntPtr)(this.IsMirrored ? HTTOPRIGHT : HTTOPLEFT);
					return;
				}
				///allow resize on the upper left corner
				if (pt.X >= clientSize.Width - 16 && pt.Y <= 16 && clientSize.Height >= 16)
				{
					m.Result = (IntPtr)(this.IsMirrored ? HTTOPLEFT : HTTOPRIGHT);
					return;
				}
				///allow resize on the top border
				if (pt.Y <= 16 && clientSize.Height >= 16)
				{
					m.Result = (IntPtr)(HTTOP);
					return;
				}
				///allow resize on the bottom border
				if (pt.Y >= clientSize.Height - 16 && clientSize.Height >= 16)
				{
					m.Result = (IntPtr)(HTBOTTOM);
					return;
				}
				///allow resize on the left border
				if (pt.X <= 16 && clientSize.Height >= 16)
				{
					m.Result = (IntPtr)(HTLEFT);
					return;
				}
				///allow resize on the right border
				if (pt.X >= clientSize.Width - 16 && clientSize.Height >= 16)
				{
					m.Result = (IntPtr)(HTRIGHT);
					return;
				}
			}
			else
			{
				//Enable Windows Aero Snap:
				/* this.FormBorderStyle = FormBorderStyle.Sizable;
				 * Application.EnableVisualStyles();  <<- Disabled  */

				if (m.Msg == WM_NCCALCSIZE && m.WParam.ToInt32() == 1)
				{
					//m.Result = new IntPtr(0xF0);   // Align client area to all borders
					//m.Result = 0;
					return;
				}
			}

			base.WndProc(ref m);
		}

		protected override CreateParams CreateParams
		{
			get
			{
				CreateParams cp = base.CreateParams;
				cp.Style |= CS_DROPSHADOW; //<- Borde con sombra
				return cp;
			}
		}
		protected override bool ProcessDialogKey(Keys keyData)
		{
			//Keybinding para CTRL+G
			if (keyData == (Keys.Control | Keys.G))
			{
				GotoLine();
				return true;
			}
			return base.ProcessDialogKey(keyData);
		}

		private void MainForm_MouseMove(object sender, MouseEventArgs e)
		{
			//Permite Mover la Ventana sin Titulo.
			//if (e.Button == MouseButtons.Left)
			//{
			//	ReleaseCapture();
			//	SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
			//}
		}

		public void DrawGripper(PaintEventArgs e)
		{
			//Dibuja el Triangulo en la esquina inf. derecha para redimensionar la ventana
			if (VisualStyleRenderer.IsElementDefined(
				VisualStyleElement.Status.Gripper.Normal))
			{
				VisualStyleRenderer renderer = new VisualStyleRenderer(VisualStyleElement.Status.Gripper.Normal);
				Rectangle rectangle1 = new Rectangle((this.Width) - 18, (this.Height) - 20, 20, 20);
				renderer.DrawBackground(e.Graphics, rectangle1);
			}
		}

		private void MaximizeWindow()
		{
			var rectangle = Screen.FromControl(this).Bounds;
			this.FormBorderStyle = FormBorderStyle.None;
			this.Size = new Size(rectangle.Width, rectangle.Height);
			this.Location = new Point(0, 0);
			Rectangle workingRectangle = Screen.PrimaryScreen.WorkingArea;
			this.Size = new Size(workingRectangle.Width, workingRectangle.Height);
			this.IsMaximized = true;
		}

		#endregion

		#region Metodos

		private void Loadcontrols()
		{
			try
			{
				//Estos son los Controles en la ToolBar de Abajo:
				Color IconColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Icon_Color);

				this.txtSearch_2.Text = this.res_man.GetString("search");
				this.toolTip1.SetToolTip(this.cmdSearch_2, this.res_man.GetString("search"));
				this.toolTip1.SetToolTip(this.cmdFindNext_2, this.res_man.GetString("find_next"));
				this.toolTip1.SetToolTip(this.cmdReplace_2, this.res_man.GetString("replace"));

				this.panelSearchBox.Visible = true;
				this.ReplaceBox.Visible = false;
				this.cmdFindNext_2.Visible = false;
				this.cmdReplace_2.Visible = false;
				this.cmdReplaceNext_2.Visible = false;
				this.cmdReplaceAll_2.Visible = false;
				this.lblFindMatches_2.Visible = false;

				this.txtReplace_2.Text = this.res_man.GetString("replace");
				this.toolTip1.SetToolTip(this.cmdReplaceNext_2, this.res_man.GetString("replace_next"));
				this.toolTip1.SetToolTip(this.cmdReplaceAll_2, this.res_man.GetString("replace_all"));

				this.cmdSaveChanges_2.Text = this.res_man.GetString("save_title");

				//Mostrar los Numeros de Linea:
				this.ShowLines = Convert.ToBoolean(ConfigurationManager.AppSettings["LineNumbers"].NVL("true"));
				if (this.ShowLines)
				{
					this.splitContainer1.Panel1Collapsed = false;
				}
				else
				{
					this.splitContainer1.Panel1Collapsed = true;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		private void LoadTheme(string ThemeName)
		{
			try
			{
				this.MyTheme = new Theme(); //<- Has Default Values for Dark Theme
				string ThemePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ThemeName + ".json");
				if (File.Exists(ThemePath))
				{
					this.MyTheme = Util.DeSerialize_FromJSON<Theme>(ThemePath);
					if (this.MyTheme != null)
					{
						string Fname = this.MyTheme.Colors.Window_FontName;
						float Fsize = float.Parse(this.MyTheme.Colors.Window_Fontsize);						

						this.Invalidate(); //<- Obliga a re-dibujar los Bordes de la Ventana

						this.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_ForeColor);
						this.Font = new Font(Fname, Fsize);

						#region Window Title

						this.panel_TOP.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.panel_TOP.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_ForeColor);
						this.panel_TOP.Font = new Font(Fname, Fsize);

						this.lblWindowTitle.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_ForeColor);

						this.picFormIcon.Image = IconChar.StickyNote.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Icon_Color), 24);

						this.cmdWindow_Maximize.Text = string.Empty;
						this.cmdWindow_Maximize.Image = IconChar.Square.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Window_ForeColor), 22);
						this.cmdWindow_Maximize.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
						this.cmdWindow_Maximize.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);

						this.cmdWindow_Close.Text = string.Empty;
						this.cmdWindow_Close.Image = IconChar.Times.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Window_ForeColor), 22);
						this.cmdWindow_Close.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
						this.cmdWindow_Close.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);

						this.cmdWindow_Minimize.Text = string.Empty;
						this.cmdWindow_Minimize.Image = IconChar.WindowMinimize.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Window_ForeColor), 22);
						this.cmdWindow_Minimize.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
						this.cmdWindow_Minimize.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);

						#endregion

						#region Text Editor

						Fname = this.MyTheme.Colors.TextEditor_FontName;
						Fsize = float.Parse(this.MyTheme.Colors.TextEditor_Fontsize);
						this.Fuente = new Font(Fname, Fsize);

						this.txLines.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.LineCounter_BackColor);
						this.txLines.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.LineCounter_ForeColor);
						this.txLines.Font = new Font(Fname, Fsize);
						this.txLines.EnableMouseWheel = false;

						this.memoTEXTO.Buddy = this.txLines;
						this.memoTEXTO.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.TextEditor_BackColor);
						this.memoTEXTO.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.TextEditor_ForeColor);
						this.memoTEXTO.Font = new Font(Fname, Fsize);

						#endregion

						#region Bottom Toolbar

						this.panel_BOTTOM_2.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.panel_BOTTOM_2.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_ForeColor);
						this.panel_BOTTOM_2.Font = this.Font;

						this.panelSearchBox.Invalidate();
						this.txtSearch_2.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.txtSearch_2.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.TextEditor_ForeColor);
						this.txtSearch_2.BorderStyle = BorderStyle.None;

						this.cmdSearch_2.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.cmdSearch_2.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_ForeColor);
						this.cmdSearch_2.FlatAppearance.MouseOverBackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_HoverColor);
						this.cmdSearch_2.FlatAppearance.MouseDownBackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_PressColor);
						this.cmdSearch_2.FlatAppearance.BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.cmdSearch_2.Image = IconChar.Search.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Icon_Color), 20);
						this.cmdSearch_2.Text = string.Empty;
						this.cmdSearch_2.Tag = "Search";

						this.cmdFindNext_2.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.cmdFindNext_2.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_ForeColor);
						this.cmdFindNext_2.FlatAppearance.MouseOverBackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_HoverColor);
						this.cmdFindNext_2.FlatAppearance.MouseDownBackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_PressColor);
						this.cmdFindNext_2.FlatAppearance.BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.cmdFindNext_2.Image = IconChar.ArrowRight.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Icon_Color), 20);
						this.cmdFindNext_2.Text = string.Empty;
						this.cmdFindNext_2.Tag = "Find Next";

						this.ReplaceBox.Invalidate();
						this.txtReplace_2.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.txtReplace_2.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.TextEditor_ForeColor);
						this.txtReplace_2.BorderStyle = BorderStyle.None;

						this.cmdReplace_2.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.cmdReplace_2.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_ForeColor);
						this.cmdReplace_2.FlatAppearance.MouseOverBackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_HoverColor);
						this.cmdReplace_2.FlatAppearance.MouseDownBackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_PressColor);
						this.cmdReplace_2.FlatAppearance.BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.cmdReplace_2.Image = IconChar.SignOutAlt.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Icon_Color), 20);
						this.cmdReplace_2.Text = string.Empty;
						this.cmdReplace_2.Tag = "Replace";

						this.cmdReplaceNext_2.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.cmdReplaceNext_2.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_ForeColor);
						this.cmdReplaceNext_2.FlatAppearance.MouseOverBackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_HoverColor);
						this.cmdReplaceNext_2.FlatAppearance.MouseDownBackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_PressColor);
						this.cmdReplaceNext_2.FlatAppearance.BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.cmdReplaceNext_2.Image = IconChar.AngleRight.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Icon_Color), 20);
						this.cmdReplaceNext_2.Text = string.Empty;
						this.cmdReplaceNext_2.Tag = "Replace";

						this.cmdReplaceAll_2.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.cmdReplaceAll_2.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_ForeColor);
						this.cmdReplaceAll_2.FlatAppearance.MouseOverBackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_HoverColor);
						this.cmdReplaceAll_2.FlatAppearance.MouseDownBackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_PressColor);
						this.cmdReplaceAll_2.FlatAppearance.BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.cmdReplaceAll_2.Image = IconChar.AngleDoubleRight.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Icon_Color), 20);
						this.cmdReplaceAll_2.Text = string.Empty;
						this.cmdReplaceAll_2.Tag = "Replace";

						this.cmdSaveChanges_2.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_BackColor);
						this.cmdSaveChanges_2.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_ForeColor);
						this.cmdSaveChanges_2.FlatAppearance.BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
						this.cmdSaveChanges_2.FlatAppearance.MouseOverBackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_HoverColor);
						this.cmdSaveChanges_2.FlatAppearance.MouseDownBackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_PressColor);
						this.cmdSaveChanges_2.Image = IconChar.Save.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Button_ForeColor), 20);
						this.cmdSaveChanges_2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;

						#endregion

						#region Scrollbars

						this.HScrollBar_Box.BackColor =      ColorTranslator.FromHtml(this.MyTheme.Colors.Slider_BackColor);
						this.scrollBarEx_H.BackgroundColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Slider_BackColor);
						this.scrollBarEx_H.BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Slider_BackColor);
						this.scrollBarEx_H.TrackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Slider_ForeColor);
						this.scrollBarEx_H.HoverColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Slider_HoverColor);
						this.scrollBarEx_H.PressColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Slider_PressColor);						

						this.VScrollBar_Box.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Slider_BackColor);
						this.scrollBarEx_V.BackgroundColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Slider_BackColor);
						this.scrollBarEx_V.BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Slider_BackColor);
						this.scrollBarEx_V.TrackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Slider_ForeColor);
						this.scrollBarEx_V.HoverColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Slider_HoverColor);
						this.scrollBarEx_V.PressColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Slider_PressColor);						

						#endregion
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void OpenFile()
		{
			try
			{
				OpenFileDialog OFDialog = new OpenFileDialog()
				{
					Filter = this.res_man.GetString("text_file_filter"),
					FilterIndex = 0,
					DefaultExt = "txt",
					AddExtension = true,
					CheckPathExists = true,
					CheckFileExists = true,
					InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
				};

				if (OFDialog.ShowDialog() == DialogResult.OK)
				{
					this.FilePath = OFDialog.FileName;
					Loadfile(this.FilePath);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		private void Loadfile(string _FilePath)
		{
			try
			{
				if (File.Exists(_FilePath))
				{
					this.FilePath = _FilePath;
					System.IO.FileInfo file1 = new System.IO.FileInfo(_FilePath);

					this.lblFileSize_2.Text = Util.FileSize(file1.Length);
					this.lblWindowTitle.Text = string.Format("DXNotepad - {0}", file1.Name);
					this.Text = this.lblWindowTitle.Text;

					LoadText(Util.ReadTextFile(_FilePath, Util.TextEncoding.UTF8));
					this.memoTEXTO.Focus();
				}
				else
				{
					MessageBox.Show(this.res_man.GetString("error_404"), "ERROR_404", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		private void LoadText(string _Texto)
		{
			try
			{
				if (_Texto != null && _Texto.Length > 0)
				{
					this.memoTEXTO.Text = _Texto;

					UpdateLinesCount(_Texto);

					this.IsDirty = false;
				}
				else
				{
					this.memoTEXTO.Text = string.Empty;
					UpdateLinesCount(string.Empty);
				}
				this.memoTEXTO.ScrollToLine(0);
				ShowLine(1);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void SaveFile(bool Rename = false)
		{
			try
			{
				if (Rename) goto SaveAss;

				if (!this.FilePath.EmptyOrNull() && File.Exists(this.FilePath))
				{
					//Si hay archivo lo guarda directo
					Util.SaveTextFile(this.FilePath, this.memoTEXTO.Text, Util.TextEncoding.UTF8);
					this.IsDirty = false;
					goto Hell;
				}
				else { goto SaveAss; }

				SaveAss:
				{
					//Si no hay Archivo, pregunta:
					SaveFileDialog SFDialog = new SaveFileDialog()
					{
						Filter = this.res_man.GetString("text_file_filter"),
						FilterIndex = 0,
						DefaultExt = "txt",
						AddExtension = true,
						CheckPathExists = true,
						OverwritePrompt = true,
						FileName = this.res_man.GetString("text_file_name"),
						InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
					};

					if (SFDialog.ShowDialog() == DialogResult.OK)
					{
						this.FilePath = SFDialog.FileName;
						this.Text = System.IO.Path.GetFileName(SFDialog.FileName);

						string Ext = System.IO.Path.GetExtension(SFDialog.FileName);
						if (Ext.ToLower() == "rtf")
						{
							this.memoTEXTO.SaveFile(this.FilePath);
						}
						else
						{
							Util.SaveTextFile(this.FilePath, this.memoTEXTO.Text, Util.TextEncoding.UTF8);
						}

						this.IsDirty = false;
						goto Hell;
					}
					else
					{
						return;
					}
				}

				Hell:
				{
					System.IO.FileInfo file1 = new System.IO.FileInfo(this.FilePath);
					this.lblFileSize_2.Text = Util.FileSize(file1.Length);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		private void NewFile()
		{
			try
			{
				this.FilePath = string.Empty;
				this.LinesCount = 1;
				this.IsDirty = false;
				this.lblFileSize_2.Text = "0 bytes";
				this.lblWindowTitle.Text = string.Format("DXNotepad - {0}", this.res_man.GetString("text_file_name"));

				LoadText(" ");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void PrintFile()
		{
			try
			{
				PrintDialog printDialog = new PrintDialog();
				if (DialogResult.OK == printDialog.ShowDialog())
				{
					this.documentContents = this.memoTEXTO.Text;
					this.stringToPrint = this.documentContents;

					this.printDocument1.PrinterSettings = printDialog.PrinterSettings;
					//this.printDocument1.DefaultPageSettings.Landscape = true;
					this.printDocument1.DefaultPageSettings.Margins = new Margins(50, 50, 50, 50);

					this.printPreviewDialog1.UseAntiAlias = true;
					this.printPreviewDialog1.WindowState = FormWindowState.Maximized;
					this.printPreviewDialog1.Document = this.printDocument1;

					this.printPreviewDialog1.ShowDialog();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally { this.Cursor = Cursors.Default; }
		}
		private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
		{
			int charactersOnPage = 0;
			int linesPerPage = 0;

			// Sets the value of charactersOnPage to the number of characters
			// of stringToPrint that will fit within the bounds of the page.
			e.Graphics.MeasureString(this.stringToPrint, this.Font,
				e.MarginBounds.Size, StringFormat.GenericTypographic,
				out charactersOnPage, out linesPerPage);

			// Draws the string within the bounds of the page.
			e.Graphics.DrawString(this.stringToPrint, this.Font, Brushes.Black,
			e.MarginBounds, StringFormat.GenericTypographic);

			// Remove the portion of the string that has been printed.
			this.stringToPrint = this.stringToPrint.Substring(charactersOnPage);

			// Check to see if more pages are to be printed.
			e.HasMorePages = (this.stringToPrint.Length > 0);

			// If there are no more pages, reset the string to be printed.
			if (!e.HasMorePages)
				this.stringToPrint = this.documentContents;
		}

		private void Changefont()
		{
			try
			{
				FontDialog Dialog = new FontDialog()
				{
					Font = this.memoTEXTO.Font,
					ShowColor = false,
					ShowHelp = false,
					FontMustExist = true,
					FixedPitchOnly = true
				};

				if (Dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{

					this.Fuente = Dialog.Font;
					this.memoTEXTO.Font = Dialog.Font;
					this.txLines.Font = Dialog.Font;

					// Guardar Datos en el AppConfig:
					Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
					config.AppSettings.Settings["Font_Name"].Value = this.Fuente.Name;
					config.AppSettings.Settings["Font_Size"].Value = this.Fuente.Size.ToString();
					config.Save(ConfigurationSaveMode.Modified);
					ConfigurationManager.RefreshSection("appSettings");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void GotoLine()
		{
			try
			{
				string _Input = "";
				if (Util.InputBox(
					this.res_man.GetString("menu_format_goto"),
					this.res_man.GetString("line_number"), ref _Input) == DialogResult.OK)
				{
					if (!_Input.EmptyOrNull())
					{
						GoToLine(Convert.ToInt32(_Input));
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		private void GoToLine(int LineNumber)
		{
			try
			{
				Invoke((MethodInvoker)(() =>
				{
					int pos = this.memoTEXTO.GetFirstCharIndexFromLine(LineNumber - 1);
					int index = this.txLines.GetFirstCharIndexFromLine(LineNumber - 1);
					if (index >= 0)
					{
						this.txLines.Select(index, 0);
						this.txLines.ScrollToCaret();
					}

					if (pos >= 0)
					{
						this.memoTEXTO.SelectionStart = pos;
						this.memoTEXTO.SelectionLength = 1;
						this.memoTEXTO.ScrollToCaret();
						this.memoTEXTO.Focus();
					}
				}));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		private void ShowLine(int LineNumber)
		{
			try
			{
				if (this.txLines.Lines.Length > 0)
				{
					Invoke((MethodInvoker)(() =>
					{
						int index = this.txLines.GetFirstCharIndexFromLine(LineNumber - 1);
						if (index >= 0)
						{
							this.txLines.Select(index, this.txLines.Lines[LineNumber - 1].Length);
						}
					}));
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private List<Point> FindText(string SearchString, string TextoCompleto)
		{
			List<Point> _Matches = null;
			try
			{
				#region Busca TODAS las coincidencias del texto seleccionado

				if (!SearchString.EmptyOrNull() && !TextoCompleto.NVL("").EmptyOrNull())
				{
					Invoke((MethodInvoker)(() =>
					{
						this.Cursor = Cursors.WaitCursor;
						this.memoTEXTO.Focus();
						this.memoTEXTO.SelectionStart = 0;
						this.memoTEXTO.SelectionLength = 0;

						// Imagen donde se muestran lineas rojas en las posiciones de los textos encontrados
						this.VScrollBar_Box.Image = new Bitmap(this.VScrollBar_Box.Width, this.VScrollBar_Box.Height);
					}));

					_Matches = new List<Point>();
					int index = 0; //Muestra las posiciones de las Coincidencias en la barra lateral
					using (var gr = Graphics.FromImage(this.VScrollBar_Box.Image))
					{
						do
						{
							index = TextoCompleto.IndexOf(SearchString, index);
							if (index != -1)
							{
								Point nPos = new Point(index, SearchString.Length);
								_Matches.Add(nPos);
								index++;

								Invoke((MethodInvoker)(() =>
								{
									// calculate where to postion the bar
									int offset = 20;
									int MaxPos = this.LinesCount + (offset * 2); //= this.pictureBox1.Heigh
									int _Line = this.memoTEXTO.GetLineFromCharIndex(nPos.X) + 1;
									var position = ((double)this.VScrollBar_Box.Height * (_Line + offset) / MaxPos);
									if (position <= this.VScrollBar_Box.Height)
									{
										//gr.DrawLine(new Pen(Color.Red, 1), 0, (int)offset, this.pictureBox1.Width, (int)offset);
										//gr.DrawLine(new Pen(Color.Red, 1), 0, (int)this.pictureBox1.Height - offset, this.pictureBox1.Width, (int)this.pictureBox1.Height - offset);

										gr.DrawLine(new Pen(Color.Orange, 2), 0, (int)position, this.VScrollBar_Box.Width, (int)position);
										this.VScrollBar_Box.Invalidate();

										Console.WriteLine(string.Format("Line:{0}, Pos:{1:n2}", _Line, position));

										//Resaltar el texto encontrado:
										this.memoTEXTO.Select(nPos.X, SearchString.Length);
										this.memoTEXTO.SelectionColor = System.Drawing.Color.Black;
										this.memoTEXTO.SelectionBackColor = System.Drawing.Color.Orange;
									}
								}));
							}
						} while (index != -1);
					}

					if (_Matches.Count > 0)
					{
						Invoke((MethodInvoker)(() =>
						{
							this.panel_BOTTOM_2.Tag = _Matches; //<- Todas las Coincidencias

							this.txtSearch_2.Tag = 0; //<- Indice del primer elemento encontrado							
							this.cmdSearch_2.Image = IconChar.TimesCircle.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Icon_Color), 20);
							this.toolTip1.SetToolTip(this.cmdSearch_2, this.res_man.GetString("clear"));
							this.cmdSearch_2.Tag = "Clear";

							this.lblFindMatches_2.Text = string.Format("{0} {1}", _Matches.Count, this.res_man.GetString("matches"));
							this.lblFindMatches_2.Visible = true;
							this.cmdFindNext_2.Visible = true;
							this.cmdReplace_2.Visible = true;

							if (_Matches[0].X >= 0)
							{
								int LineNumber = this.memoTEXTO.GetLineFromCharIndex(_Matches[0].X);
								int pos = this.txLines.GetFirstCharIndexFromLine(LineNumber);

								this.txLines.Select(pos, 0);
								this.txLines.ScrollToCaret();

								this.memoTEXTO.SelectionStart = _Matches[0].X;
								this.memoTEXTO.SelectionLength = _Matches[0].Y;
								this.memoTEXTO.ScrollToCaret();
								this.memoTEXTO.Focus();
							}

							this.Cursor = Cursors.Default;
						}));
					}
					else
					{
						/* NADA SE ENCONTRO */
						Invoke((MethodInvoker)(() =>
						{
							ClearSearch();

							this.txtSearch_2.Tag = -1;
							this.lblFindMatches_2.Text = string.Format("{0} {1}", _Matches.Count, this.res_man.GetString("matches"));
							this.lblFindMatches_2.Visible = true;
							this.txtSearch_2.Focus();

							this.Cursor = Cursors.Default;
						}));
					}
				}

				#endregion
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			return _Matches;
		}
		private Point FindNext(bool Descendent = true)
		{
			Point _ret = new Point();
			try
			{
				#region Muestra la siguiente Coincidencia

				if (this.txtSearch_2.Tag != null && this.panel_BOTTOM_2.Tag != null)
				{
					List<Point> _Matches = (List<Point>)this.panel_BOTTOM_2.Tag;
					int index = (int)this.txtSearch_2.Tag; //<- Indice del elemento encontrado	

					index = Descendent ? index + 1 : index - 1;

					if (index <= -1) index = _Matches.Count - 1;
					if (index > _Matches.Count - 1) index = 0;

					Invoke((MethodInvoker)(() =>
					{
						this.txtSearch_2.Tag = index; //<- Guarda el Indice usado

						_ret = _Matches[index];

						int pos = this.txLines.GetFirstCharIndexFromLine(this.memoTEXTO.GetLineFromCharIndex(_ret.X));
						this.txLines.Select(pos, 0);
						this.txLines.ScrollToCaret();

						this.memoTEXTO.SelectionStart = _ret.X;
						this.memoTEXTO.SelectionLength = _ret.Y;
						this.memoTEXTO.ScrollToCaret();
						this.memoTEXTO.Focus();
					}));
				}

				#endregion
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			return _ret;
		}

		private void ReplaceNext(string RepText)
		{
			/* Busca y Reemplaza la Siguiente Aparicion del texto buscado */
			try
			{
				if (RepText != null)
				{
					Point _ret = FindNext();

					Invoke((MethodInvoker)(() =>
					{
						this.memoTEXTO.SelectedText = RepText;
						this.memoTEXTO.SelectionStart = _ret.X;
						this.memoTEXTO.SelectionLength = _ret.Y;
						this.memoTEXTO.ScrollToCaret();
						this.memoTEXTO.Focus();
					}));
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		private void ReplaceAll(string SearchText, string RepText)
		{
			/* REEMPLAZA TODAS LAS APARICONES DEL TEXTO BUSCADO */
			try
			{
				if (!SearchText.EmptyOrNull() && RepText != null)
				{
					string WholeText = this.memoTEXTO.Text;
					this.Cursor = Cursors.WaitCursor;

					System.Globalization.CultureInfo customCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
					var t = System.Threading.Tasks.Task.Factory.StartNew(delegate
					{
						System.Threading.Thread.CurrentThread.CurrentCulture = customCulture;

						List<Point> _Matches = FindText(SearchText, WholeText);
						if (_Matches.IsNotEmpty())
						{
							foreach (var _Match in _Matches)
							{
								Invoke((MethodInvoker)(() =>
								{
									this.memoTEXTO.SelectionStart = _Match.X;
									this.memoTEXTO.SelectionLength = _Match.Y;
									this.memoTEXTO.SelectedText = RepText;
								}));
							}

							Invoke((MethodInvoker)(() =>
							{
								this.memoTEXTO.ScrollToCaret();
								this.memoTEXTO.Focus();

								this.Cursor = Cursors.Default;
							}));
						}
					});
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		private void ClearSearch()
		{
			try
			{
				if (this.txtSearch_2.Tag != null && this.panel_BOTTOM_2.Tag != null)
				{
					List<Point> _Matches = (List<Point>)this.panel_BOTTOM_2.Tag;
					if (_Matches.IsNotEmpty())
					{
						foreach (var _match in _Matches)
						{
							this.memoTEXTO.SelectionStart = _match.X;
							this.memoTEXTO.SelectionLength = _match.Y;
							this.memoTEXTO.SelectionColor = this.memoTEXTO.ForeColor;
							this.memoTEXTO.SelectionBackColor = this.memoTEXTO.BackColor;
						}
					}
				}
				this.panel_BOTTOM_2.Tag = null;

				this.lblFindMatches_2.Text = string.Empty;
				this.lblFindMatches_2.Visible = false;

				this.cmdSearch_2.Image = IconChar.Search.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Icon_Color), 20);
				this.toolTip1.SetToolTip(this.cmdSearch_2, this.res_man.GetString("search"));
				this.cmdSearch_2.Tag = "Search";

				// Imagen donde se muestran lineas rojas en las posiciones de los textos encontrados
				this.VScrollBar_Box.Image = new Bitmap(this.VScrollBar_Box.Width, this.VScrollBar_Box.Height);

				this.ReplaceBox.Visible = false;
				this.cmdFindNext_2.Visible = false;
				this.cmdReplace_2.Visible = false;
				this.txtReplace_2.Visible = false;
				this.cmdReplaceNext_2.Visible = false;
				this.cmdReplaceAll_2.Visible = false;

				this.txtSearch_2.Tag = -1;
				this.txtSearch_2.Text = string.Empty;
				this.toolTip1.SetToolTip(this.txtSearch_2, this.res_man.GetString("search"));
				this.txtSearch_2.Focus();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void SetLanguage(string LangShort)
		{
			try
			{
				try
				{
					this.res_man = new ResourceManager(string.Format("DXNotepad.Languages.lang_{0}", LangShort), Assembly.GetExecutingAssembly());
					this.res_man.GetString("menu_file");
				}
				catch
				{
					this.res_man = new ResourceManager("DXNotepad.Languages.lang_en", Assembly.GetExecutingAssembly());
				}

				// Guardar Datos en el AppConfig:
				Util.AppConfig_SetValue("Language", LangShort);
				LoadMenus(LangShort);
				Loadcontrols();

				this.FPM = null;
				AddContextMenuEx(this.memoTEXTO);

				UpdateLinesCount(this.memoTEXTO.Text);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		private void UpdateLinesCount(string _Texto)
		{
			try
			{
				this.txLines.Text = string.Empty;

				System.Globalization.CultureInfo customCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
				var t = System.Threading.Tasks.Task.Factory.StartNew(delegate
				{
					System.Threading.Thread.CurrentThread.CurrentCulture = customCulture;

					string[] Lineas = System.Text.RegularExpressions.Regex.Split(_Texto, "\r\n|\r|\n");
					this.LinesCount = Lineas.Length;

					StringBuilder LineNumbers = new StringBuilder();
					for (int i = 1; i <= this.LinesCount; i++)
					{
						LineNumbers.AppendLine((i).ToString("n0"));
					}

					Invoke((MethodInvoker)(() =>
					{
						Size s = TextRenderer.MeasureText("A", this.memoTEXTO.Font, this.memoTEXTO.Size, TextFormatFlags.WordBreak);
						int letterHeight = s.Height;
						int displayableLines = this.memoTEXTO.Height / letterHeight;

						this.txLines.Text = LineNumbers.ToString();
						this.txLines.SelectAll();
						this.txLines.SelectionAlignment = HorizontalAlignment.Center;
						this.txLines.SelectionLength = 0;

						this.lblStatus_2.Text = string.Format("{0:n0} {1}.", this.LinesCount, this.res_man.GetString("lines"));
					}));
				});
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		int heightContentRtb, widthContentRtb;
		private void Determine_HMax(RichTextBox RTB)
		{
			//Determina el Ancho maximo del Control para usar en la Scrollbar
			this.scrollBarEx_H.Visible = HorizontalScrollBarVisible(RTB);
			if (this.scrollBarEx_H.Visible)
			{
				int max = this.widthContentRtb - RTB.ClientSize.Width + 1;

				this.scrollBarEx_H.Maximum = max;
				this.scrollBarEx_H.LargeChange = (max * 20) / 100;
			}
		}
		private void Determine_VMax(RichTextBox RTB)
		{
			//Determina la altura maxima del Control para usar en la Scrollbar
			this.scrollBarEx_V.Visible = VerticalScrollBarVisible(RTB);
			if (this.scrollBarEx_V.Visible)
			{
				int max = this.heightContentRtb - RTB.ClientSize.Height + 1;

				this.scrollBarEx_V.Maximum = max;
				this.scrollBarEx_V.LargeChange = (max * 20) / 100;
			}
		}

		private void CheckForUpdates(bool WaitForIt = false)
		{
			try
			{
				//https://github.com/ravibpatel/AutoUpdater.NET

				string LastUpdateCheck = ConfigurationManager.AppSettings["LastUpdateCheck"].NVL(DateTime.Today.ToShortDateString());
				DateTime LastCheckDate = Convert.ToDateTime(LastUpdateCheck);

				if (this.SilentUpdate || LastCheckDate < DateTime.Today)
				{
					AutoUpdater.ReportErrors = true;
					AutoUpdater.Synchronous = WaitForIt;
					AutoUpdater.CheckForUpdateEvent += AutoUpdater_CheckForUpdateEvent;
					AutoUpdater.InstalledVersion = new Version(ConfigurationManager.AppSettings["Version"].ToString());
					AutoUpdater.DownloadPath = Path.Combine(System.IO.Path.GetTempPath(), "DXNotePad");

					AutoUpdater.Start(@"https://raw.githubusercontent.com/BlueMystical/DXNotepad/main/latest_version_info.xml");
				}
				else
				{
					AutoUpdater.ReportErrors = true;
					AutoUpdater.Synchronous = WaitForIt;
					AutoUpdater.CheckForUpdateEvent += AutoUpdater_CheckForUpdateEvent;
					AutoUpdater.InstalledVersion = new Version(ConfigurationManager.AppSettings["Version"].ToString());
					AutoUpdater.DownloadPath = Path.Combine(System.IO.Path.GetTempPath(), "DXNotePad");

					AutoUpdater.Start(@"https://raw.githubusercontent.com/BlueMystical/DXNotepad/main/latest_version_info.xml");
				}

				/* If you are using a zip file as an update file then you can set the "InstallationPath" equal to the path where your app is installed. 
				 * This is only necessary when your installation directory differs from your executable path. */

				//var currentDirectory = new DirectoryInfo(Environment.CurrentDirectory);
				//if (currentDirectory.Parent != null)
				//{
				//	AutoUpdater.InstallationPath = currentDirectory.Parent.FullName;
				//}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		private void AutoUpdater_CheckForUpdateEvent(UpdateInfoEventArgs args)
		{
			//https://github.com/ravibpatel/AutoUpdater.NET

			if (args.Error != null)
			{
				MessageBox.Show(args.Error.Message + args.Error.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			if (args.Error == null)
			{
				if (args.IsUpdateAvailable)
				{
					DialogResult dialogResult;
					if (args.Mandatory.Value)
					{
						//$@"There is new version {args.CurrentVersion} available. You are using version {args.InstalledVersion}. This is required update. Press Ok to begin updating the application.",
						dialogResult =
							MessageBox.Show(string.Format(this.res_man.GetString("update_mandatroy_msg"), args.CurrentVersion, args.InstalledVersion),
								this.res_man.GetString("update_available"),
								MessageBoxButtons.OK, MessageBoxIcon.Information);
					}
					else
					{
						//$@"There is new version {args.CurrentVersion} available. You are using version {args.InstalledVersion}. Do you want to update the application now?"
						dialogResult =
							MessageBox.Show(
								string.Format(this.res_man.GetString("update_optional_msg"), args.CurrentVersion, args.InstalledVersion),
								this.res_man.GetString("update_available"),
								MessageBoxButtons.YesNo,
								MessageBoxIcon.Information);
					}

					// Uncomment the following line if you want to show standard update dialog instead.
					//AutoUpdater.ShowUpdateForm(args);

					if (dialogResult.Equals(DialogResult.Yes) || dialogResult.Equals(DialogResult.OK))
					{
						try
						{
							if (AutoUpdater.DownloadUpdate(args))
							{
								Application.Exit();
							}
						}
						catch (Exception exception)
						{
							MessageBox.Show(exception.Message, exception.GetType().ToString(), MessageBoxButtons.OK,
								MessageBoxIcon.Error);
						}
					}
				}
				else
				{
					if (!this.SilentUpdate)
					{
						MessageBox.Show(this.res_man.GetString("update_no_update_msg"), this.res_man.GetString("update_no_update"),
												MessageBoxButtons.OK, MessageBoxIcon.Information);
					}
				}

				//Guarda la ultima fecha de Checkeo, para evitar estar chequeando cada vez que cierra el programa.
				Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
				config.AppSettings.Settings["LastUpdateCheck"].Value = DateTime.Today.ToShortDateString();
				config.Save(ConfigurationSaveMode.Modified);
				ConfigurationManager.RefreshSection("appSettings");
			}
			else
			{
				if (args.Error is System.Net.WebException)
				{
					MessageBox.Show(this.res_man.GetString("update_conn_error"),
						@"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
				else
				{
					MessageBox.Show(args.Error.Message,
						args.Error.GetType().ToString(), MessageBoxButtons.OK,
						MessageBoxIcon.Error);
				}
			}
		}

		

		#endregion

		#region Menus

		private void LoadMenus(string SelectedLang)
		{
			try
			{
				// Set up color theme options.
				#region Root Menus

				string Fname = this.MyTheme.Colors.Window_FontName;
				float Fsize = float.Parse(this.MyTheme.Colors.Window_Fontsize);

				this.menuBar1.Font = new Font(Fname, Fsize);

				this.menuBar1.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BackColor);
				this.menuBar1.BackGradientColor = new GradientColor(ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BackColor));

				this.menuBar1.BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
				this.menuBar1.SeparatorColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_SeparatorColor);

				this.menuBar1.TextColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_ForeColor);
				this.menuBar1.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_ForeColor);

				this.menuBar1.HoverBackGradientColor = new GradientColor(ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_HightLight_BackColor));
				this.menuBar1.HoverTextColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_HightLight_ForeColor);
				this.menuBar1.HoverBorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_HightLight_BorderColor);

				#endregion

				#region First Level Menus

				this.menuBar1.Popup.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BackColor);
				this.menuBar1.Popup.BackGradientColor = new GradientColor(ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BackColor));

				this.menuBar1.Popup.BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BorderColor);
				this.menuBar1.Popup.SeparatorColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_SeparatorColor);

				this.menuBar1.Popup.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_ForeColor);
				this.menuBar1.Popup.TextColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_ForeColor);

				this.menuBar1.Popup.HoverBackGradientColor = new GradientColor(ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_HightLight_BackColor));
				this.menuBar1.Popup.HoverTextColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_HightLight_ForeColor);
				this.menuBar1.Popup.HoverBorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_HightLight_BorderColor);

				#endregion

				#region Second Level Menus

				this.menuBar1.Popup.Popup.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BackColor);
				this.menuBar1.Popup.Popup.BackGradientColor = new GradientColor(ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BackColor));
				this.menuBar1.Popup.Popup.TextColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_ForeColor);
				this.menuBar1.Popup.Popup.ForeColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_ForeColor);
				this.menuBar1.Popup.Popup.BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BorderColor);
				this.menuBar1.Popup.Popup.SeparatorColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_SeparatorColor);
				this.menuBar1.Popup.Popup.HoverBackGradientColor = new GradientColor(ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_HightLight_BackColor));
				this.menuBar1.Popup.Popup.HoverTextColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_HightLight_ForeColor);
				this.menuBar1.Popup.Popup.HoverBorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_HightLight_BorderColor);

				#endregion

				this.menuBar1.AlwaysShowPopupMenu = true;
				this.menuBar1.MenuItems.Clear();

				//Crea los Menus
				#region File menu

				FlatMenuItem fileMenu = new FlatMenuItem(this.res_man.GetString("menu_file"));

				AddLinkItem(fileMenu, this.res_man.GetString("menu_file_new"), "menu_file_new");
				AddLinkItem(fileMenu, this.res_man.GetString("menu_file_open"), "menu_file_open");

				AddLinkItem(fileMenu, this.res_man.GetString("menu_file_save"), "menu_file_save");
				AddLinkItem(fileMenu, this.res_man.GetString("menu_file_save_as"), "menu_file_save_as");
				fileMenu.MenuItems.AddSeparator();
				AddLinkItem(fileMenu, this.res_man.GetString("file_asoc_title"), "file_asoc_title");
				fileMenu.MenuItems.AddSeparator();
				AddLinkItem(fileMenu, this.res_man.GetString("mnu_file_print"), "mnu_file_print");
				AddLinkItem(fileMenu, this.res_man.GetString("mnu_file_exit"), "mnu_file_exit");

				#endregion

				#region Format menu

				FlatMenuItem editMenu = new FlatMenuItem(this.res_man.GetString("menu_format"));

				AddLinkItem(editMenu, this.res_man.GetString("menu_format_font"), "menu_format_font");
				FlatMenuItem LanguagesMenu = AddLinkItem(editMenu, this.res_man.GetString("menu_format_lang"), String.Empty);

				AddLinkItem(LanguagesMenu, this.res_man.GetString("language_en"), "language_en", Util.IIf(SelectedLang == "en", true, false));
				AddLinkItem(LanguagesMenu, this.res_man.GetString("language_es"), "language_es", Util.IIf(SelectedLang == "es", true, false));
				AddLinkItem(LanguagesMenu, this.res_man.GetString("language_fr"), "language_fr", Util.IIf(SelectedLang == "fr", true, false));
				AddLinkItem(LanguagesMenu, this.res_man.GetString("language_de"), "language_de", Util.IIf(SelectedLang == "de", true, false));
				AddLinkItem(LanguagesMenu, this.res_man.GetString("language_pt"), "language_pt", Util.IIf(SelectedLang == "pt", true, false));
				AddLinkItem(LanguagesMenu, this.res_man.GetString("language_ru"), "language_ru", Util.IIf(SelectedLang == "ru", true, false));

				AddLinkItem(editMenu, string.Format("{0}   CTRL + G", this.res_man.GetString("menu_format_goto")), "menu_format_goto");

				#endregion

				#region View menu

				FlatMenuItem viewMenu = new FlatMenuItem(this.res_man.GetString("mnu_view"));

				AddLinkItem(viewMenu, this.res_man.GetString("mnu_view_about"), "mnu_view_about");
				AddLinkItem(viewMenu, this.res_man.GetString("mnu_view_updates"), "mnu_view_updates");
				viewMenu.MenuItems.AddSeparator();
				AddLinkItem(viewMenu, this.res_man.GetString("mnu_view_lines"), "mnu_view_lines");

				string _curTheme = Util.AppConfig_GetValue("Theme").NVL("theme_dark");
				FlatMenuItem ThemesMenu = AddLinkItem(viewMenu, this.res_man.GetString("mnu_view_theme"), String.Empty);
				AddLinkItem(ThemesMenu, this.res_man.GetString("theme_dark"), "theme_dark", Util.IIf(_curTheme == "theme_dark", true, false));
				AddLinkItem(ThemesMenu, this.res_man.GetString("theme_clear"), "theme_clear", Util.IIf(_curTheme == "theme_clear", true, false));
				AddLinkItem(ThemesMenu, this.res_man.GetString("theme_custom"), "theme_custom", Util.IIf(_curTheme == "theme_custom", true, false));

				#endregion

				// Add the four top-level menus to menu bar.
				this.menuBar1.MenuItems.Add(fileMenu);
				this.menuBar1.MenuItems.Add(editMenu);
				this.menuBar1.MenuItems.Add(viewMenu);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private FlatMenuItem AddLinkItem(FlatMenuItem menuItem, string text, string url, bool Checked = false)
		{
			// Create a new menu item.
			FlatMenuItem newItem = new FlatMenuItem();
			newItem.Text = text;
			newItem.Tag = url;

			if (Checked)
			{
				newItem.Style = FlatMenuItemStyle.Check;
				newItem.Checked = Checked;
			}

			// Add it to parent item.
			menuItem.MenuItems.Add(newItem);

			// Add a Click handler and URL mapping entry to hashtable.
			AddLink(newItem, url);

			return newItem;
		}
		private void AddLink(FlatMenuItem menuItem, string url)
		{
			// Add a Click handler:
			menuItem.Click += new System.EventHandler(menuItem_Click);

			// Add a URL mapping entry to hashtable.
			if (url != String.Empty)
			{

			}
		}

		/* AQUI SE RESPONDE A LOS MENUS  */
		private void menuItem_Click(object obj, System.EventArgs e)
		{
			FlatMenuItem item = obj as FlatMenuItem;
			if (item != null && item.Tag != null)
			{
				switch (item.Tag.ToString())
				{
					case "menu_file_new": NewFile(); break;
					case "menu_file_open": OpenFile(); break;

					case "menu_file_save": SaveFile(); break;
					case "menu_file_save_as": SaveFile(true); break;

					case "file_asoc_title":
						FileAsocForm _Form = new FileAsocForm(this.res_man);
						_Form.ShowDialog();
						break;

					case "mnu_file_print": PrintFile(); break;
					case "mnu_file_exit": Close(); break;

					case "menu_format_font": Changefont(); break;

					case "language_en": SetLanguage("en"); break;
					case "language_es": SetLanguage("es"); break;
					case "language_fr": SetLanguage("fr"); break;
					case "language_de": SetLanguage("de"); break;
					case "language_pt": SetLanguage("pt"); break;
					case "language_ru": SetLanguage("ru"); break;

					case "menu_format_goto": GotoLine(); break;

					case "mnu_view_about":
						Loadfile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "GPL_Licence.txt"));
						AboutForm _AboutForm = new AboutForm(this.res_man);
						_AboutForm.ShowDialog();
						break;

					case "mnu_view_updates":
						this.SilentUpdate = false; CheckForUpdates();
						break;

					case "mnu_view_lines":
						this.ShowLines = !this.ShowLines;
						if (this.ShowLines)
						{
							this.splitContainer1.Panel1Collapsed = false;
						}
						else
						{
							this.splitContainer1.Panel1Collapsed = true;
						}
						Util.AppConfig_SetValue("LineNumbers", this.txLines.Visible.ToString());
						break;

					case "theme_dark":
						Util.AppConfig_SetValue("Theme", "theme_dark");
						LoadTheme("theme_dark");
						LoadMenus(Util.AppConfig_GetValue("Language"));
						break;

					case "theme_clear":
						Util.AppConfig_SetValue("Theme", "theme_clear");
						LoadTheme("theme_clear");
						LoadMenus(Util.AppConfig_GetValue("Language"));
						break;

					case "theme_custom":
						Util.AppConfig_SetValue("Theme", "theme_custom");
						LoadTheme("theme_custom");
						LoadMenus(Util.AppConfig_GetValue("Language"));

						this.CustomizingTheme = true; //<- Cuando Guarde los cambios los muestra
						Loadfile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "theme_custom.json"));
						item.Checked = true;
						break;

					default:
						break;
				}
			}
		}
		private void menuBar1_MouseMove(object sender, MouseEventArgs e)
		{
			//Permite Mover la Ventana sin Titulo.
			if (e.Button == MouseButtons.Left)
			{
				ReleaseCapture();
				SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
			}
		}



		public void AddContextMenuEx(RichTextBox rtb)
		{
			if (this.FPM == null)
			{
				this.FPM = new FlatPopupMenu()
				{
					BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BackColor),
					BackGradientColor = new GradientColor(ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BackColor)),
					BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BorderColor),
					SeparatorColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_SeparatorColor),
					TextColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_ForeColor),

					HoverBackGradientColor = new GradientColor(ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_HightLight_BackColor)),
					HoverTextColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_HightLight_ForeColor),
					HoverBorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_HightLight_BorderColor),
				};
				this.FPM.Popup.BackGradientColor = new GradientColor(ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BackColor));
				this.FPM.Popup.BorderColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Menus_BorderColor);

				FlatMenuItem mnuUndo = new FlatMenuItem();
				mnuUndo.Text = this.res_man.GetString("contex_undo"); // "Undo"; 
				mnuUndo.Click += (sender, e) => rtb.Undo();
				this.FPM.MenuItems.Add(mnuUndo);


				FlatMenuItem mnuReDo = new FlatMenuItem();
				mnuReDo.Text = this.res_man.GetString("contex_redo"); // "Redo";
				mnuReDo.Click += (sender, e) => rtb.Redo();
				this.FPM.MenuItems.Add(mnuReDo);

				this.FPM.MenuItems.AddSeparator();

				FlatMenuItem mnuCut = new FlatMenuItem();
				mnuCut.Text = this.res_man.GetString("contex_cut"); // "Cut";
				mnuCut.Click += (sender, e) => rtb.Cut();
				this.FPM.MenuItems.Add(mnuCut);

				FlatMenuItem mnuCopy = new FlatMenuItem();
				mnuCopy.Text = this.res_man.GetString("contex_copy"); // "Copy";
				mnuCopy.Click += (sender, e) =>
				{
					//rtb.Copy(); //<- Copia en RTF

					//Copia Texto Plano:
					DataObject dto = new DataObject();
					//dto.SetText(rtb.SelectedRtf, TextDataFormat.Rtf);
					dto.SetText(rtb.SelectedText, TextDataFormat.UnicodeText);
					Clipboard.Clear();
					Clipboard.SetDataObject(dto, true);
				};
				this.FPM.MenuItems.Add(mnuCopy);

				FlatMenuItem mnuPaste = new FlatMenuItem();
				mnuPaste.Text = this.res_man.GetString("contex_paste"); // "Paste";
				mnuPaste.Click += (sender, e) => rtb.Paste();
				this.FPM.MenuItems.Add(mnuPaste);

				FlatMenuItem mnuDelete = new FlatMenuItem();
				mnuDelete.Text = this.res_man.GetString("contex_delete"); // "Delete";
				mnuDelete.Click += (sender, e) => rtb.SelectedText = "";
				this.FPM.MenuItems.Add(mnuDelete);

				this.FPM.MenuItems.AddSeparator();

				FlatMenuItem mnuSelectAll = new FlatMenuItem();
				mnuSelectAll.Text = this.res_man.GetString("contex_select_all"); // "Select All";
				mnuSelectAll.Click += (sender, e) => rtb.SelectAll();
				this.FPM.MenuItems.Add(mnuSelectAll);

				this.FPM.VisibleChanged += (sender, e) =>
				{
					mnuUndo.Enabled = !rtb.ReadOnly && rtb.CanUndo;
					mnuReDo.Enabled = !rtb.ReadOnly && rtb.CanRedo;
					mnuCut.Enabled = !rtb.ReadOnly && rtb.SelectionLength > 0;
					mnuCopy.Enabled = rtb.SelectionLength > 0;
					mnuPaste.Enabled = !rtb.ReadOnly && Clipboard.ContainsText();
					mnuDelete.Enabled = !rtb.ReadOnly && rtb.SelectionLength > 0;
					mnuSelectAll.Enabled = rtb.TextLength > 0 && rtb.SelectionLength < rtb.TextLength;
				};
			}

		}

		#endregion

		#region Eventos de Controles

		//Permite Mover la Ventana sin Titulo.
		private void panel_TOP_MouseMove(object sender, MouseEventArgs e)
		{
			//Permite Mover la Ventana sin Titulo.
			if (e.Button == MouseButtons.Left)
			{
				//ReleaseCapture();
				//SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);

				this.panel_TOP.Capture = false;
				Message msg = Message.Create(this.Handle, WM_NCLBUTTONDOWN, (IntPtr)HT_CAPTION, IntPtr.Zero);
				WndProc(ref msg);
			}
		}
		private void lblWindowTitle_MouseMove(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				//ReleaseCapture();
				//SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);

				this.lblWindowTitle.Capture = false;
				Message msg = Message.Create(this.Handle, WM_NCLBUTTONDOWN, (IntPtr)HT_CAPTION, IntPtr.Zero);
				WndProc(ref msg);
			}
		}

		private void cmdWindow_Maximize_Click(object sender, EventArgs e)
		{
			if (this.IsMaximized)
			{
				this.Size = new Size(this.WindowSize.Width, this.WindowSize.Height);
				this.Location = new Point(this.WindowSize.X, this.WindowSize.Y);
				this.IsMaximized = false;

				//Vuelve al icono de Maximizar:
				this.cmdWindow_Maximize.Image = IconChar.Square.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Window_ForeColor), 22);
			}
			else
			{
				MaximizeWindow(); //Cambia el icono a modo Restaurar Ventana
				this.cmdWindow_Maximize.Image = IconChar.WindowRestore.ToBitmap(ColorTranslator.FromHtml(this.MyTheme.Colors.Window_ForeColor), 22);
			}
		}
		private void cmdWindow_Maximize_MouseEnter(object sender, EventArgs e)
		{
			this.cmdWindow_Maximize.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_HoverColor);
		}
		private void cmdWindow_Maximize_MouseLeave(object sender, EventArgs e)
		{
			this.cmdWindow_Maximize.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
		}

		private void cmdWindow_Minimize_Click(object sender, EventArgs e)
		{
			this.WindowState = FormWindowState.Minimized;
		}
		private void cmdWindow_Minimize_MouseEnter(object sender, EventArgs e)
		{
			this.cmdWindow_Minimize.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Button_HoverColor);
		}
		private void cmdWindow_Minimize_MouseLeave(object sender, EventArgs e)
		{
			this.cmdWindow_Minimize.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
		}

		private void cmdCloseWindow_Click(object sender, EventArgs e)
		{
			Close();
		}
		private void cmdCloseWindow_MouseEnter(object sender, EventArgs e)
		{
			this.cmdWindow_Close.BackColor = Color.FromArgb(230, 26, 77); //<- Rojo
		}
		private void cmdCloseWindow_MouseLeave(object sender, EventArgs e)
		{
			this.cmdWindow_Close.BackColor = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BackColor);
		}

		private void cmdSaveChanges_Click(object sender, EventArgs e)
		{
			SaveFile();
			if (this.CustomizingTheme)
			{
				LoadTheme("theme_custom");
				LoadMenus(Util.AppConfig_GetValue("Language"));
			}
		}

		private void memoTEXTO_MouseUp(object sender, MouseEventArgs e)
		{
			if (e.Button != MouseButtons.Right) return;

			// Display the popup menu.
			this.FPM.TrackPopupMenu(this, e.X, e.Y);
		}
		private void memoTEXTO_VScroll(object sender, EventArgs e)
		{
			if (!this.memoTEXTO.Scrolling)
			{
				//Sincroniza el VScrollbar:
				Point pt = new Point();
				SendMessage(this.memoTEXTO.Handle, EM_GETSCROLLPOS, 0, ref pt);
				this.scrollBarEx_V.Value = pt.Y;
			}
		}
		private void memoTEXTO_HScroll(object sender, EventArgs e)
		{
			Point pt = new Point();
			SendMessage(this.memoTEXTO.Handle, EM_GETSCROLLPOS, 0, ref pt);
			this.scrollBarEx_H.Value = pt.X;
		}
		private void memoTEXTO_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.G && (e.Control))
			{
				GotoLine();
			}
		}
		private void memoTEXTO_TextChanged(object sender, EventArgs e)
		{
			//actualiza el numero de lineas cuando se cambian
			if (this.memoTEXTO.Lines.Length != this.LinesCount)
			{
				UpdateLinesCount(this.memoTEXTO.Text);
			}
			this.IsDirty = true;
		}
		private void memoTEXTO_LinkClicked(object sender, LinkClickedEventArgs e)
		{
			//Abre el link clickeado en el Navegador Predeterminado:
			System.Diagnostics.Process.Start(e.LinkText);
		}
		private void memoTEXTO_ContentsResized(object sender, ContentsResizedEventArgs e)
		{
			this.heightContentRtb = e.NewRectangle.Height; Determine_VMax(this.memoTEXTO);
			this.widthContentRtb = e.NewRectangle.Width; Determine_HMax(this.memoTEXTO);
		}
		private void memoTEXTO_Resize(object sender, EventArgs e)
		{
			Determine_VMax(this.memoTEXTO);
			Determine_HMax(this.memoTEXTO);
		}
		private void memoTEXTO_SelectionChanged(object sender, EventArgs e)
		{
			int lineIndex = this.memoTEXTO.GetLineFromCharIndex(this.memoTEXTO.SelectionStart) + 1;
			ShowLine(lineIndex);
		}

		private void scrollBarEx_H_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			Point pt = new Point();
			SendMessage(this.memoTEXTO.Handle, EM_GETSCROLLPOS, 0, ref pt);
			pt.X = e.NewValue;
			SendMessage(this.memoTEXTO.Handle, EM_SETSCROLLPOS, 0, ref pt);
			this.memoTEXTO.Focus();
		}
		private void scrollBarEx_V_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			Point pt = new Point();
			SendMessage(this.memoTEXTO.Handle, EM_GETSCROLLPOS, 0, ref pt);
			pt.Y = e.NewValue;
			SendMessage(this.memoTEXTO.Handle, EM_SETSCROLLPOS, 0, ref pt);
			SendMessage(this.txLines.Handle, EM_SETSCROLLPOS, 0, ref pt);
			this.memoTEXTO.Focus();
		}

		private void txtSearch_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == System.Windows.Forms.Keys.Enter)
			{
				if (!this.txtSearch_2.Text.EmptyOrNull())
				{
					string SearchString = this.txtSearch_2.Text.NVL(string.Empty);
					string WholeText = this.memoTEXTO.Text;

					var t = System.Threading.Tasks.Task.Factory.StartNew(delegate
					{
						FindText(SearchString, WholeText);
					});
				}
			}
		}
		private void cmdSearch_Click(object sender, EventArgs e)
		{
			string SearchString = this.txtSearch_2.Text.NVL(string.Empty);
			string WholeText = this.memoTEXTO.Text;

			switch (this.cmdSearch_2.Tag.ToString())
			{
				case "Search":
					var t = System.Threading.Tasks.Task.Factory.StartNew(delegate
					{
						FindText(SearchString, WholeText);
					});
					break;

				case "Clear":
					ClearSearch();
					break;

				default: break;
			}
		}
		private void txtSearch_2_MouseClick(object sender, MouseEventArgs e)
		{
			this.txtSearch_2.SelectAll();
		}
		private void cmdSearch_2_Click(object sender, EventArgs e)
		{
			string SearchString = this.txtSearch_2.Text.NVL(string.Empty);
			string WholeText = this.memoTEXTO.Text;

			switch (this.cmdSearch_2.Tag.ToString())
			{
				case "Search":
					var t = System.Threading.Tasks.Task.Factory.StartNew(delegate
					{
						FindText(SearchString, WholeText);
					});
					break;

				case "Clear":
					ClearSearch();
					break;

				default: break;
			}
		}

		private void panelSearchBox_Paint(object sender, PaintEventArgs e)
		{
			Graphics g = e.Graphics;
			g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBilinear;
			//g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
			//g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
			g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

			Color _Color = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BorderColor);
			g.DrawRoundedRectangle(new Pen(_Color), 2, 2, this.panelSearchBox.Width - 4, this.panelSearchBox.Height - 6, 8);
			//g.DrawRoundedRectangle(new Pen(ControlPaint.Light(_Color, 0.00f)), 2, 2, panelSearchBox.Width - 4, panelSearchBox.Height - 6, 8);
		}
		private void ReplaceBox_Paint(object sender, PaintEventArgs e)
		{
			Graphics g = e.Graphics;
			g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBilinear;
			//g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
			//g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
			g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

			Color _Color = ColorTranslator.FromHtml(this.MyTheme.Colors.Window_BorderColor);

			g.DrawRoundedRectangle(new Pen(_Color), 2, 2, this.ReplaceBox.Width - 4, this.ReplaceBox.Height - 6, 8);
			//g.DrawRoundedRectangle(new Pen(ControlPaint.Light(_Color, 0.00f)), 2, 2, ReplaceBox.Width - 4, ReplaceBox.Height - 6, 8);
		}

		private void cmdFindNext_Click(object sender, EventArgs e)
		{
			FindNext(true);
		}

		private void txtReplace_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == System.Windows.Forms.Keys.Enter)
			{
				ReplaceNext(this.txtReplace_2.Text);
			}
		}
		private void cmdReplace_Click(object sender, EventArgs e)
		{
			this.ReplaceBox.Visible = true;
			this.cmdReplaceNext_2.Visible = !this.cmdReplaceNext_2.Visible;
			this.cmdReplaceAll_2.Visible = !this.cmdReplaceAll_2.Visible;
			this.txtReplace_2.Visible = !this.txtReplace_2.Visible;
			this.txtReplace_2.Focus();
		}
		private void cmdReplaceNext_Click(object sender, EventArgs e)
		{
			ReplaceNext(this.txtReplace_2.Text);
		}
		private void cmdReplaceAll_Click(object sender, EventArgs e)
		{
			ReplaceAll(this.txtSearch_2.Text, this.txtReplace_2.Text);
		}

		private void Scroll_Bar1_VScroll(object sender, EventArgs e)
		{
			this.memoTEXTO.Scrolling = true;
			int LinePos = (int)sender;
			this.memoTEXTO.ScrollToLine(LinePos);
			this.memoTEXTO.Scrolling = false;
		}
		private void Scroll_Bar1_OnTrackArea_Click(object sender, EventArgs e)
		{
			//if (!this.memoTEXTO.Scrolling)
			//{
			//	this.memoTEXTO.ScrollToLine(this.scroll_Bar1.Value);
			//}
		}

		private const int Panel1MaxWidth = 55;
		private void splitContainer1_SizeChanged(object sender, EventArgs e)
		{
			if (this.splitContainer1.Panel1.Width > Panel1MaxWidth)
			{
				this.splitContainer1.SplitterDistance = Panel1MaxWidth;
			}
		}
		private void splitContainer1_SplitterMoved(object sender, SplitterEventArgs e)
		{
			if (this.splitContainer1.Panel1.Width > Panel1MaxWidth)
			{
				this.splitContainer1.SplitterDistance = Panel1MaxWidth;
			}
		}

		private void MainForm_ResizeEnd(object sender, EventArgs e)
		{
			Invalidate(false);
			Update();
		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{
			var mouseEventArgs = e as MouseEventArgs;
			if (mouseEventArgs != null) Console.WriteLine("X= " + mouseEventArgs.X + " Y= " + mouseEventArgs.Y);

			int pos = mouseEventArgs.Y;
			int offset = 20;
			int MaxPos = this.LinesCount + (offset * 2); //= this.pictureBox1.Heigh
			int Line = (pos * MaxPos) / this.VScrollBar_Box.Height;
			Console.WriteLine("Pos= " + mouseEventArgs.Y + " Line= " + Line);

			GoToLine(Line - offset);
		}

		#endregion
	}
}