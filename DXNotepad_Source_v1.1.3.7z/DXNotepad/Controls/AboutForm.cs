﻿using System;
using System.Configuration;
using System.Resources;
using System.Windows.Forms;
using AutoUpdaterDotNET;

namespace DXNotepad.Controls
{
	public partial class AboutForm : Form
	{
		private ResourceManager res_man;

		public AboutForm(ResourceManager Language)
		{
			InitializeComponent();
			this.res_man = Language;
		}

		private void AboutForm_Load(object sender, EventArgs e)
		{
			string version = ConfigurationManager.AppSettings["Version"].ToString(); // Assembly.GetExecutingAssembly().GetName().Version.ToString();

			this.Text = this.res_man.GetString("mnu_view_about");
			this.lblProgram.Text = System.IO.Path.GetFileNameWithoutExtension(System.AppDomain.CurrentDomain.FriendlyName);
			this.lblVersion.Text = string.Format("Version: {0}", version);

			this.cmdCheckUpdates.Text = this.res_man.GetString("mnu_view_updates");
		}

		private void cmdCheckUpdates_Click(object sender, EventArgs e)
		{
			AutoUpdater.ReportErrors = true;
			AutoUpdater.InstalledVersion = new Version(ConfigurationManager.AppSettings["Version"].ToString());
			AutoUpdater.CheckForUpdateEvent += AutoUpdater_CheckForUpdateEvent;
			AutoUpdater.Start(@"https://raw.githubusercontent.com/BlueMystical/DXNotepad/main/latest_version_info.xml");
		}
		private void AutoUpdater_CheckForUpdateEvent(UpdateInfoEventArgs args)
		{
			//https://github.com/ravibpatel/AutoUpdater.NET

			if (args.Error != null)
			{
				MessageBox.Show(args.Error.Message + args.Error.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			if (args.Error == null)
			{
				if (args.IsUpdateAvailable)
				{
					DialogResult dialogResult;
					if (args.Mandatory.Value)
					{
						//$@"There is new version {args.CurrentVersion} available. You are using version {args.InstalledVersion}. This is required update. Press Ok to begin updating the application.",
						dialogResult =
							MessageBox.Show(string.Format(this.res_man.GetString("update_mandatroy_msg"), args.CurrentVersion, args.InstalledVersion),
								this.res_man.GetString("update_available"),
								MessageBoxButtons.OK, MessageBoxIcon.Information);
					}
					else
					{
						//$@"There is new version {args.CurrentVersion} available. You are using version {args.InstalledVersion}. Do you want to update the application now?"
						dialogResult =
							MessageBox.Show(
								string.Format(this.res_man.GetString("update_optional_msg"), args.CurrentVersion, args.InstalledVersion),
								this.res_man.GetString("update_available"),
								MessageBoxButtons.YesNo,
								MessageBoxIcon.Information);
					}

					// Uncomment the following line if you want to show standard update dialog instead.
					AutoUpdater.ShowUpdateForm(args);

					//if (dialogResult.Equals(DialogResult.Yes) || dialogResult.Equals(DialogResult.OK))
					//{
					//	try
					//	{
					//		if (AutoUpdater.DownloadUpdate(args))
					//		{
					//			Application.Exit();
					//		}
					//	}
					//	catch (Exception exception)
					//	{
					//		MessageBox.Show(exception.Message, exception.GetType().ToString(), MessageBoxButtons.OK,
					//			MessageBoxIcon.Error);
					//	}
					//}
				}
				else
				{
					MessageBox.Show(this.res_man.GetString("update_no_update_msg"), this.res_man.GetString("update_no_update"),
						MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
			}
			else
			{
				if (args.Error is System.Net.WebException)
				{
					MessageBox.Show(this.res_man.GetString("update_conn_error"),
						@"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
				else
				{
					MessageBox.Show(args.Error.Message,
						args.Error.GetType().ToString(), MessageBoxButtons.OK,
						MessageBoxIcon.Error);
				}
			}
		}

		private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start(linkLabel1.Text);
		}
	}
}
