﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DXNotepad.Clases;

namespace DXNotepad.Controls
{
	public partial class TextBoxEx : UserControl
	{
		public TextBoxEx()
		{
			InitializeComponent();
		}

		private void TextBoxEx_Paint(object sender, PaintEventArgs e)
		{
			GraphicsExtension.DrawRoundedRectangle(e.Graphics, new Pen(this.ForeColor), 
				0, 0, this.Width - 1, this.Height - 1, 4);
			this.textBox1.BackColor = this.BackColor;
			this.textBox1.ForeColor = this.ForeColor;
		}
	}
}
