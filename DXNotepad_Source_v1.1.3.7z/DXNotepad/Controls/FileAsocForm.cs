﻿using System;
using System.IO;
using System.Linq;
using System.Resources;
using System.Windows.Forms;
using DXNotepad.Clases;

namespace DXNotepad.Controls
{
	public partial class FileAsocForm : Form
	{
		private ResourceManager res_man;    // declare Resource manager to access to specific cultureinfo

		public FileAsocForm(ResourceManager Language)
		{
			InitializeComponent();
			this.res_man = Language;
		}

		private void FileAsocForm_Load(object sender, EventArgs e)
		{
			try
			{
				this.Text = this.res_man.GetString("file_asoc_title");
				this.lblPromt.Text = this.res_man.GetString("file_asoc_prompt");
				this.cmdAsociar.Text = this.res_man.GetString("file_asoc_asoc");

				this.lblAddNewType.Text = this.res_man.GetString("file_asoc_new_type");
				this.cmdAddNewType.Text = this.res_man.GetString("agregar");

				for (int count = 0; count < this.checkedListBoxControl1.Items.Count; count++)
				{
					this.checkedListBoxControl1.SetItemChecked(count, true);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
		private void FileAsocForm_Shown(object sender, EventArgs e)
		{

		}

		private void cmdAsociar_Click(object sender, EventArgs e)
		{
			string AppExePath = AppDomain.CurrentDomain.BaseDirectory;
			string AppName = System.IO.Path.GetFileName(System.AppDomain.CurrentDomain.FriendlyName);

			//Obtiene los Indices de los elelmentos con Check:
			int[] indexes = this.checkedListBoxControl1.CheckedIndices.Cast<int>().ToArray();
			if (indexes != null && indexes.Length > 0)
			{
				foreach (int item in indexes)
				{
					FileAssociations.SetAssociation_User(this.checkedListBoxControl1.Items[item].ToString().Replace(".", ""), 
						Path.Combine(AppExePath, AppName), AppName);
				}
			}

			FileAssociations.ContextMenu_NewTextFile();

			MessageBox.Show(this.res_man.GetString("file_asoc_msg_ok"), this.res_man.GetString("exito"),
				MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void cmdAddNewType_Click(object sender, EventArgs e)
		{
			try
			{
				string new_type = this.txtAddNewType.Text;
				bool Continuar = true;

				//1. Revisar que no existe ya:
				int[] indexes = this.checkedListBoxControl1.CheckedIndices.Cast<int>().ToArray();
				if (indexes != null && indexes.Length > 0)
				{
					foreach (int item in indexes)
					{
						if (this.checkedListBoxControl1.Items[item].ToString() == new_type) Continuar = false;
					}
				}

				if (Continuar)
				{
					this.checkedListBoxControl1.Items.Add(new_type, CheckState.Checked);
				}
				else
				{
					MessageBox.Show(this.res_man.GetString("file_asoc_msg_err"), "Error",
						MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + ex.StackTrace, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
	}
}
