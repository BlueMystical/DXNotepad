﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace DXNotepad.Controls
{
	public class RichTextBoxEx : RichTextBox
	{
		#region Declaraciones API

		[DllImport("user32.dll")]
		private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		private static extern int GetScrollPos(IntPtr hWnd, int nBar);

		[DllImport("user32.dll")]
		private static extern int SetScrollPos(IntPtr hWnd, int nBar, int nPos, bool bRedraw);

		private const int SB_HORZ = 0x0;
		private const int SB_VERT = 0x1;

		private const int SB_LINEUP = 0;
		private const int SB_LINEDOWN = 1;
		private const int SB_PAGEUP = 2;
		private const int SB_PAGEDOWN = 3;
		private const int SB_TOP = 6;
		private const int SB_BOTTOM = 7;

		private const int SB_ENDSCROLL = 8;

		private const int WM_HSCROLL = 0x114;
		private const int WM_VSCROLL = 0x115;
		private const int WM_MOUSEWHEEL = 0x20A;
		private const int MK_CONTROL = 0x0008; //<- Tecla [CONTROL]
		private const int WM_SETREDRAW = 0x0b;

		#endregion

		#region Eventos y Propiedades Publicas

		public event EventHandler OnScrollMove; //<- Declaracion del Evento:
		public event EventHandler FocusChanged;

		public bool EnableMouseWheel { get; set; }
		public int HorizontalPosition
		{
			get { return GetScrollPos((IntPtr)this.Handle, SB_HORZ); }
			set { SetScrollPos((IntPtr)this.Handle, SB_HORZ, value, true); }
		}
		public int VerticalPosition
		{
			get { return GetScrollPos((IntPtr)this.Handle, SB_VERT); }
			set { SetScrollPos((IntPtr)this.Handle, SB_VERT, value, true); }
		}
		public bool Scrolling { get; set; }

		/// <summary>Control Compañero con el que se Sincroniza el Scroll Vertical.</summary>
		public Control Buddy { get; set; }

		#endregion

		#region Constructores y Overrides

		public RichTextBoxEx()
		{
			this.Multiline = true;
			this.WordWrap = false;
			this.ScrollBars = RichTextBoxScrollBars.Both;
			this.MouseWheel += Me_MouseWheel;
		}

		protected override void WndProc(ref Message m)
		{
			//Trap WM_VSCROLL and WM_MOUSEWHEEL message and pass to buddy
			if (this.Buddy != null && this.Buddy != this)
			{
				if (m.Msg == WM_MOUSEWHEEL)  //mouse wheel 
				{
					if ((int)m.WParam < 0)  //mouse wheel scrolls down
						SendMessage(this.Handle, (int)0x0115, new IntPtr(1), new IntPtr(0)); //WParam: 1- scroll down, 0- scroll up

					else if ((int)m.WParam > 0)
						SendMessage(this.Handle, (int)0x0115, new IntPtr(0), new IntPtr(0));

					return; //prevent base.WndProc() from messing synchronization up 
				}
				else if (m.Msg == WM_VSCROLL)
				{
					if (this.Buddy != this && !this.Scrolling && this.Buddy != null && this.Buddy.IsHandleCreated)
					{
						this.Scrolling = true;
						SendMessage(this.Buddy.Handle, m.Msg, m.WParam, m.LParam);
						this.Scrolling = false;
					}
				}
			}
			//}
			//else
			//{
			//	//m.WParam = IntPtr.Zero;
			//	//m.Result = IntPtr.Zero;
			//	//return;
			//}

			//do the usual
			base.WndProc(ref m);
		}

		#endregion

		#region Metodos Publicos

		public void BeginUpdate()
		{
			SendMessage(this.Handle, WM_SETREDRAW, (IntPtr)0, IntPtr.Zero);
		}
		public void EndUpdate()
		{
			SendMessage(this.Handle, WM_SETREDRAW, (IntPtr)1, IntPtr.Zero);
		}

		public int GetFirstSelectedLine()
		{
			var index = GetFirstCharIndexOfCurrentLine();
			return GetLineFromCharIndex(index);
		}
		public int GetFirstVisibleLine()
		{
			var index = GetCharIndexFromPosition(new Point(1, 1));
			return GetLineFromCharIndex(index);
		}

		public void ScrollToLine(int line)
		{
			if (line > 0)
			{
				// save the current selection to be restored later
				var selection = new { this.SelectionStart, this.SelectionLength };

				// select that line and scroll it to
				Select(GetFirstCharIndexFromLine(line) + 1, 0);
				ScrollToCaret();

				// restore selection
				Select(selection.SelectionStart, selection.SelectionLength);
			}
		}

		#endregion

		#region Metodos Privados

		private void Me_MouseWheel(object sender, MouseEventArgs e)
		{
			try
			{
				if (e.Delta < 0)
				{
					// Scrolls down
					SendMessage(this.Handle, WM_VSCROLL, (IntPtr)SB_LINEDOWN, IntPtr.Zero);
				}
				else
				{
					// Scrolls up
					SendMessage(this.Handle, WM_VSCROLL, (IntPtr)SB_LINEUP, IntPtr.Zero);
				}

				//Produce el evento Scroll y le pasa la posicion del Scroll Vertical
				OnScrollMove(e.Delta, e); //<- Disparador del Evento.
			}
			catch
			{
			}
		}

		private void RaiseFocusChanged()
		{
			var focusChanged = FocusChanged;
			if (focusChanged != null)
			{
				focusChanged(this, null);
			}
		}

		#endregion
	}
}