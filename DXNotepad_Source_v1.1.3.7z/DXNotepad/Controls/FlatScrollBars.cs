﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using FontAwesome.Sharp;

namespace DXNotepad.Controls
{
	#region Data Set 1     
	public sealed class Consts
	{
		public static int Padding = 10;
		public static int ScrollBarSize = 15;
		public static int ArrowButtonSize = 15;
		public static int MinimumThumbSize = 10;
	}

	public class ScrollValueEventArgs : EventArgs
	{
		public int Value { get; private set; }
		public ScrollValueEventArgs(int value)
		{
			this.Value = value;
		}
	}
	public class ScrollEventArgs : EventArgs
	{
		public int Value { get; private set; }
		public ScrollEventArgs(int value)
		{
			this.Value = value;
		}
	}
	public enum ScrollOrientation
	{
		Vertical,
		Horizontal
	}
	#endregion

	class Scroll_Bar : ScrollableControl
	{
		///         /// Colors         ///         
		public Color ScrollItemBackColor { get; set; }
		public Color ArrowColor { get; set; }
		public Color HighlightLine { get; set; }
		///         /// Colors         ///        

		public event EventHandler<ScrollValueEventArgs> ValueChanged;
		public event EventHandler VScroll;  //<- 
		public event EventHandler OnTrackArea_Click;

		#region Field Region     

		private ScrollOrientation _scrollOrientation;
		private int _value;
		private int _minimum = 0;
		private int _maximum = 100;
		private int _viewSize;
		private Rectangle _trackArea;
		private float _viewContentRatio;
		private Rectangle _thumbArea;
		private Rectangle _upArrowArea;
		private Rectangle _downArrowArea;
		private bool _thumbHot;
		private bool _upArrowHot;
		private bool _downArrowHot;
		private bool _thumbClicked;
		private bool _upArrowClicked;
		private bool _downArrowClicked;
		private bool _isScrolling;
		private int _initialValue;
		private Point _initialContact;
		public System.Windows.Forms.Timer _scrollTimer;

		#endregion

		#region Property Region     
		
		[Category("Behavior")]
		[Description("The orientation type of the scrollbar.")]
		[DefaultValue(ScrollOrientation.Vertical)]
		public ScrollOrientation ScrollOrientation
		{
			get { return this._scrollOrientation; }
			set
			{
				this._scrollOrientation = value;
				UpdateScrollBar();
			}
		}

		[Category("Behavior")]
		[Description("The value that the scroll thumb position represents.")]
		[DefaultValue(0)]
		public int Value
		{
			get { return this._value; }
			set
			{
				if (value < this.Minimum)
					value = this.Minimum;

				var maximumValue = this.Maximum - this.ViewSize;

				if (value > maximumValue)
					value = maximumValue;

				if (this._value == value)
					return;

				this._value = value;
				UpdateThumb(true);

				if (ValueChanged != null)
					ValueChanged(this, new ScrollValueEventArgs(this.Value));
			}
		}

		[Category("Behavior")]
		[Description("The lower limit value of the scrollable range.")]
		[DefaultValue(0)]
		public int Minimum
		{
			get { return this._minimum; }
			set
			{
				this._minimum = value;
				UpdateScrollBar();
			}
		}

		[Category("Behavior")]
		[Description("The upper limit value of the scrollable range.")]
		[DefaultValue(100)]
		public int Maximum
		{
			get { return this._maximum; }
			set
			{
				this._maximum = value;
				UpdateScrollBar();
			}
		}

		[Category("Behavior")]
		[Description("The view size for the scrollable area.")]
		[DefaultValue(0)]
		public int ViewSize
		{
			get { return this._viewSize; }
			set
			{
				this._viewSize = value;
				UpdateScrollBar();
			}
		}

		public new bool Visible
		{
			get { return base.Visible; }
			set
			{
				if (base.Visible == value)
					return;
				base.Visible = value;
			}
		}
		
		#endregion

		public void UpdateScrollBar()
		{
			if (this.ViewSize >= this.Maximum)
				return;
			var area = this.ClientRectangle;

			// Cap to maximum value             
			var maximumValue = this.Maximum - this.ViewSize;
			if (this.Value > maximumValue)
				this.Value = maximumValue;

			// Arrow buttons            
			if (this._scrollOrientation == ScrollOrientation.Vertical)
			{
				this._upArrowArea = new Rectangle(area.Left, area.Top, Consts.ArrowButtonSize, Consts.ArrowButtonSize);
				this._downArrowArea = new Rectangle(area.Left, area.Bottom - Consts.ArrowButtonSize, Consts.ArrowButtonSize, Consts.ArrowButtonSize);
			}
			else if (this._scrollOrientation == ScrollOrientation.Horizontal)
			{
				this._upArrowArea = new Rectangle(area.Left, area.Top, Consts.ArrowButtonSize, Consts.ArrowButtonSize);
				this._downArrowArea = new Rectangle(area.Right - Consts.ArrowButtonSize, area.Top, Consts.ArrowButtonSize, Consts.ArrowButtonSize);
			}
			// Track     
			if (this._scrollOrientation == ScrollOrientation.Vertical)
			{
				this._trackArea = new Rectangle(area.Left, area.Top + Consts.ArrowButtonSize, area.Width, area.Height - (Consts.ArrowButtonSize * 2));
			}
			else if (this._scrollOrientation == ScrollOrientation.Horizontal)
			{
				this._trackArea = new Rectangle(area.Left + Consts.ArrowButtonSize, area.Top, area.Width - (Consts.ArrowButtonSize * 2), area.Height);
			}
			// Thumb   
			UpdateThumb();
			Invalidate();
		}

		public void UpdateThumb(bool forceRefresh = false)
		{
			// Calculate size ratio      
			this._viewContentRatio = (float)this.ViewSize / (float)this.Maximum;
			var viewAreaSize = this.Maximum - this.ViewSize;
			var positionRatio = (float)this.Value / (float)viewAreaSize;

			// Update area          
			if (this._scrollOrientation == ScrollOrientation.Vertical)
			{
				var thumbSize = (int)(this._trackArea.Height * this._viewContentRatio);
				if (thumbSize < Consts.MinimumThumbSize)
					thumbSize = Consts.MinimumThumbSize;
				var trackAreaSize = this._trackArea.Height - thumbSize;
				var thumbPosition = (int)(trackAreaSize * positionRatio);
				this._thumbArea = new Rectangle(this._trackArea.Left + 3, this._trackArea.Top + thumbPosition, Consts.ScrollBarSize - 6, thumbSize);
			}
			else if (this._scrollOrientation == ScrollOrientation.Horizontal)
			{
				var thumbSize = (int)(this._trackArea.Width * this._viewContentRatio);
				if (thumbSize < Consts.MinimumThumbSize)
					thumbSize = Consts.MinimumThumbSize;
				var trackAreaSize = this._trackArea.Width - thumbSize;
				var thumbPosition = (int)(trackAreaSize * positionRatio);
				this._thumbArea = new Rectangle(this._trackArea.Left + thumbPosition, this._trackArea.Top + 3, thumbSize, Consts.ScrollBarSize - 6);
			}

			if (forceRefresh)
			{
				Invalidate();
				Update();
			}
		}

		public Scroll_Bar()
		{
			SetStyle(ControlStyles.OptimizedDoubleBuffer |
				ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);

			SetStyle(ControlStyles.Selectable, false);
			this._scrollTimer = new System.Windows.Forms.Timer();
			this._scrollTimer.Interval = 1;
			this._scrollTimer.Tick += ScrollTimerTick;
		}

		#region Event Handler Region    
		
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			UpdateScrollBar();
		}
		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			if (this._thumbArea.Contains(e.Location) && e.Button == MouseButtons.Left)
			{
				this._isScrolling = true;
				this._initialContact = e.Location;

				if (this._scrollOrientation == ScrollOrientation.Vertical)
					this._initialValue = this._thumbArea.Top;
				else
					this._initialValue = this._thumbArea.Left;

				Invalidate();
				OnTrackArea_Click(this, null);
				return;
			}
			if (this._upArrowArea.Contains(e.Location) && e.Button == MouseButtons.Left)
			{
				this._upArrowClicked = true;
				this._scrollTimer.Enabled = true;
				Invalidate();
				return;
			}
			if (this._downArrowArea.Contains(e.Location) && e.Button == MouseButtons.Left)
			{
				this._downArrowClicked = true;
				this._scrollTimer.Enabled = true;
				Invalidate();
				return;
			}
			if (this._trackArea.Contains(e.Location) && e.Button == MouseButtons.Left)
			{
				// Step 1. Check if our input is at least aligned with the thumb              
				if (this._scrollOrientation == ScrollOrientation.Vertical)
				{
					var modRect = new Rectangle(this._thumbArea.Left, this._trackArea.Top, this._thumbArea.Width, this._trackArea.Height);
					if (!modRect.Contains(e.Location))
						return;
				}
				else if (this._scrollOrientation == ScrollOrientation.Horizontal)
				{
					var modRect = new Rectangle(this._trackArea.Left, this._thumbArea.Top, this._trackArea.Width, this._thumbArea.Height);
					if (!modRect.Contains(e.Location))
						return;
				}
				// Step 2. Scroll to the area initially clicked.             
				if (this._scrollOrientation == ScrollOrientation.Vertical)
				{
					var loc = e.Location.Y;
					loc -= this._upArrowArea.Bottom - 1;
					loc -= this._thumbArea.Height / 2;
					ScrollToPhysical(loc);
				}
				else
				{
					var loc = e.Location.X;
					loc -= this._upArrowArea.Right - 1;
					loc -= this._thumbArea.Width / 2;
					ScrollToPhysical(loc);
				}
				// Step 3. Initiate a thumb drag.          
				this._isScrolling = true;
				this._initialContact = e.Location;
				this._thumbHot = true;
				if (this._scrollOrientation == ScrollOrientation.Vertical)
					this._initialValue = this._thumbArea.Top;
				else
					this._initialValue = this._thumbArea.Left;

				
				Invalidate();				
				return;
			}
		}

		protected override void OnMouseUp(MouseEventArgs e)
		{
			base.OnMouseUp(e);
			this._isScrolling = false;
			this._thumbClicked = false;
			this._upArrowClicked = false;
			this._downArrowClicked = false;
			Invalidate();
		}
		protected override void OnMouseMove(MouseEventArgs e)
		{
			base.OnMouseMove(e);
			if (!this._isScrolling)
			{
				var thumbHot = this._thumbArea.Contains(e.Location);
				if (this._thumbHot != thumbHot)
				{
					this._thumbHot = thumbHot;
					Invalidate();
				}
				var upArrowHot = this._upArrowArea.Contains(e.Location);
				if (this._upArrowHot != upArrowHot)
				{
					this._upArrowHot = upArrowHot;
					Invalidate();
				}
				var downArrowHot = this._downArrowArea.Contains(e.Location);
				if (this._downArrowHot != downArrowHot)
				{
					this._downArrowHot = downArrowHot;
					Invalidate();
				}
			}
			if (this._isScrolling)
			{
				if (e.Button != MouseButtons.Left)
				{
					OnMouseUp(null);
					return;
				}
				var difference = new Point(e.Location.X - this._initialContact.X, e.Location.Y - this._initialContact.Y);
				if (this._scrollOrientation == ScrollOrientation.Vertical)
				{
					var thumbPos = (this._initialValue - this._trackArea.Top);
					var newPosition = thumbPos + difference.Y;
					ScrollToPhysical(newPosition);

					VScroll(this.Value, null);
				}
				else if (this._scrollOrientation == ScrollOrientation.Horizontal)
				{
					var thumbPos = (this._initialValue - this._trackArea.Left);
					var newPosition = thumbPos + difference.X;
					ScrollToPhysical(newPosition);
				}
				UpdateScrollBar();
			}
		}
		protected override void OnMouseLeave(EventArgs e)
		{
			base.OnMouseLeave(e);
			this._thumbHot = false;
			this._upArrowHot = false;
			this._downArrowHot = false;
			Invalidate();
		}

		private void ScrollTimerTick(object sender, EventArgs e)
		{
			if (!this._upArrowClicked && !this._downArrowClicked)
			{
				this._scrollTimer.Enabled = false;
				return;
			}
			if (this._upArrowClicked)
				ScrollBy(-1);
			else if (this._downArrowClicked)
				ScrollBy(1);
		}

		//protected override void MouseWheel(EventArgs e)
		//{

		//}

		#endregion

		#region Method Region    
		public void ScrollTo(int position)
		{
			this.Value = position;
		}
		public void ScrollToPhysical(int positionInPixels)
		{
			var isVert = this._scrollOrientation == ScrollOrientation.Vertical;
			var trackAreaSize = isVert ? this._trackArea.Height - this._thumbArea.Height : this._trackArea.Width - this._thumbArea.Width;
			var positionRatio = (float)positionInPixels / (float)trackAreaSize;
			var viewScrollSize = (this.Maximum - this.ViewSize);
			var newValue = (int)(positionRatio * viewScrollSize);
			this.Value = newValue;
		}
		public void ScrollBy(int offset)
		{
			var newValue = this.Value + offset;
			ScrollTo(newValue);
		}
		public void ScrollByPhysical(int offsetInPixels)
		{
			var isVert = this._scrollOrientation == ScrollOrientation.Vertical;
			var thumbPos = isVert ? (this._thumbArea.Top - this._trackArea.Top) : (this._thumbArea.Left - this._trackArea.Left);
			var newPosition = thumbPos - offsetInPixels;
			ScrollToPhysical(newPosition);
		}
		#endregion

		#region Paint Region      
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				var g = e.Graphics;
				// Up arrow                 
				var upIcon = this._upArrowHot ? IconChar.ChevronDown.ToBitmap(Color.White, 16) : IconChar.ChevronDown.ToBitmap(Color.Yellow, 16);
				if (this._upArrowClicked)
					upIcon = IconChar.ChevronDown.ToBitmap(Color.Gray, 16);
				if (this._scrollOrientation == ScrollOrientation.Vertical)
					upIcon.RotateFlip(RotateFlipType.RotateNoneFlipY);
				else if (this._scrollOrientation == ScrollOrientation.Horizontal)
					upIcon.RotateFlip(RotateFlipType.Rotate90FlipNone);
				g.DrawImageUnscaled(upIcon,
					this._upArrowArea.Left + (this._upArrowArea.Width / 2) - (upIcon.Width / 2),
					this._upArrowArea.Top + (this._upArrowArea.Height / 2) - (upIcon.Height / 2));
				// Down arrow                 
				var downIcon = this._downArrowHot ? IconChar.ChevronDown.ToBitmap(Color.White, 16) : IconChar.ChevronDown.ToBitmap(Color.Yellow, 16);
				if (this._downArrowClicked)
					downIcon = IconChar.ChevronDown.ToBitmap(Color.Gray, 16);
				if (this._scrollOrientation == ScrollOrientation.Horizontal)
					downIcon.RotateFlip(RotateFlipType.Rotate270FlipNone);
				g.DrawImageUnscaled(downIcon,
					this._downArrowArea.Left + (this._downArrowArea.Width / 2) - (downIcon.Width / 2),
					this._downArrowArea.Top + (this._downArrowArea.Height / 2) - (downIcon.Height / 2));

				// Draw thumb                
				var scrollColor = this._thumbHot ? this.HighlightLine : this.ArrowColor;
				if (this._isScrolling)
					scrollColor = this.ScrollItemBackColor;

				using (var b = new SolidBrush(scrollColor))
				{
					g.FillRectangle(b, this._thumbArea);
				}
			}
			catch { }
		}
		#endregion

		public void Theme_Dark()
		{
			this.ScrollItemBackColor = Color.FromArgb(104, 104, 104);
			this.ArrowColor = Color.FromArgb(153, 153, 153);
			this.HighlightLine = Color.FromArgb(40, 40, 40);
			this.BackColor = Color.FromArgb(40, 40, 40);
		}
		public void Theme_Light()
		{
		}
		public void Theme_Blue() { }
	}
}