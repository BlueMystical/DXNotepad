﻿namespace DXNotepad.Controls
{
	partial class FileAsocForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.checkedListBoxControl1 = new System.Windows.Forms.CheckedListBox();
			this.lblPromt = new System.Windows.Forms.Label();
			this.cmdAsociar = new System.Windows.Forms.Button();
			this.lblAddNewType = new System.Windows.Forms.Label();
			this.txtAddNewType = new System.Windows.Forms.TextBox();
			this.cmdAddNewType = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// checkedListBoxControl1
			// 
			this.checkedListBoxControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
			this.checkedListBoxControl1.BackColor = System.Drawing.Color.Black;
			this.checkedListBoxControl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.checkedListBoxControl1.ForeColor = System.Drawing.Color.White;
			this.checkedListBoxControl1.FormattingEnabled = true;
			this.checkedListBoxControl1.Items.AddRange(new object[] {
            ".txt",
            ".csv",
            ".data",
            ".xml",
            ".ini",
            ".json",
            ".rtf",
            ".config",
            ".sql"});
			this.checkedListBoxControl1.Location = new System.Drawing.Point(12, 12);
			this.checkedListBoxControl1.Name = "checkedListBoxControl1";
			this.checkedListBoxControl1.Size = new System.Drawing.Size(125, 167);
			this.checkedListBoxControl1.TabIndex = 0;
			// 
			// lblPromt
			// 
			this.lblPromt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.lblPromt.ForeColor = System.Drawing.Color.White;
			this.lblPromt.Location = new System.Drawing.Point(152, 12);
			this.lblPromt.Name = "lblPromt";
			this.lblPromt.Size = new System.Drawing.Size(184, 77);
			this.lblPromt.TabIndex = 1;
			this.lblPromt.Text = "Select the File Types you wish to asociate with this Application";
			// 
			// cmdAsociar
			// 
			this.cmdAsociar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.cmdAsociar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cmdAsociar.ForeColor = System.Drawing.Color.White;
			this.cmdAsociar.Location = new System.Drawing.Point(155, 92);
			this.cmdAsociar.Name = "cmdAsociar";
			this.cmdAsociar.Size = new System.Drawing.Size(175, 23);
			this.cmdAsociar.TabIndex = 2;
			this.cmdAsociar.Text = "Associate";
			this.cmdAsociar.UseVisualStyleBackColor = false;
			this.cmdAsociar.Click += new System.EventHandler(this.cmdAsociar_Click);
			// 
			// lblAddNewType
			// 
			this.lblAddNewType.AutoSize = true;
			this.lblAddNewType.ForeColor = System.Drawing.Color.White;
			this.lblAddNewType.Location = new System.Drawing.Point(152, 140);
			this.lblAddNewType.Name = "lblAddNewType";
			this.lblAddNewType.Size = new System.Drawing.Size(100, 13);
			this.lblAddNewType.TabIndex = 3;
			this.lblAddNewType.Text = "Add New File Type:";
			// 
			// txtAddNewType
			// 
			this.txtAddNewType.BackColor = System.Drawing.Color.Black;
			this.txtAddNewType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtAddNewType.ForeColor = System.Drawing.Color.White;
			this.txtAddNewType.Location = new System.Drawing.Point(155, 158);
			this.txtAddNewType.Name = "txtAddNewType";
			this.txtAddNewType.Size = new System.Drawing.Size(58, 20);
			this.txtAddNewType.TabIndex = 4;
			// 
			// cmdAddNewType
			// 
			this.cmdAddNewType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.cmdAddNewType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cmdAddNewType.ForeColor = System.Drawing.Color.White;
			this.cmdAddNewType.Location = new System.Drawing.Point(219, 156);
			this.cmdAddNewType.Name = "cmdAddNewType";
			this.cmdAddNewType.Size = new System.Drawing.Size(111, 25);
			this.cmdAddNewType.TabIndex = 5;
			this.cmdAddNewType.Text = "button2";
			this.cmdAddNewType.UseVisualStyleBackColor = false;
			this.cmdAddNewType.Click += new System.EventHandler(this.cmdAddNewType_Click);
			// 
			// FileAsocForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Black;
			this.ClientSize = new System.Drawing.Size(348, 231);
			this.Controls.Add(this.cmdAddNewType);
			this.Controls.Add(this.txtAddNewType);
			this.Controls.Add(this.lblAddNewType);
			this.Controls.Add(this.cmdAsociar);
			this.Controls.Add(this.lblPromt);
			this.Controls.Add(this.checkedListBoxControl1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "FileAsocForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "File Asociations";
			this.Load += new System.EventHandler(this.FileAsocForm_Load);
			this.Shown += new System.EventHandler(this.FileAsocForm_Shown);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.CheckedListBox checkedListBoxControl1;
		private System.Windows.Forms.Label lblPromt;
		private System.Windows.Forms.Button cmdAsociar;
		private System.Windows.Forms.Label lblAddNewType;
		private System.Windows.Forms.TextBox txtAddNewType;
		private System.Windows.Forms.Button cmdAddNewType;
	}
}