﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DXNotepad
{
	public partial class FlatButton_WOC : Control
	{
		private ContentAlignment _textAligment = ContentAlignment.MiddleLeft;
		private Image _image;
		private Image _selectedImage;
		private Point _offset = new Point(0, 0);
		private SizeF _imageSize = new SizeF(20, 20);

		private bool _selected = false;
		private bool _drawImage = false;
		private bool _drawText = true;
		private bool _mouseHovering = false;
		private bool _useActiveImageWhileHovering = false;

		private Color _selectedBackColor;
		private Color _selectedForeColor;
		private Color _onHoverColor;
		private Color _onHoverTextColor;

		public FlatButton_WOC()
		{
			DoubleBuffered = true;
			BackColor = Color.FromArgb(41, 53, 65);
			ForeColor = Color.White;
			Height = 50;
			Width = 220;

			MouseEnter += OnMouseEnter;
			MouseLeave += OnMouseExit;
			MouseClick += OnClick;
		}

		private void OnClick(object sender, MouseEventArgs e)
		{
			if (!_selected && IsTab)
			{
				BackColor = _selectedBackColor;
				ForeColor = _selectedForeColor;

				if (Parent != null)
					foreach (Control control in Parent.Controls)
						(control as FlatButton_WOC)?.Unselect();

				_selected = true;
			}
		}

		public void Unselect()
		{
			if (!_selected) return;

			_selected = false;
			BackColor = DefaultBackColor;
			ForeColor = DefaultForeColor;
		}

		private void OnMouseExit(object sender, EventArgs e)
		{
			_mouseHovering = false;
			if (!_selected)
			{
				BackColor = DefaultBackColor;
				ForeColor = DefaultForeColor;
				Invalidate();
			}
		}

		private void OnMouseEnter(object sender, EventArgs e)
		{
			_mouseHovering = true;
			if (!_selected)
			{
				DefaultBackColor = BackColor;
				BackColor = _onHoverColor;

				DefaultForeColor = ForeColor;
				ForeColor = _onHoverTextColor;
				Invalidate();
			}
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
			if (_drawText)
				DrawString(pe.Graphics, _textAligment.ToString());
			if (_drawImage && _image != null)
			{
				float drawHeight = Height / 2 - _imageSize.Height / 2;
				pe.Graphics.DrawImage(_selected ||
									  (_mouseHovering && _useActiveImageWhileHovering)
						? (_selectedImage ?? _image)
						: _image,
					drawHeight, drawHeight, _imageSize.Width, _imageSize.Height);
			}
		}

		private void DrawString(Graphics g, string textAligment)
		{
			var stringSize = g.MeasureString(Text, Font);
			float drawX = _drawImage ? Height + _offset.X : _offset.X;
			float drawY = _offset.Y;

			if (textAligment.Contains("Middle"))
				drawY += Height / 2 - stringSize.Height / 2;
			else if (textAligment.Contains("Bottom"))
				drawY += Height - stringSize.Height;

			if (textAligment.Contains("Center"))
				drawX += Width / 2 - stringSize.Width / 2;
			else if (textAligment.Contains("Right"))
				drawX += Width - stringSize.Width;

			g.DrawString(Text, Font, new SolidBrush(ForeColor), drawX, drawY);
		}


		#region Getters and setters

		public bool Selected
		{
			get => _selected;
			set
			{
				if (_selected = value) //Intended
				{
					BackColor = _selectedBackColor;
					ForeColor = _selectedForeColor;
				}
				else
				{
					BackColor = DefaultBackColor;
					ForeColor = DefaultForeColor;
				}
			}
		}

		public new Color DefaultForeColor { get; set; }

		public new Color DefaultBackColor { get; set; }

		public Point TextOffset
		{
			get => _offset;
			set
			{
				_offset = value;
				Invalidate();
			}
		}

		public bool UseActiveImageWhileHovering
		{
			get => _useActiveImageWhileHovering;
			set => _useActiveImageWhileHovering = value;
		}

		public bool DrawText
		{
			get => _drawText;
			set
			{
				_drawText = value;
				Invalidate();
			}
		}

		public bool IsTab { get; set; } = true;

		public bool DrawImage
		{
			get => _drawImage;
			set
			{
				_drawImage = value;
				Invalidate();
			}
		}

		public ContentAlignment TextAligment
		{
			get => _textAligment;
			set
			{
				_textAligment = value;
				Invalidate();
			}
		}

		public Image ActiveImage
		{
			get => _selectedImage;
			set
			{
				_selectedImage = value;
				Invalidate();
			}
		}

		public Image Image
		{
			get => _image;
			set
			{
				_image = value;
				Invalidate();
			}
		}

		public Color OnHoverColor
		{
			get => _onHoverColor;
			set
			{
				_onHoverColor = value;
				Invalidate();
			}
		}

		public Color OnHoverTextColor
		{
			get => _onHoverTextColor;
			set
			{
				_onHoverTextColor = value;
				Invalidate();
			}
		}

		public Color ActiveColor
		{
			get => _selectedBackColor;
			set
			{
				_selectedBackColor = value;
				Invalidate();
			}
		}

		public Color ActiveTextColor
		{
			get => _selectedForeColor;
			set
			{
				_selectedForeColor = value;
				Invalidate();
			}
		}

		public override string Text
		{
			get => base.Text;
			set
			{
				base.Text = value;
				Invalidate();
			}
		}

		public SizeF ImageSize
		{
			get => _imageSize;
			set
			{
				_imageSize = value;
				Invalidate();
			}
		}

		#endregion
	}
}
