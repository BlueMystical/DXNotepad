﻿namespace DXNotepad.Controls
{
	partial class AboutForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.lblProgram = new System.Windows.Forms.Label();
			this.linkLabel1 = new System.Windows.Forms.LinkLabel();
			this.lblVersion = new System.Windows.Forms.Label();
			this.cmdCheckUpdates = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = global::DXNotepad.Properties.Resources.ergo_proxy_fullon_fight;
			this.pictureBox1.Location = new System.Drawing.Point(7, 9);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(147, 143);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(159, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(116, 24);
			this.label1.TabIndex = 1;
			this.label1.Text = "Blue Mystic";
			// 
			// lblProgram
			// 
			this.lblProgram.AutoSize = true;
			this.lblProgram.Location = new System.Drawing.Point(162, 68);
			this.lblProgram.Name = "lblProgram";
			this.lblProgram.Size = new System.Drawing.Size(83, 13);
			this.lblProgram.TabIndex = 2;
			this.lblProgram.Text = "[Program Name]";
			// 
			// linkLabel1
			// 
			this.linkLabel1.AutoSize = true;
			this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
			this.linkLabel1.Location = new System.Drawing.Point(160, 33);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new System.Drawing.Size(159, 13);
			this.linkLabel1.TabIndex = 3;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "https://github.com/BlueMystical";
			this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
			// 
			// lblVersion
			// 
			this.lblVersion.AutoSize = true;
			this.lblVersion.Location = new System.Drawing.Point(162, 87);
			this.lblVersion.Name = "lblVersion";
			this.lblVersion.Size = new System.Drawing.Size(48, 13);
			this.lblVersion.TabIndex = 4;
			this.lblVersion.Text = "[Version]";
			// 
			// cmdCheckUpdates
			// 
			this.cmdCheckUpdates.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
			this.cmdCheckUpdates.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cmdCheckUpdates.ForeColor = System.Drawing.Color.Black;
			this.cmdCheckUpdates.Location = new System.Drawing.Point(165, 123);
			this.cmdCheckUpdates.Name = "cmdCheckUpdates";
			this.cmdCheckUpdates.Size = new System.Drawing.Size(173, 23);
			this.cmdCheckUpdates.TabIndex = 5;
			this.cmdCheckUpdates.Text = "[Check For Updates]";
			this.cmdCheckUpdates.UseVisualStyleBackColor = false;
			this.cmdCheckUpdates.Click += new System.EventHandler(this.cmdCheckUpdates_Click);
			// 
			// AboutForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Black;
			this.ClientSize = new System.Drawing.Size(350, 164);
			this.Controls.Add(this.cmdCheckUpdates);
			this.Controls.Add(this.lblVersion);
			this.Controls.Add(this.linkLabel1);
			this.Controls.Add(this.lblProgram);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBox1);
			this.ForeColor = System.Drawing.Color.White;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "AboutForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "AboutForm";
			this.Load += new System.EventHandler(this.AboutForm_Load);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblProgram;
		private System.Windows.Forms.LinkLabel linkLabel1;
		private System.Windows.Forms.Label lblVersion;
		private System.Windows.Forms.Button cmdCheckUpdates;
	}
}