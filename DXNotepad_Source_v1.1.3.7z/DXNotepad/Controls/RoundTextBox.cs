﻿using System;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace DXNotepad.Controls
{
	public partial class RoundedCornerTextbox : TextBox
	{

		public RoundedCornerTextbox() : base()
		{
			this.Timer = new Timer();
			base.EnabledChanged += Enabled_Changed;
			base.Multiline = true;
			base.Height = 23;
			this.Timer.Interval = 20;
			this.Timer.Enabled = true;
		}

		[DllImport("user32")]
		static extern IntPtr GetWindowDC(IntPtr hwnd);
		[DllImport("user32.dll")]
		static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

		#region Globals
		private ArrayList mLeavingEventlist;
		private string _OriText = "";
		private string _NewText = "";
		private bool _Texthaschanged = false;
		private states state = states.normal;
		private Pen BorderPen;
		private Brush ArrowBrush, ButtonBrush, TextBrush;
		private Rectangle MainRect;
		private PointF[] pointArrow = new PointF[3];
		private int VerticalMiddle;
		private GraphicsPath ArrowPath = new GraphicsPath();
		private PointF TxtLoc;

		public enum states
		{
			normal,
			focused,
			disabled
		}

		#endregion

		#region Public properties
		public bool Texthaschanged
		{
			get
			{
				return this._Texthaschanged;
			}

			set
			{
				this._Texthaschanged = value;
			}
		}

		public string OriText
		{
			get
			{
				return this._OriText;
			}

			set
			{
				this._OriText = value;
			}
		}

		public string NewText
		{
			get
			{
				return this._NewText;
			}

			set
			{
				this._NewText = value;
			}
		}

		#endregion

		#region Events


		public event EventHandler BijLeaving
		{
			add
			{
				if (this.mLeavingEventlist is null)
				{
					this.mLeavingEventlist = new ArrayList();
				}

				this.mLeavingEventlist.Add(value);
			}

			remove
			{
				this.mLeavingEventlist.Remove(value);
			}
		}

		void OnBijLeaving(object sender, EventArgs ea)
		{
			if (this.mLeavingEventlist is object)
			{
				foreach (EventHandler handler in this.mLeavingEventlist)
				{
					if (handler is object)
					{
						handler.BeginInvoke(sender, ea, null, null);
					}
				}
			}
		}

		#endregion

		#region Listeners

		//protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		//{
		//	if (msg.WParam.ToInt32()  == Keys.Enter)
		//	{
		//		SendKeys.Send("{Tab}");
		//		return true;
		//	}
		//	else if (msg.WParam.ToInt32() == Keys.Decimal)
		//	{
		//		SendKeys.Send(",");
		//		return true;
		//	}

		//	return default;
		//}

		protected override void WndProc(ref Message m)
		{
			base.WndProc(ref m);
			switch (m.Msg)
			{
				case 0xF:
					{
						// WM_PAINT
						var rect = new Rectangle(0, 0, base.Width, base.Height);
						var hDC = GetWindowDC(this.Handle);
						Graphics g = Graphics.FromHdc(hDC);
						if (this.Enabled)
						{
							g.Clear(Color.White);
						}
						else
						{
							g.Clear(Color.FromName("control"));
						}

						DrawBorder(g);
						DrawText(g);
						ReleaseDC(this.Handle, hDC);
						g.Dispose();
						break;
					}

				case 0x7:
				case 0x8:
				case 0x200:
				case 0x2A3:
					{
						// CMB_DROPDOWN, CMB_CLOSEUP, WM_SETFOCUS, 
						// WM_KILLFOCUS, WM_MOUSEMOVE,  
						// WM_MOUSELEAVE (if you move the mouse fast over
						// the combobox, mouseleave doesn't always react)

						UpdateState();
						break;
					}
			}
		}

		private void Enabled_Changed(object sender, EventArgs e)
		{
			UpdateState();
		}

		private Timer _Timer;

		private Timer Timer
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			get
			{
				return this._Timer;
			}

			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				if (this._Timer != null)
				{
					this._Timer.Tick -= Timer_Tick;
				}

				this._Timer = value;
				if (this._Timer != null)
				{
					this._Timer.Tick += Timer_Tick;
				}
			}
		}

		private void Timer_Tick(object sender, EventArgs e)
		{
			UpdateState();
		}

		protected override void Dispose(bool e)
		{
			this.Timer.Enabled = false;
			base.Dispose(e);
		}

		private void UpdateState()
		{
			// save the current state
			var temp = this.state;
			// 
			if (this.Enabled)
			{
				if (this.ClientRectangle.Contains(PointToClient(Control.MousePosition)))
				{
					this.state = states.focused;
				}
				else if (this.Focused)
				{
					this.state = states.focused;
				}
				else
				{
					this.state = states.normal;
				}
			}
			else
			{
				this.state = states.disabled;
			}

			if (this.state != temp)
			{
				Invalidate();
			}
		}
		#endregion

		#region  Drawing functions 

		private void TekenRondeRechthoek(Graphics g, Pen pen, Rectangle rectangle, float radius)
		{
			float size = radius * 2.0f;
			var gp = new GraphicsPath();
			gp.AddArc(rectangle.X, rectangle.Y, size, size, 180, 90);
			gp.AddArc(rectangle.X + (rectangle.Width - size), rectangle.Y, size, size, 270, 90);
			gp.AddArc(rectangle.X + (rectangle.Width - size), rectangle.Y + (rectangle.Height - size), size, size, 0, 90);

			gp.AddArc(rectangle.X, rectangle.Y + (rectangle.Height - size), size, size, 90, 90);
			gp.CloseFigure();
			g.DrawPath(pen, gp);
			gp.Dispose();
		}

		private void DrawBorder(Graphics g)
		{
			this.MainRect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
			switch (this.state)
			{
				case states.focused:
					{
						this.BorderPen = new Pen(Color.Blue);
						break;
					}

				case states.disabled:
					{
						this.BorderPen = new Pen(Color.DarkGray);
						break;
					}

				case states.normal:
					{
						this.BorderPen = new Pen(Color.DimGray);
						break;
					}

				default:
					{
						return;
					}
			}

			TekenRondeRechthoek(g, this.BorderPen, this.MainRect, 3.0f);
		}

		private void DrawText(Graphics g)
		{
			string text = "";
			switch (this.state)
			{
				case states.normal:
				case states.focused:
					{
						this.TextBrush = new SolidBrush(this.ForeColor);
						break;
					}

				case states.disabled:
					{
						this.TextBrush = new SolidBrush(Color.DarkGray);
						break;
					}
			}

			if (g.MeasureString(this.Text, this.Font).Width > this.Width - 30)
			{
				int i = -1;
				do
				{
					i += 1;
					if (g.MeasureString(text, this.Font).Width > this.Width - 30)
						break;
					text += this.Text.Substring(i, 1);
				}
				while (true);
			}
			else
			{
				text = this.Text;
			}

			if (this.RightToLeft == System.Windows.Forms.RightToLeft.No)
			{
				this.TxtLoc = new PointF(1f, 4f);
			}
			else
			{
				float temp = this.Width - g.MeasureString(text, this.Font).Width;
				this.TxtLoc = new PointF(temp, 4f);
			}

			g.DrawString(text, this.Font, this.TextBrush, this.TxtLoc);
		}
		#endregion

		#region Overrides

		protected override void OnEnter(EventArgs e)
		{
			if (!(this.Text == ""))
			{
				this.OriText = this.Text;
			}
		}

		protected override void OnLeave(EventArgs e)
		{
			if (this.Text != this.OriText)
			{
				this.Texthaschanged = true;
				if (!(this.Text == ""))
				{
					this.NewText = this.Text;
				}

				OnBijLeaving(this, EventArgs.Empty);
			}
		}

		#endregion

	}
}