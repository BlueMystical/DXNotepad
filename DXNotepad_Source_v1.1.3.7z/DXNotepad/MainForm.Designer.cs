﻿namespace DXNotepad
{
	partial class MainForm
	{
		/// <summary>
		/// Variable del diseñador necesaria.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Limpiar los recursos que se estén usando.
		/// </summary>
		/// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Código generado por el Diseñador de Windows Forms

		/// <summary>
		/// Método necesario para admitir el Diseñador. No se puede modificar
		/// el contenido de este método con el editor de código.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            MenuControls.FlatMenuItemList flatMenuItemList1 = new MenuControls.FlatMenuItemList();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panel_TOP = new System.Windows.Forms.Panel();
            this.lblWindowTitle = new System.Windows.Forms.Label();
            this.cmdWindow_Minimize = new System.Windows.Forms.Label();
            this.cmdWindow_Maximize = new System.Windows.Forms.Label();
            this.cmdWindow_Close = new System.Windows.Forms.Label();
            this.picFormIcon = new System.Windows.Forms.PictureBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.txLines = new DXNotepad.Controls.RichTextBoxEx();
            this.VScrollBar_Box = new System.Windows.Forms.PictureBox();
            this.scrollBarEx_V = new CustomScrollBar.ScrollBarEx();
            this.HScrollBar_Box = new System.Windows.Forms.Panel();
            this.scrollBarEx_H = new CustomScrollBar.ScrollBarEx();
            this.memoTEXTO = new DXNotepad.Controls.RichTextBoxEx();
            this.panel_BOTTOM_2 = new System.Windows.Forms.Panel();
            this.cmdSaveChanges_2 = new System.Windows.Forms.Button();
            this.lblFindMatches_2 = new System.Windows.Forms.Label();
            this.cmdReplaceAll_2 = new System.Windows.Forms.Button();
            this.cmdReplaceNext_2 = new System.Windows.Forms.Button();
            this.ReplaceBox = new System.Windows.Forms.Panel();
            this.txtReplace_2 = new System.Windows.Forms.TextBox();
            this.cmdReplace_2 = new System.Windows.Forms.Button();
            this.cmdFindNext_2 = new System.Windows.Forms.Button();
            this.cmdSearch_2 = new System.Windows.Forms.Button();
            this.panelSearchBox = new System.Windows.Forms.Panel();
            this.txtSearch_2 = new System.Windows.Forms.TextBox();
            this.lblStatus_2 = new System.Windows.Forms.Label();
            this.lblFileSize_2 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuBar1 = new MenuControls.FlatMenuBar();
            this.panel_TOP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFormIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VScrollBar_Box)).BeginInit();
            this.HScrollBar_Box.SuspendLayout();
            this.panel_BOTTOM_2.SuspendLayout();
            this.ReplaceBox.SuspendLayout();
            this.panelSearchBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_TOP
            // 
            this.panel_TOP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_TOP.BackColor = System.Drawing.Color.Black;
            this.panel_TOP.Controls.Add(this.lblWindowTitle);
            this.panel_TOP.Controls.Add(this.cmdWindow_Minimize);
            this.panel_TOP.Controls.Add(this.cmdWindow_Maximize);
            this.panel_TOP.Controls.Add(this.cmdWindow_Close);
            this.panel_TOP.Controls.Add(this.picFormIcon);
            this.panel_TOP.Location = new System.Drawing.Point(2, 2);
            this.panel_TOP.Name = "panel_TOP";
            this.panel_TOP.Size = new System.Drawing.Size(785, 25);
            this.panel_TOP.TabIndex = 0;
            this.panel_TOP.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_TOP_MouseMove);
            // 
            // lblWindowTitle
            // 
            this.lblWindowTitle.AutoSize = true;
            this.lblWindowTitle.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWindowTitle.ForeColor = System.Drawing.Color.White;
            this.lblWindowTitle.Location = new System.Drawing.Point(219, 6);
            this.lblWindowTitle.Name = "lblWindowTitle";
            this.lblWindowTitle.Size = new System.Drawing.Size(68, 13);
            this.lblWindowTitle.TabIndex = 3;
            this.lblWindowTitle.Text = "DXNotepad";
            this.lblWindowTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblWindowTitle.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lblWindowTitle_MouseMove);
            // 
            // cmdWindow_Minimize
            // 
            this.cmdWindow_Minimize.Dock = System.Windows.Forms.DockStyle.Right;
            this.cmdWindow_Minimize.Font = new System.Drawing.Font("Segoe UI Symbol", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdWindow_Minimize.ForeColor = System.Drawing.Color.White;
            this.cmdWindow_Minimize.Location = new System.Drawing.Point(713, 0);
            this.cmdWindow_Minimize.Name = "cmdWindow_Minimize";
            this.cmdWindow_Minimize.Size = new System.Drawing.Size(24, 25);
            this.cmdWindow_Minimize.TabIndex = 2;
            this.cmdWindow_Minimize.Text = "─";
            this.cmdWindow_Minimize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cmdWindow_Minimize.Click += new System.EventHandler(this.cmdWindow_Minimize_Click);
            this.cmdWindow_Minimize.MouseEnter += new System.EventHandler(this.cmdWindow_Minimize_MouseEnter);
            this.cmdWindow_Minimize.MouseLeave += new System.EventHandler(this.cmdWindow_Minimize_MouseLeave);
            // 
            // cmdWindow_Maximize
            // 
            this.cmdWindow_Maximize.Dock = System.Windows.Forms.DockStyle.Right;
            this.cmdWindow_Maximize.Font = new System.Drawing.Font("Segoe UI Symbol", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdWindow_Maximize.ForeColor = System.Drawing.Color.White;
            this.cmdWindow_Maximize.Location = new System.Drawing.Point(737, 0);
            this.cmdWindow_Maximize.Name = "cmdWindow_Maximize";
            this.cmdWindow_Maximize.Size = new System.Drawing.Size(24, 25);
            this.cmdWindow_Maximize.TabIndex = 1;
            this.cmdWindow_Maximize.Text = "◳";
            this.cmdWindow_Maximize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cmdWindow_Maximize.Click += new System.EventHandler(this.cmdWindow_Maximize_Click);
            this.cmdWindow_Maximize.MouseEnter += new System.EventHandler(this.cmdWindow_Maximize_MouseEnter);
            this.cmdWindow_Maximize.MouseLeave += new System.EventHandler(this.cmdWindow_Maximize_MouseLeave);
            // 
            // cmdWindow_Close
            // 
            this.cmdWindow_Close.Dock = System.Windows.Forms.DockStyle.Right;
            this.cmdWindow_Close.Font = new System.Drawing.Font("Segoe UI Symbol", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdWindow_Close.ForeColor = System.Drawing.Color.White;
            this.cmdWindow_Close.Location = new System.Drawing.Point(761, 0);
            this.cmdWindow_Close.Name = "cmdWindow_Close";
            this.cmdWindow_Close.Size = new System.Drawing.Size(24, 25);
            this.cmdWindow_Close.TabIndex = 0;
            this.cmdWindow_Close.Text = "X";
            this.cmdWindow_Close.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cmdWindow_Close.Click += new System.EventHandler(this.cmdCloseWindow_Click);
            this.cmdWindow_Close.MouseEnter += new System.EventHandler(this.cmdCloseWindow_MouseEnter);
            this.cmdWindow_Close.MouseLeave += new System.EventHandler(this.cmdCloseWindow_MouseLeave);
            // 
            // picFormIcon
            // 
            this.picFormIcon.Location = new System.Drawing.Point(3, 3);
            this.picFormIcon.Name = "picFormIcon";
            this.picFormIcon.Size = new System.Drawing.Size(20, 20);
            this.picFormIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picFormIcon.TabIndex = 5;
            this.picFormIcon.TabStop = false;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(2, 31);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.txLines);
            this.splitContainer1.Panel1MinSize = 50;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.VScrollBar_Box);
            this.splitContainer1.Panel2.Controls.Add(this.scrollBarEx_V);
            this.splitContainer1.Panel2.Controls.Add(this.HScrollBar_Box);
            this.splitContainer1.Panel2.Controls.Add(this.memoTEXTO);
            this.splitContainer1.Panel2MinSize = 50;
            this.splitContainer1.Size = new System.Drawing.Size(785, 466);
            this.splitContainer1.SplitterDistance = 66;
            this.splitContainer1.TabIndex = 5;
            this.splitContainer1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitContainer1_SplitterMoved);
            this.splitContainer1.SizeChanged += new System.EventHandler(this.splitContainer1_SizeChanged);
            // 
            // txLines
            // 
            this.txLines.BackColor = System.Drawing.Color.DimGray;
            this.txLines.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txLines.Buddy = null;
            this.txLines.DetectUrls = false;
            this.txLines.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txLines.EnableMouseWheel = false;
            this.txLines.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txLines.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txLines.HideSelection = false;
            this.txLines.HorizontalPosition = 0;
            this.txLines.Location = new System.Drawing.Point(0, 0);
            this.txLines.Name = "txLines";
            this.txLines.ReadOnly = true;
            this.txLines.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.txLines.Scrolling = false;
            this.txLines.ShortcutsEnabled = false;
            this.txLines.Size = new System.Drawing.Size(66, 466);
            this.txLines.TabIndex = 0;
            this.txLines.TabStop = false;
            this.txLines.Text = "";
            this.txLines.VerticalPosition = 0;
            this.txLines.WordWrap = false;
            // 
            // VScrollBar_Box
            // 
            this.VScrollBar_Box.Dock = System.Windows.Forms.DockStyle.Right;
            this.VScrollBar_Box.Location = new System.Drawing.Point(690, 0);
            this.VScrollBar_Box.Name = "VScrollBar_Box";
            this.VScrollBar_Box.Size = new System.Drawing.Size(6, 446);
            this.VScrollBar_Box.TabIndex = 1;
            this.VScrollBar_Box.TabStop = false;
            this.VScrollBar_Box.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // scrollBarEx_V
            // 
            this.scrollBarEx_V.BackgroundColor = System.Drawing.Color.Black;
            this.scrollBarEx_V.BorderColor = System.Drawing.Color.Black;
            this.scrollBarEx_V.Dock = System.Windows.Forms.DockStyle.Right;
            this.scrollBarEx_V.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.scrollBarEx_V.Location = new System.Drawing.Point(696, 0);
            this.scrollBarEx_V.Name = "scrollBarEx_V";
            this.scrollBarEx_V.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.scrollBarEx_V.Size = new System.Drawing.Size(19, 446);
            this.scrollBarEx_V.TabIndex = 0;
            this.scrollBarEx_V.TrackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.scrollBarEx_V.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrollBarEx_V_Scroll);
            // 
            // HScrollBar_Box
            // 
            this.HScrollBar_Box.BackColor = System.Drawing.Color.Black;
            this.HScrollBar_Box.Controls.Add(this.scrollBarEx_H);
            this.HScrollBar_Box.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.HScrollBar_Box.Location = new System.Drawing.Point(0, 446);
            this.HScrollBar_Box.Name = "HScrollBar_Box";
            this.HScrollBar_Box.Size = new System.Drawing.Size(715, 20);
            this.HScrollBar_Box.TabIndex = 4;
            // 
            // scrollBarEx_H
            // 
            this.scrollBarEx_H.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.scrollBarEx_H.BackgroundColor = System.Drawing.Color.Black;
            this.scrollBarEx_H.BorderColor = System.Drawing.Color.Black;
            this.scrollBarEx_H.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.scrollBarEx_H.Location = new System.Drawing.Point(0, 0);
            this.scrollBarEx_H.Name = "scrollBarEx_H";
            this.scrollBarEx_H.Orientation = CustomScrollBar.ScrollBarOrientation.Horizontal;
            this.scrollBarEx_H.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.scrollBarEx_H.Size = new System.Drawing.Size(697, 19);
            this.scrollBarEx_H.TabIndex = 3;
            this.scrollBarEx_H.TrackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.scrollBarEx_H.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrollBarEx_H_Scroll);
            // 
            // memoTEXTO
            // 
            this.memoTEXTO.AcceptsTab = true;
            this.memoTEXTO.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.memoTEXTO.AutoWordSelection = true;
            this.memoTEXTO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.memoTEXTO.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.memoTEXTO.Buddy = this.txLines;
            this.memoTEXTO.EnableMouseWheel = true;
            this.memoTEXTO.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.memoTEXTO.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.memoTEXTO.HideSelection = false;
            this.memoTEXTO.HorizontalPosition = 0;
            this.memoTEXTO.Location = new System.Drawing.Point(0, 0);
            this.memoTEXTO.Name = "memoTEXTO";
            this.memoTEXTO.Scrolling = false;
            this.memoTEXTO.Size = new System.Drawing.Size(708, 466);
            this.memoTEXTO.TabIndex = 1;
            this.memoTEXTO.Text = "";
            this.memoTEXTO.VerticalPosition = 0;
            this.memoTEXTO.WordWrap = false;
            this.memoTEXTO.ContentsResized += new System.Windows.Forms.ContentsResizedEventHandler(this.memoTEXTO_ContentsResized);
            this.memoTEXTO.HScroll += new System.EventHandler(this.memoTEXTO_HScroll);
            this.memoTEXTO.LinkClicked += new System.Windows.Forms.LinkClickedEventHandler(this.memoTEXTO_LinkClicked);
            this.memoTEXTO.SelectionChanged += new System.EventHandler(this.memoTEXTO_SelectionChanged);
            this.memoTEXTO.VScroll += new System.EventHandler(this.memoTEXTO_VScroll);
            this.memoTEXTO.TextChanged += new System.EventHandler(this.memoTEXTO_TextChanged);
            this.memoTEXTO.KeyDown += new System.Windows.Forms.KeyEventHandler(this.memoTEXTO_KeyDown);
            this.memoTEXTO.MouseUp += new System.Windows.Forms.MouseEventHandler(this.memoTEXTO_MouseUp);
            this.memoTEXTO.Resize += new System.EventHandler(this.memoTEXTO_Resize);
            // 
            // panel_BOTTOM_2
            // 
            this.panel_BOTTOM_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_BOTTOM_2.BackColor = System.Drawing.Color.Black;
            this.panel_BOTTOM_2.Controls.Add(this.cmdSaveChanges_2);
            this.panel_BOTTOM_2.Controls.Add(this.lblFindMatches_2);
            this.panel_BOTTOM_2.Controls.Add(this.cmdReplaceAll_2);
            this.panel_BOTTOM_2.Controls.Add(this.cmdReplaceNext_2);
            this.panel_BOTTOM_2.Controls.Add(this.ReplaceBox);
            this.panel_BOTTOM_2.Controls.Add(this.cmdReplace_2);
            this.panel_BOTTOM_2.Controls.Add(this.cmdFindNext_2);
            this.panel_BOTTOM_2.Controls.Add(this.cmdSearch_2);
            this.panel_BOTTOM_2.Controls.Add(this.panelSearchBox);
            this.panel_BOTTOM_2.Controls.Add(this.lblStatus_2);
            this.panel_BOTTOM_2.Controls.Add(this.lblFileSize_2);
            this.panel_BOTTOM_2.ForeColor = System.Drawing.Color.White;
            this.panel_BOTTOM_2.Location = new System.Drawing.Point(2, 497);
            this.panel_BOTTOM_2.Name = "panel_BOTTOM_2";
            this.panel_BOTTOM_2.Size = new System.Drawing.Size(776, 28);
            this.panel_BOTTOM_2.TabIndex = 6;
            // 
            // cmdSaveChanges_2
            // 
            this.cmdSaveChanges_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.cmdSaveChanges_2.Dock = System.Windows.Forms.DockStyle.Right;
            this.cmdSaveChanges_2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.cmdSaveChanges_2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.cmdSaveChanges_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdSaveChanges_2.ForeColor = System.Drawing.Color.Black;
            this.cmdSaveChanges_2.Location = new System.Drawing.Point(635, 0);
            this.cmdSaveChanges_2.Name = "cmdSaveChanges_2";
            this.cmdSaveChanges_2.Size = new System.Drawing.Size(141, 28);
            this.cmdSaveChanges_2.TabIndex = 2;
            this.cmdSaveChanges_2.Text = "&Save Changes";
            this.cmdSaveChanges_2.UseVisualStyleBackColor = false;
            this.cmdSaveChanges_2.Click += new System.EventHandler(this.cmdSaveChanges_Click);
            // 
            // lblFindMatches_2
            // 
            this.lblFindMatches_2.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblFindMatches_2.Location = new System.Drawing.Point(492, 0);
            this.lblFindMatches_2.Name = "lblFindMatches_2";
            this.lblFindMatches_2.Size = new System.Drawing.Size(96, 28);
            this.lblFindMatches_2.TabIndex = 6;
            this.lblFindMatches_2.Text = "[0 Coincidencias]";
            this.lblFindMatches_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmdReplaceAll_2
            // 
            this.cmdReplaceAll_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.cmdReplaceAll_2.Dock = System.Windows.Forms.DockStyle.Left;
            this.cmdReplaceAll_2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.cmdReplaceAll_2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.cmdReplaceAll_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdReplaceAll_2.Location = new System.Drawing.Point(468, 0);
            this.cmdReplaceAll_2.Name = "cmdReplaceAll_2";
            this.cmdReplaceAll_2.Size = new System.Drawing.Size(24, 28);
            this.cmdReplaceAll_2.TabIndex = 9;
            this.cmdReplaceAll_2.UseVisualStyleBackColor = false;
            this.cmdReplaceAll_2.Click += new System.EventHandler(this.cmdReplaceAll_Click);
            // 
            // cmdReplaceNext_2
            // 
            this.cmdReplaceNext_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.cmdReplaceNext_2.Dock = System.Windows.Forms.DockStyle.Left;
            this.cmdReplaceNext_2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.cmdReplaceNext_2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.cmdReplaceNext_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdReplaceNext_2.Location = new System.Drawing.Point(444, 0);
            this.cmdReplaceNext_2.Name = "cmdReplaceNext_2";
            this.cmdReplaceNext_2.Size = new System.Drawing.Size(24, 28);
            this.cmdReplaceNext_2.TabIndex = 8;
            this.cmdReplaceNext_2.UseVisualStyleBackColor = false;
            this.cmdReplaceNext_2.Click += new System.EventHandler(this.cmdReplaceNext_Click);
            // 
            // ReplaceBox
            // 
            this.ReplaceBox.Controls.Add(this.txtReplace_2);
            this.ReplaceBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.ReplaceBox.Location = new System.Drawing.Point(332, 0);
            this.ReplaceBox.Name = "ReplaceBox";
            this.ReplaceBox.Padding = new System.Windows.Forms.Padding(4, 6, 4, 4);
            this.ReplaceBox.Size = new System.Drawing.Size(112, 28);
            this.ReplaceBox.TabIndex = 7;
            this.ReplaceBox.Paint += new System.Windows.Forms.PaintEventHandler(this.ReplaceBox_Paint);
            // 
            // txtReplace_2
            // 
            this.txtReplace_2.BackColor = System.Drawing.Color.Black;
            this.txtReplace_2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtReplace_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtReplace_2.ForeColor = System.Drawing.Color.White;
            this.txtReplace_2.Location = new System.Drawing.Point(4, 6);
            this.txtReplace_2.Name = "txtReplace_2";
            this.txtReplace_2.Size = new System.Drawing.Size(104, 15);
            this.txtReplace_2.TabIndex = 1;
            this.txtReplace_2.Text = "Search Here.";
            this.txtReplace_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtReplace_2.WordWrap = false;
            this.txtReplace_2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtReplace_KeyDown);
            // 
            // cmdReplace_2
            // 
            this.cmdReplace_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.cmdReplace_2.Dock = System.Windows.Forms.DockStyle.Left;
            this.cmdReplace_2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.cmdReplace_2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.cmdReplace_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdReplace_2.Location = new System.Drawing.Point(308, 0);
            this.cmdReplace_2.Name = "cmdReplace_2";
            this.cmdReplace_2.Size = new System.Drawing.Size(24, 28);
            this.cmdReplace_2.TabIndex = 5;
            this.cmdReplace_2.UseVisualStyleBackColor = false;
            this.cmdReplace_2.Click += new System.EventHandler(this.cmdReplace_Click);
            // 
            // cmdFindNext_2
            // 
            this.cmdFindNext_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.cmdFindNext_2.Dock = System.Windows.Forms.DockStyle.Left;
            this.cmdFindNext_2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.cmdFindNext_2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.cmdFindNext_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdFindNext_2.Location = new System.Drawing.Point(284, 0);
            this.cmdFindNext_2.Name = "cmdFindNext_2";
            this.cmdFindNext_2.Size = new System.Drawing.Size(24, 28);
            this.cmdFindNext_2.TabIndex = 4;
            this.cmdFindNext_2.UseVisualStyleBackColor = false;
            this.cmdFindNext_2.Visible = false;
            this.cmdFindNext_2.Click += new System.EventHandler(this.cmdFindNext_Click);
            // 
            // cmdSearch_2
            // 
            this.cmdSearch_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.cmdSearch_2.Dock = System.Windows.Forms.DockStyle.Left;
            this.cmdSearch_2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.cmdSearch_2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.cmdSearch_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdSearch_2.Location = new System.Drawing.Point(260, 0);
            this.cmdSearch_2.Name = "cmdSearch_2";
            this.cmdSearch_2.Size = new System.Drawing.Size(24, 28);
            this.cmdSearch_2.TabIndex = 3;
            this.cmdSearch_2.UseVisualStyleBackColor = false;
            this.cmdSearch_2.Click += new System.EventHandler(this.cmdSearch_2_Click);
            // 
            // panelSearchBox
            // 
            this.panelSearchBox.Controls.Add(this.txtSearch_2);
            this.panelSearchBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSearchBox.Location = new System.Drawing.Point(153, 0);
            this.panelSearchBox.Name = "panelSearchBox";
            this.panelSearchBox.Padding = new System.Windows.Forms.Padding(4, 6, 4, 4);
            this.panelSearchBox.Size = new System.Drawing.Size(107, 28);
            this.panelSearchBox.TabIndex = 2;
            this.panelSearchBox.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSearchBox_Paint);
            // 
            // txtSearch_2
            // 
            this.txtSearch_2.BackColor = System.Drawing.Color.Black;
            this.txtSearch_2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSearch_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSearch_2.ForeColor = System.Drawing.Color.White;
            this.txtSearch_2.Location = new System.Drawing.Point(4, 6);
            this.txtSearch_2.Name = "txtSearch_2";
            this.txtSearch_2.Size = new System.Drawing.Size(99, 15);
            this.txtSearch_2.TabIndex = 0;
            this.txtSearch_2.Text = "Search Here.";
            this.txtSearch_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSearch_2.WordWrap = false;
            this.txtSearch_2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtSearch_2_MouseClick);
            this.txtSearch_2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // lblStatus_2
            // 
            this.lblStatus_2.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblStatus_2.Location = new System.Drawing.Point(65, 0);
            this.lblStatus_2.Name = "lblStatus_2";
            this.lblStatus_2.Size = new System.Drawing.Size(88, 28);
            this.lblStatus_2.TabIndex = 1;
            this.lblStatus_2.Text = "1.925 Lines.";
            this.lblStatus_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFileSize_2
            // 
            this.lblFileSize_2.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblFileSize_2.Location = new System.Drawing.Point(0, 0);
            this.lblFileSize_2.Name = "lblFileSize_2";
            this.lblFileSize_2.Size = new System.Drawing.Size(65, 28);
            this.lblFileSize_2.TabIndex = 0;
            this.lblFileSize_2.Text = "64.56 Kb";
            this.lblFileSize_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuBar1
            // 
            this.menuBar1.BorderColor = System.Drawing.Color.Black;
            this.menuBar1.DisabledTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(151)))), ((int)(((byte)(165)))));
            this.menuBar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.menuBar1.HoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.menuBar1.HoverFont = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.menuBar1.HoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.menuBar1.Location = new System.Drawing.Point(27, 2);
            this.menuBar1.MenuItems = flatMenuItemList1;
            this.menuBar1.Name = "flatMenuBar1";
            this.menuBar1.ParentMenu = null;
            this.menuBar1.ParentMenuItem = null;
            this.menuBar1.SeparatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.menuBar1.Size = new System.Drawing.Size(175, 25);
            this.menuBar1.TabIndex = 1;
            this.menuBar1.TabStop = false;
            this.menuBar1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.menuBar1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.menuBar1_MouseMove);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(790, 528);
            this.ControlBox = false;
            this.Controls.Add(this.panel_BOTTOM_2);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.menuBar1);
            this.Controls.Add(this.panel_TOP);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.ResizeEnd += new System.EventHandler(this.MainForm_ResizeEnd);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseMove);
            this.panel_TOP.ResumeLayout(false);
            this.panel_TOP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFormIcon)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.VScrollBar_Box)).EndInit();
            this.HScrollBar_Box.ResumeLayout(false);
            this.panel_BOTTOM_2.ResumeLayout(false);
            this.ReplaceBox.ResumeLayout(false);
            this.ReplaceBox.PerformLayout();
            this.panelSearchBox.ResumeLayout(false);
            this.panelSearchBox.PerformLayout();
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panel_TOP;
		private System.Windows.Forms.Label cmdWindow_Close;
		private System.Windows.Forms.Label cmdWindow_Maximize;
		private System.Windows.Forms.Label cmdWindow_Minimize;
		private System.Windows.Forms.Label lblWindowTitle;
		private MenuControls.FlatMenuBar menuBar1;
		private System.Windows.Forms.PictureBox picFormIcon;
		private Controls.RichTextBoxEx memoTEXTO;
		private Controls.RichTextBoxEx txLines;
		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.PictureBox VScrollBar_Box;
		private CustomScrollBar.ScrollBarEx scrollBarEx_V;
		private System.Windows.Forms.Panel panel_BOTTOM_2;
		private System.Windows.Forms.Button cmdSearch_2;
		private System.Windows.Forms.Panel panelSearchBox;
		private System.Windows.Forms.TextBox txtSearch_2;
		private System.Windows.Forms.Label lblStatus_2;
		private System.Windows.Forms.Label lblFileSize_2;
		private System.Windows.Forms.Button cmdReplace_2;
		private System.Windows.Forms.Button cmdFindNext_2;
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.Label lblFindMatches_2;
		private System.Windows.Forms.Panel ReplaceBox;
		private System.Windows.Forms.TextBox txtReplace_2;
		private System.Windows.Forms.Button cmdReplaceAll_2;
		private System.Windows.Forms.Button cmdReplaceNext_2;
		private System.Windows.Forms.Button cmdSaveChanges_2;
		private System.Windows.Forms.Panel HScrollBar_Box;
		private CustomScrollBar.ScrollBarEx scrollBarEx_H;
	}
}

